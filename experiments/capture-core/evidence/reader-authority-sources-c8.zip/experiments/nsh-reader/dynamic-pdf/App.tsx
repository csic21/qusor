import { Canvas, Image, Scroll, mount, signal, Text, View } from "nsh";
import { AlertDialog, Input } from "nsh/base";
import { ReaderSurface, DynamicReader } from "qusor/pdf-surface";
const parse=(value:string)=>JSON.parse(value);
function App(){
 const config=signal<any>(null),display=signal<any>(null),width=signal(968),ready=signal("");
 const boxes=signal<number[][]>([]),quote=signal(""),candidate=signal(""),saved=signal(false),note=signal("");
 const status=signal("选择一份本地 PDF 开始阅读"),busy=signal(false),saving=signal(false),importedOnly=signal(false),draftSource=signal(""),frameFailed=signal(false);
 let layout="",desiredZoom=.6,frameRequest=0,importRequest=0,noteCommitted=false;
 const key=(c:any)=>c?`${c.handle}:${c.generation}:${c.frame_id}`:"empty";
 const wide=()=>width()>=900;const paperWidth=()=>wide()?width()-276:width();
 const clear=()=>{boxes.set([]);quote.set("");candidate.set("");saved.set(false);};
 const clearImage=()=>{const old=display();display.set(null);if(old?.url)URL.revokeObjectURL(old.url);};
 const requestImage=async(c:any)=>{
  const id=++frameRequest;frameFailed.set(false);config.set(c);clearImage();ready.set("");clear();status.set("页面加载中");
  try{const frame=await DynamicReader.frame(c.handle,c.generation,c.frame_id);if(id!==frameRequest||key(config())!==key(c))return;
   const info=parse(frame.info);if(key(info)!==key(c))throw Error("stale image");const url=URL.createObjectURL(frame.file);display.set({frame:info,url});
  }catch(_){if(id===frameRequest&&key(config())===key(c)){status.set("页面暂不可用，请重试。");}}
 };
 const configure=(page:number,zoom:number,fromLayout=false)=>{
  if(!config()||busy())return;if(!fromLayout)desiredZoom=zoom;const old=config();const result=parse(ReaderSurface.configure(old.handle,old.generation,page,zoom));
  if(key(config())!==key(old))return;
  if(result.ok)requestImage(result.value);else{clearImage();ready.set("");clear();status.set("页面暂不可用，请重新打开资料。");}
 };
 const open=async()=>{
  if(busy())return;
  if(note().length>0&&!saved()){
   const answer=await AlertDialog.show({title:"切换资料？",description:"未保存的想法会在另一份资料打开成功后清除。",actions:[{id:"cancel",label:"继续当前阅读",role:"cancel"},{id:"open",label:"选择另一份"}]});
   if(answer.action!=="open")return;
  }
  const id=++importRequest;busy.set(true);status.set("请选择本地 PDF；读取后将保留原文件");
  try{const result=parse(await DynamicReader.choose());if(id!==importRequest)return;
   if(!result.ok){status.set("无法打开该 PDF。请检查文件或当前验证预算；原资料和想法已保留。");return;}
   if(result.value.cancelled){status.set(config()?"已取消，继续当前阅读":"选择一份本地 PDF 开始阅读");return;}
   if(result.value.imported&&!result.value.opened){draftSource.set(config()?.title||draftSource());config.set(null);clearImage();clear();importedOnly.set(true);status.set("资料已导入，但阅读器暂未打开。未保存的想法仍保留在下方。");return;}
   note.set("");draftSource.set("");noteCommitted=false;importedOnly.set(false);clear();const c=result.value;
   const fitted=Math.max(.25,Math.min(desiredZoom,paperWidth()/(c.width/c.zoom)));
   const fittedResult=parse(ReaderSurface.configure(c.handle,c.generation,c.page,fitted));
   await requestImage(fittedResult.ok?fittedResult.value:c);
  }catch(_){if(id===importRequest)status.set("未能打开资料，原资料和想法已保留。");}
  finally{if(id===importRequest)busy.set(false);}
 };
 const reopen=async()=>{if(busy())return;busy.set(true);try{const r=parse(await DynamicReader.reopen());if(r.ok){note.set("");draftSource.set("");noteCommitted=false;importedOnly.set(false);await requestImage(r.value);}else status.set("阅读器仍不可用，已导入的资料和想法保留在本机。");}catch(_){status.set("阅读器仍不可用，请重试。");}finally{busy.set(false);}};
 const cancelImport=()=>{const r=parse(DynamicReader.cancel());if(r.ok&&r.value.cancelled){++importRequest;busy.set(false);status.set(config()?"已取消导入，继续当前阅读":"已取消导入");}else status.set("正在完成本机保存，请稍候。");};
 const button=(title:string,action:()=>void,enabled=true)=><View accessibilityState={{disabled:!enabled}} onPress={enabled?action:undefined} style={{paddingHorizontal:12,paddingVertical:9,borderRadius:6,backgroundColor:"#e8e7e3",opacity:enabled?1:.45}}><Text style={{fontSize:14}}>{title}</Text></View>;
 return <View onLayout={({bounds}:any)=>{if(bounds.size.width<=0||bounds.size.height<=0)return;const size=`${bounds.size.width}:${bounds.size.height}`;width.set(Math.max(240,bounds.size.width-32));const changed=layout!==size;layout=size;if(changed&&config()&&!busy())configure(config().page,Math.max(.25,Math.min(desiredZoom,paperWidth()/(config().width/config().zoom))),true);}} style={{flex:1,padding:16,gap:12,backgroundColor:"#f2f1ed"}}>
  <View style={{flexDirection:"row",flexWrap:"wrap",alignItems:"center",gap:8}}>
   {button("打开 PDF",open,!busy())}<Text style={{flex:1,fontSize:18,fontWeight:"600"}}>{config()?.title||"本地阅读"}</Text>
   {button("上一页",()=>configure(config().page-1,config().zoom),!busy()&&config()?.page>0)}
   <Text>{config()?`${config().page+1} / ${config().pages}`:""}</Text>
   {button("下一页",()=>configure(config().page+1,config().zoom),!busy()&&!!config()&&config().page+1<config().pages)}
   <Text>{config()?`${Math.round(config().zoom*100)}%`:""}</Text>
   {button("−",()=>configure(config().page,Math.max(.25,config().zoom-.1)),!busy()&&!!config())}
   {button("＋",()=>configure(config().page,Math.min(1.25,config().zoom+.1)),!busy()&&!!config())}
  </View>
  <If when={busy()}><View style={{flexDirection:"row",alignItems:"center",gap:8}}><Text style={{flex:1}}>{saving()?"保存中，请稍候。":"正在打开资料…"}</Text>{button("取消导入",cancelImport,!saving())}</View></If>
  <If when={!display()}><View style={{flex:1,padding:24,gap:16}}><Text>{status()}</Text><Text style={{color:"#777777",fontSize:13}}>当前验证支持 16 MiB、16 页以内的 PDF。原文件不上传。</Text><If when={importedOnly()}>{button("打开已导入资料",reopen,!busy())}</If><If when={note().length>0}><Text>{draftSource()?`${draftSource()} · 未保存想法`:"未保存想法"}</Text><Input value={note()} onChange={({value}:any)=>note.set(value)} multiline readonly={busy()} style={{height:96,padding:8,borderWidth:1,borderColor:"#dddddd"}}/></If>{button(config()?"重试当前页":"选择本地 PDF",()=>config()?requestImage(config()):open(),!busy())}</View></If>
  <Each of={display()?[display()]:[]} key={(entry:any)=>`${key(entry.frame)}:${entry.url}`}>{(entry)=>{const item=entry();const frame=item.frame;let gesture:number|null=null;let pointer:number|null=null;
   const matches=()=>key(config())===key(frame)&&display()?.url===item.url;
   const current=()=>matches()&&!busy();
   const receive=(raw:string)=>{if(!current())return;const r=parse(raw);if(!r.ok){clear();gesture=null;pointer=null;status.set("拖动正文以选择文字");return;}const v=r.value;if(v.handle!==frame.handle||v.generation!==frame.generation||v.frame_id!==frame.frame_id)return;gesture=v.gesture??null;boxes.set(v.boxes??[]);quote.set(v.text??"");candidate.set(v.candidate?.candidate_id??"");saved.set(false);status.set(v.candidate?"候选引文 · 尚未保存":v.text?"正在选择文字":"拖动正文以选择文字");};
   const cancel=()=>{if(gesture!==null){ReaderSurface.cancel(frame.handle,frame.generation,pointer!,gesture);gesture=null;pointer=null;if(current()){clear();status.set("拖动正文以选择文字");}}};
   const save=async()=>{if(!current()||!candidate()||saved())return;const id=candidate();busy.set(true);saving.set(true);status.set("保存中");
    try{const result=parse(await DynamicReader.save(id,note()));if(key(config())!==key(frame)||candidate()!==id)return;
     if(result.ok&&result.value.saved){saved.set(true);noteCommitted=true;status.set("已保存到本机");}else status.set("保存未确认，想法已保留，请原样重试。");
    }catch(_){status.set("保存未确认，想法已保留，请原样重试。");}finally{saving.set(false);busy.set(false);}
   };
   return <Scroll style={{flex:1}} contentStyle={{flexDirection:wide()?"row":"column",gap:16,alignItems:"flex-start"}} onScroll={cancel}>
    <Scroll horizontal style={{width:paperWidth(),height:frame.height}} onScroll={cancel}>
     <View style={{width:frame.width,height:frame.height,backgroundColor:"#ffffff"}}>
      <Image src={item.url} onLoad={()=>{if(!matches()||ready()===key(frame))return;const r=parse(ReaderSurface.ready(frame.handle,frame.generation,frame.frame_id,frame.report_digest));if(r.ok&&matches()){ready.set(key(frame));status.set(frame.text_status==="mapped"?"拖动正文以选择文字":frame.text_status==="no_text"?"此页没有可选文字":"此页暂不支持精确选文");}}} onError={()=>{if(!matches())return;ReaderSurface.failed(frame.handle,frame.generation,frame.frame_id);ready.set("");clear();frameFailed.set(true);status.set("页面加载失败，请重试。");}} style={{width:frame.width,height:frame.height}}/>
      <Canvas onStartShouldSetResponder={()=>current()&&ready()===key(frame)&&frame.text_status==="mapped"} onResponderGrant={(e:any)=>{if(!current())return;if(noteCommitted){note.set("");noteCommitted=false;}clear();pointer=e.identifier;receive(ReaderSurface.down(frame.handle,frame.generation,pointer,e.locationX,e.locationY));}} onResponderMove={(e:any)=>{if(gesture!==null&&pointer===e.identifier)receive(ReaderSurface.motion(frame.handle,frame.generation,pointer,gesture,e.locationX,e.locationY));}} onResponderRelease={(e:any)=>{if(gesture!==null&&pointer===e.identifier)receive(ReaderSurface.up(frame.handle,frame.generation,pointer,gesture,e.locationX,e.locationY));pointer=null;}} onResponderTerminate={cancel} onResponderTerminationRequest={()=>true} onMouseLeave={cancel} draw={(cx)=>{cx.fillStyle="rgba(245,196,70,0.35)";for(const [x,y,w,h]of boxes())cx.fillRect(x,y,w,h);}} style={{position:"absolute",left:0,top:0,width:frame.width,height:frame.height}}/>
     </View>
    </Scroll>
    <View style={{width:wide()?260:width(),padding:16,gap:10,borderRadius:8,backgroundColor:"#ffffff"}}>
     <Text style={{fontSize:13,color:"#666666"}}>{`${frame.title} · 第 ${frame.page+1} 页`}</Text>
     <Text style={{fontSize:14,color:"#666666"}}>{status()}</Text><If when={frameFailed()}>{button("重试当前页",()=>configure(frame.page,frame.zoom),!busy())}</If><Text style={{fontSize:13,color:"#666666"}}>引文</Text>
     <Text style={{fontSize:16,lineHeight:24}}>{quote()||"在页面中拖动选择文字，确认引文后保存。"}</Text>
     <Text style={{fontSize:13,color:"#666666"}}>个人想法</Text>
     <Input value={note()} onChange={({value}:any)=>{note.set(value);noteCommitted=false;}} multiline readonly={saved()||busy()} placeholder="写下你的想法" style={{height:96,padding:8,borderWidth:1,borderColor:"#dddddd"}}/>
     {button(saved()?"已保存":saving()?"保存中":"保存摘录",save,!!candidate()&&!saved()&&!busy())}
    </View>
   </Scroll>;}}
  </Each>
 </View>;
}
mount(App);
