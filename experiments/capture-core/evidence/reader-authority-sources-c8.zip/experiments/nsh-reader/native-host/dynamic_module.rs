//! Trusted native UI assembly for runtime-selected documents. Guest sees only Surface wire.
use crate::{
    dynamic_worker::{self, Artifact, WorkerConfig},
    plugin_surface::{self, ReaderSurface},
};
use nsh_core::{
    ImageData,
    element::{JsHost, JsIn, JsOwned, PropError, TsTypes},
    file_dialog::{FileFilter, OpenDialog},
    prelude::*,
};
use serde_json::{Value, json};
use std::{
    future::Future,
    io::Read,
    path::{Path, PathBuf},
    pin::Pin,
    sync::{
        Arc, Condvar, Mutex,
        atomic::{AtomicBool, AtomicU8, AtomicU64, Ordering},
    },
    task::{Context, Poll, Waker},
};
type Result<T> = std::result::Result<T, String>;
const IDLE: u8 = 0;
const PICKING: u8 = 1;
const PARSING: u8 = 2;
const COMMITTING: u8 = 3;
const READY: u8 = 4;
struct Config {
    resources: PathBuf,
    data: PathBuf,
    worker: WorkerConfig,
    nonce: String,
    picker_dir: Option<PathBuf>,
}
struct State {
    config: Config,
    generation: AtomicU64,
    phase: AtomicU8,
    has_document: AtomicBool,
    parser_running: Arc<AtomicBool>,
    frames: FrameScheduler,
    artifact: Mutex<Option<Arc<Artifact>>>,
}
static STATE: Mutex<Option<Arc<State>>> = Mutex::new(None);
fn state() -> Result<Arc<State>> {
    STATE
        .lock()
        .map_err(|_| "dynamic state unavailable")?
        .clone()
        .ok_or("dynamic state unavailable".into())
}
fn text(e: impl std::fmt::Display) -> String {
    e.to_string()
}
pub fn initialize(resources: &Path, data: &Path, worker: &Path, library: &Path) -> Result<()> {
    let mut nonce = [0; 16];
    std::fs::File::open("/dev/urandom")
        .and_then(|mut f| f.read_exact(&mut nonce))
        .map_err(text)?;
    let config = Config {
        resources: resources.into(),
        data: data.into(),
        worker: WorkerConfig {
            worker: worker.into(),
            library: library.into(),
            jobs: data.join("native-jobs"),
        },
        nonce: nonce.iter().map(|b| format!("{b:02x}")).collect(),
        picker_dir: std::env::var_os("QUSOR_DYNAMIC_PICKER_DIR").map(PathBuf::from),
    };
    *STATE.lock().map_err(|_| "dynamic state unavailable")? = Some(Arc::new(State {
        config,
        generation: AtomicU64::new(0),
        phase: AtomicU8::new(IDLE),
        has_document: AtomicBool::new(false),
        parser_running: Arc::new(AtomicBool::new(false)),
        frames: FrameScheduler::new()?,
        artifact: Mutex::new(None),
    }));
    Ok(())
}
pub fn shutdown() {
    if let Ok(s) = state() {
        s.generation
            .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |n| n.checked_add(1))
            .ok();
        s.frames.close();
        // Reap cancellation on normal exit; a crash retains the durable marker.
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
        while s.parser_running.load(Ordering::SeqCst) && std::time::Instant::now() < deadline {
            std::thread::sleep(std::time::Duration::from_millis(10));
        }
    }
}
struct Completion<T> {
    value: Option<Result<T>>,
    waker: Option<Waker>,
}
struct Job<T> {
    state: Arc<Mutex<Completion<T>>>,
}
impl<T: Send + 'static> Job<T> {
    fn start(work: impl FnOnce() -> Result<T> + Send + 'static) -> Self {
        let state = Arc::new(Mutex::new(Completion {
            value: None,
            waker: None,
        }));
        let done = state.clone();
        let spawned = std::thread::Builder::new()
            .name("qusor-native-job".into())
            .spawn(move || {
                let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(work))
                    .unwrap_or_else(|_| Err("native background job failed".into()));
                let wake = if let Ok(mut done) = done.lock() {
                    done.value = Some(result);
                    done.waker.take()
                } else {
                    None
                };
                if let Some(wake) = wake {
                    wake.wake();
                }
            });
        if let Err(error) = spawned
            && let Ok(mut done) = state.lock()
        {
            done.value = Some(Err(format!("native job could not start: {error}")));
        }
        Self { state }
    }
}
impl<T> Future for Job<T> {
    type Output = Result<T>;
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        match self.state.lock() {
            Ok(mut state) => match state.value.take() {
                Some(value) => Poll::Ready(value),
                None => {
                    state.waker = Some(cx.waker().clone());
                    Poll::Pending
                }
            },
            Err(_) => Poll::Ready(Err("native completion unavailable".into())),
        }
    }
}
struct ParserSlot(Arc<AtomicBool>);
impl Drop for ParserSlot {
    fn drop(&mut self) {
        self.0.store(false, Ordering::SeqCst);
    }
}
struct FrameTask {
    work: Box<dyn FnOnce() -> Result<FrameFile> + Send>,
    completion: Arc<Mutex<Completion<FrameFile>>>,
}
fn finish_frame(task: FrameTask, run: bool) {
    let result = if run {
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(task.work))
            .unwrap_or_else(|_| Err("native image job failed".into()))
    } else {
        Err("native image request superseded".into())
    };
    let wake = if let Ok(mut done) = task.completion.lock() {
        done.value = Some(result);
        done.waker.take()
    } else {
        None
    };
    if let Some(wake) = wake {
        wake.wake();
    }
}
#[derive(Default)]
struct FrameQueue {
    pending: Option<FrameTask>,
    stopped: bool,
}
struct FrameScheduler(Arc<(Mutex<FrameQueue>, Condvar)>);
impl FrameScheduler {
    fn new() -> Result<Self> {
        let queue = Arc::new((Mutex::new(FrameQueue::default()), Condvar::new()));
        let worker = queue.clone();
        std::thread::Builder::new()
            .name("qusor-native-frame".into())
            .spawn(move || {
                loop {
                    let (lock, wake) = &*worker;
                    let mut queue = match lock.lock() {
                        Ok(queue) => queue,
                        Err(_) => break,
                    };
                    while queue.pending.is_none() && !queue.stopped {
                        queue = match wake.wait(queue) {
                            Ok(queue) => queue,
                            Err(_) => return,
                        };
                    }
                    if queue.stopped {
                        break;
                    }
                    let Some(task) = queue.pending.take() else {
                        continue;
                    };
                    drop(queue);
                    finish_frame(task, true);
                }
            })
            .map_err(text)?;
        Ok(Self(queue))
    }
    fn submit(&self, work: impl FnOnce() -> Result<FrameFile> + Send + 'static) -> Job<FrameFile> {
        let completion = Arc::new(Mutex::new(Completion {
            value: None,
            waker: None,
        }));
        let task = FrameTask {
            work: Box::new(work),
            completion: completion.clone(),
        };
        let (lock, wake) = &*self.0;
        let mut queue = match lock.lock() {
            Ok(queue) => queue,
            Err(_) => {
                finish_frame(task, false);
                return Job { state: completion };
            }
        };
        if queue.stopped {
            drop(queue);
            finish_frame(task, false);
            return Job { state: completion };
        }
        let previous = queue.pending.replace(task);
        drop(queue);
        wake.notify_one();
        if let Some(previous) = previous {
            finish_frame(previous, false);
        }
        Job { state: completion }
    }
    fn close(&self) {
        let (lock, wake) = &*self.0;
        if let Ok(mut queue) = lock.lock() {
            queue.stopped = true;
            let previous = queue.pending.take();
            drop(queue);
            wake.notify_one();
            if let Some(previous) = previous {
                finish_frame(previous, false);
            }
        }
    }
}
impl Drop for FrameScheduler {
    fn drop(&mut self) {
        self.close();
    }
}
fn envelope(value: Value) -> String {
    json!({"ok":true,"value":value}).to_string()
}
fn failure(error: String) -> String {
    eprintln!("DYNAMIC_FAILURE {error}");
    json!({"ok":false,"error":error}).to_string()
}
impl State {
    fn settled(&self) -> u8 {
        if self.has_document.load(Ordering::SeqCst) {
            READY
        } else {
            IDLE
        }
    }
    fn begin(&self) -> Result<u64> {
        loop {
            let phase = self.phase.load(Ordering::SeqCst);
            if phase != IDLE && phase != READY {
                return Err("an import or save is still active".into());
            }
            if self
                .phase
                .compare_exchange(phase, PICKING, Ordering::SeqCst, Ordering::SeqCst)
                .is_ok()
            {
                break;
            }
        }
        match self
            .generation
            .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |n| {
                n.checked_add(1).filter(|next| *next < u64::MAX)
            }) {
            Ok(n) => Ok(n + 1),
            Err(_) => {
                self.phase.store(self.settled(), Ordering::SeqCst);
                Err("native job sequence exhausted".into())
            }
        }
    }
    fn current(&self, job: u64) -> Result<()> {
        if self.generation.load(Ordering::SeqCst) == job {
            Ok(())
        } else {
            Err("import cancelled or superseded".into())
        }
    }
}
#[derive(Clone)]
pub struct FrameFile {
    info: Value,
    image: ImageData,
}
impl JsValue for FrameFile {
    fn ts_type(types: &mut TsTypes) -> String {
        types.declare("DynamicPdfFrame", |_| {
            "export interface DynamicPdfFrame { info: string; file: File; }".into()
        })
    }
    fn from_js(value: JsIn<'_>) -> std::result::Result<Self, PropError> {
        Err(value.expected("native frame output only"))
    }
    fn to_js<'a>(&self, host: &'a dyn JsHost) -> std::result::Result<JsOwned<'a>, PropError> {
        let owned = JsOwned::new(host, host.new_object()?);
        let object = owned.get().raw();
        host.set_field(object, "info", host.new_string(&self.info.to_string())?)?;
        host.set_field(
            object,
            "file",
            host.new_file(&self.image, "image/png", "native-page.png", None)?,
        )?;
        Ok(owned)
    }
}
#[module]
pub struct DynamicReader;
#[module]
impl DynamicReader {
    pub fn choose() -> Later<String> {
        Later::new(async {
            let result = async {
                let s = state()?;
                let job = s.begin()?;
                let mut dialog = OpenDialog::files()
                    .filter(FileFilter::new("PDF", ["pdf"]))
                    .title("打开本地 PDF")
                    .button_label("打开");
                if let Some(directory) = &s.config.picker_dir {
                    dialog.directory = Some(directory.clone());
                }
                let picked = match pick_paths(dialog).await {
                    Ok(value) => value,
                    Err(error) => {
                        if s.generation.load(Ordering::SeqCst) == job {
                            s.phase.store(s.settled(), Ordering::SeqCst);
                        }
                        return Err(text(error));
                    }
                };
                s.current(job)?;
                let Some(paths) = picked else {
                    s.phase.store(s.settled(), Ordering::SeqCst);
                    eprintln!("DYNAMIC_PICK_CANCELLED {job}");
                    return Ok(envelope(json!({"cancelled":true})));
                };
                let path = match paths.into_iter().next() {
                    Some(path) => path,
                    None => {
                        s.phase.store(s.settled(), Ordering::SeqCst);
                        return Err("no file was chosen".into());
                    }
                };
                s.phase.store(PARSING, Ordering::SeqCst);
                let background = s.clone();
                let outcome = if s
                    .parser_running
                    .compare_exchange(false, true, Ordering::SeqCst, Ordering::SeqCst)
                    .is_err()
                {
                    Err(
                        "previous native read has not finished; no replacement parser started"
                            .into(),
                    )
                } else {
                    let slot = ParserSlot(background.parser_running.clone());
                    Job::start(move || {
                        let _slot = slot;
                        let (prepared, artifact) = dynamic_worker::inspect(
                            &background.config.worker,
                            &path,
                            job,
                            &background.generation,
                            &background.config.nonce,
                        )?;
                        background.current(job)?;
                        background
                            .phase
                            .compare_exchange(
                                PARSING,
                                COMMITTING,
                                Ordering::SeqCst,
                                Ordering::SeqCst,
                            )
                            .map_err(|_| "import was cancelled before commit")?;
                        let initialization = plugin_surface::initialize_document_checked(
                            &background.config.resources,
                            &background.config.data,
                            prepared,
                        )?;
                        let digest = artifact.report_digest.clone();
                        *background
                            .artifact
                            .lock()
                            .map_err(|_| "native artifact state unavailable")? = Some(artifact);
                        background.has_document.store(true, Ordering::SeqCst);
                        if let plugin_surface::DocumentInitialization::ImportedUnavailable {
                            message,
                        } = initialization
                        {
                            eprintln!("DYNAMIC_IMPORTED_AUTHORITY_UNAVAILABLE {message}");
                            return Ok(envelope(
                                json!({"imported":true,"opened":false,"error":message}),
                            ));
                        }
                        let opened: Value =
                            serde_json::from_str(&ReaderSurface::open(digest)).map_err(text)?;
                        if opened["ok"] != true {
                            eprintln!("DYNAMIC_IMPORTED_READER_UNAVAILABLE {}", opened);
                            return Ok(envelope(
                                json!({"imported":true,"opened":false,"error":opened["error"]}),
                            ));
                        }
                        eprintln!("DYNAMIC_IMPORTED {}", opened["value"]);
                        Ok(envelope(opened["value"].clone()))
                    })
                    .await
                };
                if s.generation.load(Ordering::SeqCst) == job {
                    s.phase.store(s.settled(), Ordering::SeqCst);
                }
                outcome
            }
            .await;
            Ok::<String, String>(match result {
                Ok(value) => value,
                Err(error) => failure(error),
            })
        })
    }
    pub fn reopen() -> Later<String> {
        Later::new(async {
            let s = state()?;
            s.phase
                .compare_exchange(READY, COMMITTING, Ordering::SeqCst, Ordering::SeqCst)
                .map_err(|_| "another operation is active")?;
            let outcome = Job::start(move || {
                Ok(ReaderSurface::open(plugin_surface::current_report_digest()?))
            })
            .await;
            s.phase.store(s.settled(), Ordering::SeqCst);
            outcome
        })
    }
    pub fn cancel() -> String {
        match state() {
            Ok(s) => {
                if s.phase
                    .compare_exchange(PARSING, s.settled(), Ordering::SeqCst, Ordering::SeqCst)
                    .is_ok()
                {
                    if s.generation
                        .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |n| n.checked_add(1))
                        .is_err()
                    {
                        return failure("native job sequence exhausted".into());
                    }
                    envelope(json!({"cancelled":true}))
                } else {
                    envelope(
                        json!({"cancelled":false,"committing":s.phase.load(Ordering::SeqCst)==COMMITTING}),
                    )
                }
            }
            Err(error) => failure(error),
        }
    }
    pub fn frame(handle: String, generation: u64, frame_id: String) -> Later<FrameFile> {
        Later::new(async move {
            let context = plugin_surface::native_frame_context(&handle, generation, &frame_id)?;
            if context.config["handle"] != handle
                || context.config["generation"] != generation
                || context.config["frame_id"] != frame_id
            {
                return Err("stale native frame metadata".into());
            }
            let s = state()?;
            let artifact = s
                .artifact
                .lock()
                .map_err(|_| "native artifact unavailable")?
                .clone()
                .ok_or("native artifact unavailable")?;
            if artifact.report_digest != context.report_digest
                || artifact.report.original_sha256 != context.report.original_sha256
            {
                return Err("native frame source mismatch".into());
            }
            s.frames
                .submit(move || {
                    let start =
                        plugin_surface::native_frame_context(&handle, generation, &frame_id)?;
                    if start.report_digest != context.report_digest
                        || start.config["frame_id"] != frame_id
                    {
                        return Err("native image request superseded".into());
                    }
                    let bytes = dynamic_worker::png(&artifact, context.page_index)?;
                    let fresh =
                        plugin_surface::native_frame_context(&handle, generation, &frame_id)?;
                    if fresh.report_digest != context.report_digest
                        || fresh.config["document_id"] != context.config["document_id"]
                        || fresh.config["handle"] != handle
                        || fresh.config["generation"] != generation
                        || fresh.config["frame_id"] != frame_id
                    {
                        return Err("late native image belongs to an old document".into());
                    }
                    eprintln!("DYNAMIC_FRAME {}", context.config);
                    let mut info = context.config;
                    info["text_status"] =
                        json!(artifact.report.pages[context.page_index].text_status);
                    Ok(FrameFile {
                        info,
                        image: ImageData::new(bytes),
                    })
                })
                .await
        })
    }
    pub fn save(candidate: String, note: String) -> Later<String> {
        Later::new(async move {
            let s = state()?;
            s.phase
                .compare_exchange(READY, COMMITTING, Ordering::SeqCst, Ordering::SeqCst)
                .map_err(|_| "import or save is still active")?;
            let value = Job::start(move || Ok(ReaderSurface::save(candidate, note))).await;
            s.phase.store(s.settled(), Ordering::SeqCst);
            value
        })
    }
}

#[cfg(test)]
mod dynamic_tests {
    use super::*;

    #[test]
    fn frame_queue_keeps_only_latest_pending_request() {
        let scheduler = FrameScheduler::new().unwrap();
        let (entered_tx, entered_rx) = std::sync::mpsc::channel();
        let (release_tx, release_rx) = std::sync::mpsc::channel();
        let first = scheduler.submit(move || {
            entered_tx.send(()).unwrap();
            release_rx.recv().unwrap();
            Err("first completed".into())
        });
        entered_rx
            .recv_timeout(std::time::Duration::from_secs(2))
            .unwrap();
        let executed = Arc::new(AtomicU64::new(0));
        let stale_count = executed.clone();
        let stale = scheduler.submit(move || {
            stale_count.fetch_add(100, Ordering::SeqCst);
            Err("stale ran".into())
        });
        let latest_count = executed.clone();
        let (done_tx, done_rx) = std::sync::mpsc::channel();
        let latest = scheduler.submit(move || {
            latest_count.fetch_add(1, Ordering::SeqCst);
            done_tx.send(()).unwrap();
            Err("latest completed".into())
        });
        assert!(stale.state.lock().unwrap().value.as_ref().unwrap().is_err());
        release_tx.send(()).unwrap();
        done_rx
            .recv_timeout(std::time::Duration::from_secs(2))
            .unwrap();
        assert_eq!(executed.load(Ordering::SeqCst), 1);
        scheduler.close();
        drop((first, latest));
    }
}
