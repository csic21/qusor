//! Native dynamic-document qualification composition. No fixture import at startup.
fn main() -> std::process::ExitCode {
    let args = std::env::args().collect::<Vec<_>>();
    if args.get(1).is_some_and(|arg| arg == "--managed-worker") {
        return qusor_nsh_native_host_probe::dynamic_worker::managed_main(&args[2..]);
    }
    let variable = |name| {
        std::env::var_os(name)
            .map(std::path::PathBuf::from)
            .ok_or_else(|| format!("{name} is required"))
    };
    let configured = (|| {
        let resources = variable("QUSOR_READER_RESOURCES")?;
        let data = variable("QUSOR_READER_DATA")?;
        let worker = std::env::current_exe().map_err(|e| e.to_string())?;
        let library = variable("QUSOR_PDF_LIBRARY")?;
        qusor_nsh_native_host_probe::dynamic_module::initialize(
            &resources, &data, &worker, &library,
        )
    })();
    if let Err(error) = configured {
        eprintln!("dynamic initialization failed: {error}");
        return std::process::ExitCode::FAILURE;
    }
    nsh_platform_linux::set_ui_sets(vec![
        nsh_base::registry(),
        qusor_nsh_native_host_probe::__nsh_native_module(),
    ]);
    let code = nsh_linux_host::main();
    qusor_nsh_native_host_probe::dynamic_module::shutdown();
    if let Err(error) = qusor_nsh_native_host_probe::plugin_surface::shutdown() {
        eprintln!("dynamic shutdown failed: {error}");
        return std::process::ExitCode::FAILURE;
    }
    code
}
