//! Immutable application source facts, never a plugin authorization or Surface lease.
use crate::KnowledgeApplication;
use core_api::{
    knowledge::{
        KnowledgeError, KnowledgeErrorCode, PdfReceipt, Provenance, Result, validate_native,
    },
    pdf_contract::{PdfDraft, resolve_pdf},
};
use learning_ports::KnowledgeStore;

/// A source checked against Core before the selection's transient lease expires.
/// The trusted caller must check current capture authority again before `capture`.
/// No session, permit, renderer position, or editable source fields are retained.
#[derive(Debug)]
pub struct FrozenPdfSource {
    document_id: i64,
    vault: String,
    selection: PdfDraft,
    provenance: Provenance,
}

impl FrozenPdfSource {
    /// Call under the same trusted selection/authority gate as the freeze intent.
    /// Core checks content; this method does not authenticate a plugin identity.
    pub fn freeze<S: KnowledgeStore>(
        app: &KnowledgeApplication<S>,
        document_id: i64,
        vault: &str,
        selection: PdfDraft,
        provenance: Provenance,
    ) -> Result<Self> {
        validate_native("annotation-freeze", vault, &provenance, "")?;
        let document = app.query_document(document_id)?;
        if document.vault != vault {
            return conflict("annotation source belongs to another vault");
        }
        resolve_pdf(&document.snapshot, &selection)?;
        Ok(Self {
            document_id,
            vault: vault.into(),
            selection,
            provenance,
        })
    }

    pub fn vault(&self) -> &str {
        &self.vault
    }
    pub fn document_id(&self) -> i64 {
        self.document_id
    }
    pub fn selection(&self) -> &PdfDraft {
        &self.selection
    }
    pub fn provenance(&self) -> &Provenance {
        &self.provenance
    }

    /// Requires fresh Host authorization for the original capture installation.
    /// The existing Core transaction rechecks exact source and operation identity.
    pub fn capture<S: KnowledgeStore>(
        &self,
        app: &mut KnowledgeApplication<S>,
        operation_id: &str,
        note: &str,
    ) -> Result<PdfReceipt> {
        let document = app.query_document(self.document_id)?;
        if document.vault != self.vault {
            return conflict("annotation source vault changed");
        }
        app.capture_pdf(
            operation_id,
            self.document_id,
            &self.selection,
            &self.provenance,
            note,
        )
    }

    /// Trusted read-only reconciliation of a previously frozen save payload.
    /// No save permission is required to discover an already committed result.
    /// `None` means no operation exists in this consistent Core snapshot; it is
    /// not permission to invent another operation or unlock a pending upload.
    pub fn receipt<S: KnowledgeStore>(
        &self,
        app: &KnowledgeApplication<S>,
        operation_id: &str,
        note: &str,
    ) -> Result<Option<PdfReceipt>> {
        validate_native(operation_id, &self.vault, &self.provenance, note)?;
        // One consistent snapshot avoids mixing an absent receipt with a later
        // operation lookup. Core validates all archive relationships first.
        let archive = app.export_all()?;
        if let Some(record) = archive
            .pdf_captures
            .iter()
            .find(|record| record.receipt.operation_id == operation_id)
        {
            let document = archive
                .pdf_documents
                .iter()
                .find(|document| document.receipt.document_id == self.document_id);
            if record.receipt.document_id != self.document_id
                || record.draft != self.selection
                || record.compound.is_some()
                || record.provenance != self.provenance
                || record.user_note != note
                || document.is_none_or(|document| document.vault != self.vault)
            {
                return conflict("annotation receipt belongs to a different payload");
            }
            return Ok(Some(record.receipt.clone()));
        }
        if archive
            .commits
            .iter()
            .any(|commit| commit.operation_id == operation_id)
        {
            return conflict("annotation operation belongs to another kind");
        }
        Ok(None)
    }
}
fn conflict<T>(message: &'static str) -> Result<T> {
    Err(KnowledgeError::new(KnowledgeErrorCode::Conflict, message))
}
