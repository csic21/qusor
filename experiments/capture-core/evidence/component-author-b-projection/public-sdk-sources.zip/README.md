# Capture experimental public SDK

Capture/anchor subset (contract, pdf_contract, pdf_compound) exported from core-api; knowledge storage envelopes/ports are excluded. Package format/signer comes from crates/extension-package.
No Host, Core, database or Wasm runtime implementation is included.
api/schema contains the authoritative 0.1/0.2/0.3 policy, Surface, Draft, Composition, Component Invocation, Context, Continuation and Paragraph Projection schemas; parsing does not grant authority.
This is a validation artifact, not a production SDK release.
