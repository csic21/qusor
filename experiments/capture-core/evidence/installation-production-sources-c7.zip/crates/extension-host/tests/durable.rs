use extension_api::*;
use extension_host::{Grant, durable::*};
use std::cell::RefCell;
use std::collections::BTreeMap;

struct Journal(RefCell<BTreeMap<String, AuthoritySnapshot>>);
impl AuthoritySource for Journal {
    fn authority_snapshot(
        &self,
        package: &str,
        _: AuthorityRead<'_>,
    ) -> Result<AuthoritySnapshot, ApiError> {
        self.0
            .borrow()
            .get(package)
            .cloned()
            .ok_or_else(|| ApiError::new(ErrorCode::NotFound, "record unavailable"))
    }
}
fn snapshot(id: i64, package: &str) -> AuthoritySnapshot {
    AuthoritySnapshot {
        installation_id: id,
        revision: 2,
        generation: 2,
        digest: "a".repeat(64),
        vault_id: "vault".into(),
        enable_intent: true,
        manifest: Manifest {
            manifest_version: 1,
            package_id: package.into(),
            publisher_id: "org.example".into(),
            package_version: PackageVersion {
                major: 1,
                minor: 0,
                patch: 0,
            },
            host_api: ApiRange {
                major: 0,
                min_minor: 1,
                max_minor: 2,
            },
            required_capabilities: vec![Capability::DocumentMetadataRead],
            optional_capabilities: vec![],
            contributions: vec![],
        },
        grants: vec![DurableGrant {
            grant: Grant {
                capability: Capability::DocumentMetadataRead,
                resource: Resource::Document {
                    vault_id: "vault".into(),
                    document_id: "doc".into(),
                },
            },
            expires_at: 100,
            resource_version: Some("v1".into()),
        }],
    }
}
fn journal() -> Journal {
    Journal(RefCell::new(
        [
            ("org.example.a".into(), snapshot(1, "org.example.a")),
            ("org.example.b".into(), snapshot(2, "org.example.b")),
        ]
        .into(),
    ))
}
fn host() -> DurableHost {
    DurableHost::new("vault", [Capability::DocumentMetadataRead]).unwrap()
}
fn request(api: ApiVersion) -> VersionedRequest {
    VersionedRequest {
        resource_version: Some("v1".into()),
        request: CapabilityRequest {
            api_version: api,
            request_id: "read".into(),
            capability: Capability::DocumentMetadataRead,
            resource: Resource::Document {
                vault_id: "vault".into(),
                document_id: "doc".into(),
            },
        },
    }
}

#[test]
fn one_host_restores_two_packages_with_explicit_versions_and_fresh_sessions() {
    let source = journal();
    let mut h = host();
    let a = h.activate(&source, "org.example.a", HOST_API, 1).unwrap();
    let b = h
        .activate(&source, "org.example.b", HOST_API_V0_2, 1)
        .unwrap();
    assert_eq!(
        h.dispatch(&source, &a, 2, None, request(HOST_API), |c| Ok(c
            .package_id
            .clone()))
            .unwrap(),
        "org.example.a"
    );
    assert_eq!(
        h.dispatch(&source, &b, 2, None, request(HOST_API_V0_2), |c| Ok(c
            .package_id
            .clone()))
            .unwrap(),
        "org.example.b"
    );
    assert!(
        h.dispatch(&source, &a, 2, None, request(HOST_API_V0_2), must_not_run)
            .is_err()
    );
    let mut restarted = host();
    assert!(
        restarted
            .dispatch(&source, &a, 2, None, request(HOST_API), must_not_run)
            .is_err()
    );
    let fresh = restarted
        .activate(&source, "org.example.a", HOST_API, 3)
        .unwrap();
    assert!(
        restarted
            .dispatch(&source, &fresh, 3, None, request(HOST_API), |_| Ok(()))
            .is_ok()
    );
}

#[test]
fn changed_or_unreadable_durable_state_fences_only_that_package() {
    for change in [
        "generation",
        "digest",
        "manifest",
        "scope",
        "missing",
        "intent",
    ] {
        let source = journal();
        let mut h = host();
        let a = h.activate(&source, "org.example.a", HOST_API, 1).unwrap();
        let b = h.activate(&source, "org.example.b", HOST_API, 1).unwrap();
        let old = source.0.borrow()["org.example.a"].clone();
        {
            let mut records = source.0.borrow_mut();
            let item = records.get_mut("org.example.a").unwrap();
            match change {
                "generation" => item.generation += 1,
                "digest" => item.digest = "b".repeat(64),
                "manifest" => item.manifest.package_version.patch += 1,
                "scope" => {
                    item.grants[0].grant.resource = Resource::Vault {
                        vault_id: "vault".into(),
                    }
                }
                "intent" => item.enable_intent = false,
                "missing" => {
                    records.remove("org.example.a");
                }
                _ => unreachable!(),
            }
        }
        assert!(
            h.dispatch(&source, &a, 2, None, request(HOST_API), must_not_run)
                .is_err(),
            "{change}"
        );
        source.0.borrow_mut().insert("org.example.a".into(), old);
        assert!(
            h.dispatch(&source, &a, 2, None, request(HOST_API), must_not_run)
                .is_err()
        );
        assert!(
            h.dispatch(&source, &b, 2, None, request(HOST_API), |_| Ok(()))
                .is_ok()
        );
    }
}

#[test]
fn failed_reactivation_expiry_and_identity_alias_do_not_resurrect_authority() {
    let source = journal();
    let mut h = host();
    let a = h.activate(&source, "org.example.a", HOST_API, 1).unwrap();
    assert!(
        h.activate(
            &source,
            "org.example.a",
            ApiVersion {
                major: 0,
                minor: 99
            },
            2
        )
        .is_err()
    );
    assert!(
        h.dispatch(&source, &a, 2, None, request(HOST_API), must_not_run)
            .is_err()
    );
    let a = h.activate(&source, "org.example.a", HOST_API, 3).unwrap();
    assert!(
        h.dispatch(&source, &a, 100, None, request(HOST_API), must_not_run)
            .is_err()
    );
    assert!(
        h.activate(&source, "org.example.a", HOST_API, 1).is_err(),
        "clock rollback must not revive intent"
    );
    let mut h = host();
    let a = h.activate(&source, "org.example.a", HOST_API, 1).unwrap();
    source
        .0
        .borrow_mut()
        .get_mut("org.example.b")
        .unwrap()
        .installation_id = 1;
    assert!(h.activate(&source, "org.example.b", HOST_API, 1).is_err());
    assert!(
        h.dispatch(&source, &a, 2, None, request(HOST_API), |_| Ok(()))
            .is_ok()
    );
}

#[test]
fn precommit_validation_uses_same_policy_and_does_not_publish_a_session() {
    let source = journal();
    let mut h = host();
    let record = source.0.borrow()["org.example.a"].clone();
    let grants: Vec<_> = record.grants.iter().map(|g| g.grant.clone()).collect();
    h.validate_activation_intent(&record.manifest, &record.digest, &grants, HOST_API)
        .unwrap();
    assert!(
        h.validate_activation_intent(&record.manifest, &record.digest, &[], HOST_API)
            .is_err()
    );
    let mut bad = grants;
    bad[0].resource = Resource::Document {
        vault_id: "other".into(),
        document_id: "doc".into(),
    };
    assert!(
        h.validate_activation_intent(&record.manifest, &record.digest, &bad, HOST_API)
            .is_err()
    );
    let a = h.activate(&source, "org.example.a", HOST_API, 1).unwrap();
    h.close(&a).unwrap();
    assert!(
        h.dispatch(&source, &a, 2, None, request(HOST_API), must_not_run)
            .is_err()
    );
}

#[test]
fn durable_exact_version_needs_the_current_host_resolved_version() {
    let source = journal();
    let mut h = host();
    let a = h.activate(&source, "org.example.a", HOST_API, 1).unwrap();
    for version in [None, Some("v2".into())] {
        let mut call = request(HOST_API);
        call.resource_version = version;
        assert!(
            h.dispatch(&source, &a, 2, None, call, must_not_run)
                .is_err()
        );
    }
    assert!(
        h.dispatch(&source, &a, 2, None, request(HOST_API), |_| Ok(()))
            .is_ok()
    );
}

#[test]
fn negotiated_api_rejects_grant_semantics_from_a_newer_version() {
    let source = journal();
    {
        let mut records = source.0.borrow_mut();
        let record = records.get_mut("org.example.a").unwrap();
        record.manifest.required_capabilities = vec![Capability::SelectionRead];
        record.grants[0].grant.capability = Capability::SelectionRead;
    }
    let mut h = DurableHost::new("vault", [Capability::SelectionRead]).unwrap();
    let record = source.0.borrow()["org.example.a"].clone();
    let grants = vec![record.grants[0].grant.clone()];
    assert!(
        h.validate_activation_intent(&record.manifest, &record.digest, &grants, HOST_API)
            .is_err()
    );
    assert!(h.activate(&source, "org.example.a", HOST_API, 1).is_err());
    assert!(
        h.activate(&source, "org.example.a", HOST_API_V0_2, 1)
            .is_ok()
    );
}

fn must_not_run(_: &extension_host::AuthorizedContext) -> Result<(), ApiError> {
    panic!("rejected durable authority reached service")
}
