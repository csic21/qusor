//! Restore durable intent into one live policy Host. Records never restore sessions.
//!
//! The trusted caller serializes journal mutations, Core version resolution and
//! the actual handler read/commit in this same dispatch gate or consistent snapshot. The source
//! must re-read current durable facts, not return a cached activation snapshot.
use crate::{Grant, Host, InstallationId, Session};
use extension_api::{ApiError, ApiVersion, Capability, CapabilityRequest, ErrorCode, Manifest};
use std::collections::BTreeMap;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DurableGrant {
    pub grant: Grant,
    pub expires_at: u64,
    /// Preserved durable source/version constraint; None means explicitly unversioned.
    pub resource_version: Option<String>,
}

/// Host-resolved current version, not a version self-reported by the guest.
/// Resolve it under the same gate/snapshot as the handler's actual data access.
pub struct VersionedRequest {
    pub request: CapabilityRequest,
    pub resource_version: Option<String>,
}

/// Trusted storage facts, not a permit. The verifier/source owns byte authentication.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AuthoritySnapshot {
    pub installation_id: i64,
    pub revision: i64,
    pub generation: i64,
    pub manifest: Manifest,
    pub digest: String,
    pub vault_id: String,
    pub enable_intent: bool,
    pub grants: Vec<DurableGrant>,
}

#[derive(Debug, Clone, Copy)]
pub enum AuthorityRead<'a> {
    /// May perform bounded private-state preflight, before a VM invocation starts.
    Activation,
    /// No guest execution or provider I/O in the per-message authorization gate.
    Current { run_id: Option<&'a str> },
}

/// Implemented by trusted durable infrastructure. Neither method grants a capability.
pub trait AuthoritySource {
    fn authority_snapshot(
        &self,
        package_id: &str,
        read: AuthorityRead<'_>,
    ) -> Result<AuthoritySnapshot, ApiError>;
}

/// Host-only handle. No wire deserialization and no old process session resurrection.
#[derive(Debug, Clone)]
pub struct DurableSession {
    installation: InstallationId,
    persistent_id: i64,
    package_id: String,
    session: Session,
}

struct Binding {
    installation: InstallationId,
    snapshot: AuthoritySnapshot,
}

/// One vault, one Host, many restored packages; storage has no parallel policy Host.
pub struct DurableHost {
    host: Host,
    vault_id: String,
    bindings: BTreeMap<i64, Binding>,
    last_time: u64,
}

fn denied(message: &'static str) -> ApiError {
    ApiError::new(ErrorCode::PermissionDenied, message)
}

impl DurableHost {
    pub fn new(
        vault_id: impl Into<String>,
        supported: impl IntoIterator<Item = Capability>,
    ) -> Result<Self, ApiError> {
        let vault_id = vault_id.into();
        Ok(Self {
            host: Host::new(vault_id.clone(), supported)?,
            vault_id,
            bindings: BTreeMap::new(),
            last_time: 0,
        })
    }

    /// Check a proposed durable grant against this actual Host, without enabling it
    /// or issuing a session before the journal commits the user's intent.
    pub fn validate_activation_intent(
        &self,
        manifest: &Manifest,
        digest: &str,
        grants: &[Grant],
        api: ApiVersion,
    ) -> Result<(), ApiError> {
        self.host.validate_package(manifest, digest)?;
        self.host.validate_grants(manifest, grants)?;
        if !extension_api::is_supported_api(api) || !manifest.supports_api(api) {
            return Err(ApiError::new(
                ErrorCode::UnsupportedVersion,
                "activation API is unsupported",
            ));
        }
        if grants
            .iter()
            .any(|g| !extension_api::capability_resource_valid(g.capability, &g.resource, api))
        {
            return Err(denied("durable grant requires another negotiated API"));
        }
        if !crate::required_granted(manifest, grants) {
            return Err(denied("required capabilities need explicit grants"));
        }
        Ok(())
    }

    fn time(&mut self, now: u64) -> u64 {
        self.last_time = self.last_time.max(now);
        self.last_time
    }

    fn valid(&self, snapshot: &AuthoritySnapshot, package: &str, now: u64) -> bool {
        snapshot.installation_id > 0
            && snapshot.revision > 0
            && snapshot.generation > 0
            && snapshot.manifest.package_id == package
            && snapshot.vault_id == self.vault_id
            && snapshot.enable_intent
            && snapshot.grants.iter().all(|g| g.expires_at > now)
    }

    fn remove(&mut self, id: i64) {
        if let Some(binding) = self.bindings.remove(&id) {
            let _ = self.host.unregister(binding.installation);
        }
    }

    pub fn activate(
        &mut self,
        source: &dyn AuthoritySource,
        package_id: &str,
        api: ApiVersion,
        now: u64,
    ) -> Result<DurableSession, ApiError> {
        // Even a failed reactivation cannot leave the old package session active.
        let previous = self.bindings.iter().find_map(|(id, binding)| {
            (binding.snapshot.manifest.package_id == package_id).then_some(*id)
        });
        if let Some(id) = previous {
            self.remove(id);
        }
        let now = self.time(now);
        let snapshot = source.authority_snapshot(package_id, AuthorityRead::Activation)?;
        if !self.valid(&snapshot, package_id, now) {
            return Err(denied("durable activation intent is invalid or expired"));
        }
        if self.bindings.contains_key(&snapshot.installation_id) {
            return Err(denied(
                "durable installation identity aliases another package",
            ));
        }
        self.validate_activation_intent(
            &snapshot.manifest,
            &snapshot.digest,
            &snapshot
                .grants
                .iter()
                .map(|g| g.grant.clone())
                .collect::<Vec<_>>(),
            api,
        )?;
        let installation = self
            .host
            .register(snapshot.manifest.clone(), &snapshot.digest)?;
        let result = (|| {
            self.host.replace_grants(
                installation,
                snapshot.grants.iter().map(|g| g.grant.clone()).collect(),
            )?;
            self.host.enable(installation)?;
            self.host.open_session_for_api(installation, api)
        })();
        let session = match result {
            Ok(session) => session,
            Err(error) => {
                let _ = self.host.unregister(installation);
                return Err(error);
            }
        };
        let persistent_id = snapshot.installation_id;
        self.bindings.insert(
            persistent_id,
            Binding {
                installation,
                snapshot,
            },
        );
        Ok(DurableSession {
            installation,
            persistent_id,
            package_id: package_id.into(),
            session,
        })
    }

    /// Re-read durable state, then authorize and dispatch within the caller's shared gate.
    /// A run id comes only from the trusted process controller, never from guest JSON.
    pub fn dispatch<T>(
        &mut self,
        source: &dyn AuthoritySource,
        session: &DurableSession,
        now: u64,
        run_id: Option<&str>,
        request: VersionedRequest,
        handler: impl FnOnce(&crate::AuthorizedContext) -> Result<T, ApiError>,
    ) -> Result<T, ApiError> {
        let binding = self
            .bindings
            .get(&session.persistent_id)
            .filter(|b| b.installation == session.installation)
            .ok_or_else(|| denied("unknown or stale durable session"))?;
        let expected = binding.snapshot.clone();
        let now = self.time(now);
        let fresh =
            source.authority_snapshot(&session.package_id, AuthorityRead::Current { run_id });
        match fresh {
            Ok(snapshot)
                if snapshot == expected && self.valid(&snapshot, &session.package_id, now) => {}
            _ => {
                self.remove(session.persistent_id);
                return Err(denied("durable authority changed or is unavailable"));
            }
        }
        if !expected.grants.iter().any(|grant| {
            crate::covers(&grant.grant, &request.request)
                && grant
                    .resource_version
                    .as_ref()
                    .is_none_or(|version| request.resource_version.as_ref() == Some(version))
        }) {
            return Err(denied(
                "current resource version differs from durable grant",
            ));
        }
        let permit = self.host.authorize(&session.session, request.request)?;
        self.host.dispatch(permit, handler)
    }

    pub fn close(&mut self, session: &DurableSession) -> Result<(), ApiError> {
        let binding = self
            .bindings
            .get(&session.persistent_id)
            .filter(|b| b.installation == session.installation)
            .ok_or_else(|| denied("unknown or stale durable session"))?;
        self.host.close_session(&session.session)?;
        let id = binding.installation;
        self.bindings.remove(&session.persistent_id);
        self.host.unregister(id)
    }
}
