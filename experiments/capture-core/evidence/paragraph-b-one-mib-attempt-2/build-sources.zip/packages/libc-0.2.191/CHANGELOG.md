# Changelog

## [0.2.191](https://github.com/rust-lang/libc/compare/0.2.190...0.2.191) - 2026-10-16

### Support

- Emscripten: Support v4.0.12 to v6.0.11 ([#5610](https://github.com/rust-lang/libc/pull/5610))

### Added

- Apple: Add `F_SETNOSIGPIPE` and `F_GETNOSIGPIPE` ([#5609](https://github.com/rust-lang/libc/pull/5609))
- Apple: add `ifaliasreq` and `in6_aliasreq` ([#5557](https://github.com/rust-lang/libc/pull/5557))
- FreeBSD: Add `PT_*` constants ([#5625](https://github.com/rust-lang/libc/pull/5625))
- Haiku: Add `AI_*` and `NI_*` constants from netdb.h ([#5585](https://github.com/rust-lang/libc/pull/5585))
- Hurd: Add `POSIX_SPAWN_*` flags ([#5578](https://github.com/rust-lang/libc/pull/5578))
- NuttX: Add `AT_SYMLINK_NOFOLLOW` ([#5614](https://github.com/rust-lang/libc/pull/5614))
- OpenBSD: Add `sensordev` ([#5534](https://github.com/rust-lang/libc/pull/5534))
- QuRT: Add `isatty` ([#5618](https://github.com/rust-lang/libc/pull/5618))
- WASI: Add `pthread_condattr_{get,set}clock` ([#5626](https://github.com/rust-lang/libc/pull/5626))

### Fixed

- FreeBSD-aarch64: Fix `gpregs` and `fpregs` ([#5603](https://github.com/rust-lang/libc/pull/5603))

### Changed

- AIX: Restore 'c_ulong' as the type of 'statvfs.f_fsid'. ([#5616](https://github.com/rust-lang/libc/pull/5616))
- Android: Make `prop_info` an extern type ([#5561](https://github.com/rust-lang/libc/pull/5561))
- Apple: Mach API is now available on non-MacOS targets again. This should resolve some issues building ecosystem crates. ([#5612](https://github.com/rust-lang/libc/pulls/5612)), ([#5636](https://github.com/rust-lang/libc/pull/5636))
- FreeBSD: Add back `NOTE_PCTRLMASK` with a deprecation warning ([#5600](https://github.com/rust-lang/libc/pull/5600))


## [0.2.190](https://github.com/rust-lang/libc/compare/0.2.189...0.2.190) - 2026-10-02

There is now a single config for enabling 64-bit `time_t`: `libc_unstable_time64`. This can be set
unconditionally; it opts in to 64-bit `time_t` on the following platforms that use 32-bit by
default:

* 32-bit Linux-GNU
* 32-bit Linux-uClibc
* 32-bit Linux-musl. Note that setting this flag also enables some other changes that happend in
  musl v1.2.
* 32-bit Windows-GNU
* ESP-IDF (all targets with this environment are 32-bit)

Most other 32-bit platforms are either already using 64-bit `time_t`, or are considered legacy
and will not be gaining support from their upstream maintainers.

You can enable this using `RUSTFLAGS`:

```sh
RUSTFLAGS='--cfg=libc_unstable_time64' cargo ...
```

Note that there may still be some changes to features gated by this config option, hence "unstable"
in its name. In the near future we will rename it to just `libc_time64`. Until then, please test it
out and report any bugs you find!

### Support

- Add initial support for HelenOS ([#4355](https://github.com/rust-lang/libc/pull/4355))

### Added

We are slowly filling out the `Default` implementations, to reduce the need for `mem::zeroed()` in user code:

- Unix: Implement `Default` for a number of structs, especially on Apple platforms ([#5576](https://github.com/rust-lang/libc/pull/5576))
- Linux, NetBSD: Give `statvfs` a `Default` impl ([#5583](https://github.com/rust-lang/libc/pull/5583))
- Linux: Add `Default` to a `linux/can.rs` structs ([#5257](https://github.com/rust-lang/libc/pull/5257))

Other additions:

- Expose the `libc_unstable_time64` cfg ([#5411](https://github.com/rust-lang/libc/pull/5411))
- Android, Glibc: Add `pthread_gettid_np` ([#5359](https://github.com/rust-lang/libc/pull/5359))
- Android: Add `RTLD_NEXT` ([#5323](https://github.com/rust-lang/libc/pull/5323))
- Android: Add reuseport BPF socket options ([#5366](https://github.com/rust-lang/libc/pull/5366))
- Apple: Add TCP header flags, options and SACK limits ([#5358](https://github.com/rust-lang/libc/pull/5358))
- Apple: Add `NET_RT_DUMP2` ([#5442](https://github.com/rust-lang/libc/pull/5442))
- Apple: Add `posix_spawn_file_actions_add(f)chdir(_np)` ([#5558](https://github.com/rust-lang/libc/pull/5558))
- BSD: Add `BPF_WORDALIGN` ([#5320](https://github.com/rust-lang/libc/pull/5320))
- BSD: Add `lchmod` and `lchflags` where supported ([#5400](https://github.com/rust-lang/libc/pull/5400))
- BSD: Add `minherit` and related constants ([#4849](https://github.com/rust-lang/libc/pull/4849))
- Docs: Add more links to public headers and manual pages ([#5407](https://github.com/rust-lang/libc/pull/5407)), ([#5485](https://github.com/rust-lang/libc/pull/5485))
- Emscripten: Add epoll support ([#5427](https://github.com/rust-lang/libc/pull/5427))
- FreeBSD: Add `AT_RENAME_*` and `RENAME_*` constants ([#5560](https://github.com/rust-lang/libc/pull/5560))
- FreeBSD: Add `renameat2` ([#5563](https://github.com/rust-lang/libc/pull/5563))
- FreeBSD: Add `rt_msghdr` and `rt_metrics` ([#5367](https://github.com/rust-lang/libc/pull/5367))
- Hurd: Add handling of LFS under `libc_unstable_gnu_time_bits` ([#5242](https://github.com/rust-lang/libc/pull/5242))
- Linux-GNU: Add `environ` ([#5339](https://github.com/rust-lang/libc/pull/5339))
- Linux-GNU: Add the new `f_type` field to `statvfs` and `statvfs64` ([#5434](https://github.com/rust-lang/libc/pull/5434))
- Linux-like: Add additional `STATX_*` constants ([#5412](https://github.com/rust-lang/libc/pull/5412))
- Linux-musl, Emscripten: Add `SIGEV_THREAD_ID` ([#5375](https://github.com/rust-lang/libc/pull/5375))
- Linux-musl: Add `*_SUPER_MAGIC` constants ([#5453](https://github.com/rust-lang/libc/pull/5453))
- Linux-musl: Make `statx` always available ([#5448](https://github.com/rust-lang/libc/pull/5448))
- Linux-s390x: Add `max_align_t` ([#5389](https://github.com/rust-lang/libc/pull/5389))
- Linux: Add `BCACHEFS_SUPER_MAGIC` ([#5516](https://github.com/rust-lang/libc/pull/5516))
- Linux: Add `ETH_P_LLDP` ([#5438](https://github.com/rust-lang/libc/pull/5438))
- Linux: Add `FUTEX_ROBUST_UNLOCK` and `FUTEX_ROBUST_LIST32` ([#5525](https://github.com/rust-lang/libc/pull/5525))
- Linux: Add `NLMSG_*` helpers ([#5321](https://github.com/rust-lang/libc/pull/5321))
- Linux: Update the definition of `siginfo_t` and add more getter functions ([#5345](https://github.com/rust-lang/libc/pull/5345))
- Musl riscv64: Add `SYS_futex_waitv` ([#5527](https://github.com/rust-lang/libc/pull/5527))
- Newlib: Add `__errno` ([#5346](https://github.com/rust-lang/libc/pull/5346))
- OpenBSD: Add `RTLD_NODELETE` and `RTLD_NOLOAD` ([#5377](https://github.com/rust-lang/libc/pull/5377))
- OpenBSD: Add `getexecpath` ([#5465](https://github.com/rust-lang/libc/pull/5465))
- OpenBSD: Add bindings from `sensors.h` ([#5510](https://github.com/rust-lang/libc/pull/5510))
- OpenBSD: Add missing `HW_*` sysctl constants ([#5371](https://github.com/rust-lang/libc/pull/5371))
- QNX: Add definitions for io-sock ([#5469](https://github.com/rust-lang/libc/pull/5469))
- Redox: Add `FILENAME_MAX` ([#5530](https://github.com/rust-lang/libc/pull/5530))
- Redox: Add `clock_settime` and `pause` ([#5363](https://github.com/rust-lang/libc/pull/5363))
- Redox: Add `getrandom` bindings ([#5333](https://github.com/rust-lang/libc/pull/5333))
- Unix: Add RFC 3678 multicast `group_req`/`group_source_req` and `MCAST_*` where supported ([#5236](https://github.com/rust-lang/libc/pull/5236))
- Unix: Add `HOST_NAME_MAX` ([#5531](https://github.com/rust-lang/libc/pull/5531))
- Unix: Add `_PATH_BSHELL` and `_PATH_DEFPATH` where available ([#5449](https://github.com/rust-lang/libc/pull/5449))
- WASI: Add `SOCK_CLOEXEC` ([#5336](https://github.com/rust-lang/libc/pull/5336))
- WASI: Add locale category constants ([#5378](https://github.com/rust-lang/libc/pull/5378))
- WASI: Add more pthread APIs ([#5310](https://github.com/rust-lang/libc/pull/5310))
- uClibc: Support 64-bit `time_t` on 32-bit platforms via cfg ([#5261](https://github.com/rust-lang/libc/pull/5261))

### Deprecated

- AIX: deprecate `_kernel_simple_lock` ([#5380](https://github.com/rust-lang/libc/pull/5380))
- Deprecate integer `*_MIN`/`*_MAX` in favor of e.g. `c_int::MAX` ([#5404](https://github.com/rust-lang/libc/pull/5404))
- Fuchsia: Deprecate types that do not exist upstream ([#5127](https://github.com/rust-lang/libc/pull/5127))
- Hurd: Deprecate `fallocate64`, which does not exist on the platform ([#5242](https://github.com/rust-lang/libc/pull/5242))
- Hurd: Deprecate redundant `glob64` types and routines ([#5242](https://github.com/rust-lang/libc/pull/5242))
- L4Re: deprecate LFS bindings ([#5173](https://github.com/rust-lang/libc/pull/5173))
- OpenBSD: Deprecate `syscall`, `mincore`, and `KERN_NSELCOLL`, all of which have been removed upstream ([87992e9895c2](https://github.com/rust-lang/libc/commit/87992e9895c2bfc6daab97d2e8f20ae895fd9f7b))
- Unix: Deprecate the POSIX-obsoleted `tmpnam`, `tempnam` ([#5478](https://github.com/rust-lang/libc/pull/5478))

### Fixed

- **breaking** AIX: Change the type of `BPF_ALIGNMENT` to `size_t`  to match upstream and harmonize with other platforms. ([#5373](https://github.com/rust-lang/libc/pull/5373))
- **breaking** Apple: change the type of `BPF_ALIGNMENT` to `size_t` to match upstream and harmonize with other platforms. ([#5348](https://github.com/rust-lang/libc/pull/5348))
- Exclude non-required repository files from the published crate ([#5312](https://github.com/rust-lang/libc/pull/5312))
- AIX: Correct the function signature in `fileops_t.fo_select` ([#5380](https://github.com/rust-lang/libc/pull/5380))
- AIX: Fix the alignment of `file` ([#5380](https://github.com/rust-lang/libc/pull/5380))
- Android: Add missing padding to `ucontext_t` ([#5189](https://github.com/rust-lang/libc/pull/5189))
- Android: Fix the value of RISC-V `O_` flags ([#5554](https://github.com/rust-lang/libc/pull/5554))
- Fuchsia: Correct `mcontext_t` and `ucontext_t` and make them usable on more platforms ([#5127](https://github.com/rust-lang/libc/pull/5127))
- Fuchsia: Fix available fields in `glob_t` and `statvfs` ([#5127](https://github.com/rust-lang/libc/pull/5127))
- Fuchsia: Fix the definition of `sigevent` and correct the layout of other `pthread.h` types ([#5127](https://github.com/rust-lang/libc/pull/5127))
- Haiku: Correct the definition of `sem_t` ([#5351](https://github.com/rust-lang/libc/pull/5351))
- Linux-GNU: Fix the padding field in `statvfs64` on 32-bit RISC-V ([#5518](https://github.com/rust-lang/libc/pull/5518))
- Linux: Correct PowerPC64 speed symbols with elfv2 ([#5342](https://github.com/rust-lang/libc/pull/5342))
- Linux: Fix syscall numbers on 32-bit RISC-V ([#5455](https://github.com/rust-lang/libc/pull/5455))
- Musl riscv64: Fix the definition of `ipc_perm` ([#5527](https://github.com/rust-lang/libc/pull/5527))
- Musl riscv64: Fix the name of the `uc_flags` field in `ucontext_t` ([#5527](https://github.com/rust-lang/libc/pull/5527))
- NetBSD: Fix `WIFSTOPPED` ([#5458](https://github.com/rust-lang/libc/pull/5458))
- Newlib: Update the `time_t` alias. This is a correction on Arm32 RTEMS ([#5132](https://github.com/rust-lang/libc/pull/5132))
- NuttX: Correct `O_` open flags ([#5414](https://github.com/rust-lang/libc/pull/5414))
- RTEMS: Correct `socket.h` definitions ([#5313](https://github.com/rust-lang/libc/pull/5313))
- RTEMS: Correct the size of clock and storage type aliases  ([#5450](https://github.com/rust-lang/libc/pull/5450))
- Redox: Correct `signal.h` types ([#5436](https://github.com/rust-lang/libc/pull/5436))

### Changed

- The unstable cfg `libc_unstable_musl_v1_2_3` has been renamed to a more accurate
  `libc_unstable_musl_v1_2`. The old version will continue to work for now, but will be removed in
  1-2 releases. ([#5376](https://github.com/rust-lang/libc/pull/5376))
- AIX: Make function pointers in signatures `unsafe` ([#5380](https://github.com/rust-lang/libc/pull/5380))
- Cygwin: Change `POSIX_SPAWN_*` flags to `c_short` ([#5572](https://github.com/rust-lang/libc/pull/5572))
- Hermit: Make iovec fields public ([#5460](https://github.com/rust-lang/libc/pull/5460))
- Improve the panic message for out-of-range fds in `FD_*` functions ([#5528](https://github.com/rust-lang/libc/pull/5528))
- Musl riscv64: Fix the name of `__riscv_mc_q_ext_state.__reserved` and make it private ([#5533](https://github.com/rust-lang/libc/pull/5533))
- Various: Make obsolete `stat` fields non-`pub` ([#5542](https://github.com/rust-lang/libc/pull/5542))
- uClibc: No longer link to libutil ([#5165](https://github.com/rust-lang/libc/pull/5165))

### Removed

`libc` exposed quite a bit of API on all Apple platforms that is not actually available anywhere other than MacOS. This release removes a number of these cases.

- **breaking** Apple: Disable `mach.h` API on Apple mobile OSs ([e6bfb187513c](https://github.com/rust-lang/libc/commit/e6bfb187513c665c94683b9738a855e982173c2f))
- **breaking** Apple: Remove a large number of items from iOS, tvOS, watchOS, and visionOS that are only available on MacOS. ([#5158](https://github.com/rust-lang/libc/pull/5158))
- **breaking** Apple: Remove the unsupported `exec*` and `fork` calls from tvOS and watchOS ([#5158](https://github.com/rust-lang/libc/pull/5158))

Additionally, this release cleans up a lot of API that has been deprecated since at least libc 0.2.100, released 2021-08-20.

- **breaking** Android, Linux: remove unsound `af_alg_iv` trait implementations. The have been deprecated for a long time because they allowed out-of-bounds reads via safe functions. ([444db4456f38](https://github.com/rust-lang/libc/commit/444db4456f3866519b7eacd35a8bb59484bb7bbf))
- **breaking** Remove most items that have been deprecated since before 0.2.100 ([#5401](https://github.com/rust-lang/libc/pull/5401))

Other removed items:

- Dragonfly: Remove `INHERIT_ZERO` that does not exist upstream ([#5587](https://github.com/rust-lang/libc/pull/5587))
- Musl riscv64: Remove GNU-gated `REG_*` definitions ([#5527](https://github.com/rust-lang/libc/pull/5527))
- Musl riscv64: Remove non-esxistant `REG_NARGS` ([#5527](https://github.com/rust-lang/libc/pull/5527))

A huge thank you to our GSoC student Adam Martinez ([@dybucc](https://github.com/dybucc)) who did a
huge amount of the time64 work, as well as many of the platform fixes!


## [0.2.189](https://github.com/rust-lang/libc/compare/0.2.188...0.2.189) - 2026-07-21

### Added

- Emscripten: Add `pthread_sigmask`, `sigwait`, `sigwaitinfo`, `sigtimedwait`, `faccessat`, and `pthread_kill` ([#5270](https://github.com/rust-lang/libc/pull/5270))
- Linux SPARC: Enable the `clone3` syscall ([#4980](https://github.com/rust-lang/libc/pull/4980))
- Solarish: Add `CLOCK_PROCESS_CPUTIME_ID` and `CLOCK_THREAD_CPUTIME_ID` ([#5274](https://github.com/rust-lang/libc/pull/5274))

### Deprecated

- Deprecate `CLONE_INTO_CGROUP` and `CLONE_CLEAR_SIGHAND`. These overflow their types and will be changed to a larger size in the future. ([8c6e6710458d](https://github.com/rust-lang/libc/commit/8c6e6710458db4d6aa0766f6f84bbf13f640237e))

### Fixed

- Musl riscv32: Rename padding fields to avoid a conflict and fix the build ([2499ff0ad993](https://github.com/rust-lang/libc/commit/2499ff0ad9936a036e78a4e0991445efee383564))
- NuttX: Fix `wchar_t` definition under Arm ([#5245](https://github.com/rust-lang/libc/pull/5245))
- Windows: Add back link names for `time`-related symbols ([#5300](https://github.com/rust-lang/libc/pull/5300))


## [0.2.188](https://github.com/rust-lang/libc/compare/0.2.187...0.2.188) - 2026-07-21

### Changed

- Restore `Send` and `Sync` for `DIR` ([ba6a6b56ae09](https://github.com/rust-lang/libc/commit/ba6a6b56ae09e0640a2b2e27f3f6abdb4b3d243f))

These were removed in 0.2.187 because `libc` does not actually make `Send` and `Sync`
guarantees about `DIR` (or other extern types), but this caused some crates to break.
The traits are added back for now to allow time to migrate, but will be removed again
in the future; please make sure your crates are not relying on `libc::DIR: Send` or
`libc::DIR: Sync`.


## [0.2.187](https://github.com/rust-lang/libc/compare/0.2.186...0.2.187) - 2026-07-20

This release contains a number of improvements related to 64-bit `time_t` configuration.
Of note the existing `RUST_LIBC_UNSTABLE_*` environment variables have been replaced
with configuration options. The new way to use these is:

```sh
RUSTFLAGS='--cfg=libc_unstable_musl_v1_2_3' cargo ...
RUSTFLAGS='--cfg=libc_unstable_gnu_time_bits="64"' cargo ...
```

Being able to set this via `RUSTFLAGS` makes it easier to only apply configuration to
specific targets (and notably, not the host if build scripts are used).

There are two other notable changes:

* The 32-bit `windows-gnu` targets now respect `libc_unstable_gnu_time_bits`
* uClibc now supports a similar configuration option:

  ```sh
  RUSTFLAGS='--cfg=libc_unstable_uclibc_time64'
  ```

As a reminder, these options are under active development and may change in the future
(hence the "unstable" in the name). It likely that we will harmonize everything under a
single configuration option before considering them stable.

### Support

- Add support for `aarch64-unknown-linux-pauthtest` ([#5065](https://github.com/rust-lang/libc/pull/5065))
- Add support for new QNX targets ([#5241](https://github.com/rust-lang/libc/pull/5241))
- Better document breaking change policy and recommended usage ([#5179](https://github.com/rust-lang/libc/pull/5179))

### Added

- Android: Add `POSIX_SPAWN_*` constants ([#5104](https://github.com/rust-lang/libc/pull/5104))
- Android: Add `getpwent`, `setpwent`, and `endpwent` ([#5160](https://github.com/rust-lang/libc/pull/5160))
- Android: Add `preadv2` and `pwritev2` ([#5157](https://github.com/rust-lang/libc/pull/5157))
- Android: Add `seccomp_notif*` structures ([#5224](https://github.com/rust-lang/libc/pull/5224))
- Android: Add `timer_[create, delete, getoverrun, gettime, settime]` ([#5108](https://github.com/rust-lang/libc/pull/5108))
- Apple: Add `PROC_PIDT_SHORTBSDINFO` and `proc_bsdshortinfo` ([#5110](https://github.com/rust-lang/libc/pull/5110))
- Apple: Add `SIOC*` constants from `sockio.h` ([#5263](https://github.com/rust-lang/libc/pull/5263))
- Apple: Add `_IOR`, `_IOW`, `_IOWR` ([#5264](https://github.com/rust-lang/libc/pull/5264))
- Apple: Add `bpf_program` and `bpf_insn` ([#5235](https://github.com/rust-lang/libc/pull/5235))
- Apple: Add additional `kqueue` constants ([#5077](https://github.com/rust-lang/libc/pull/5077))
- Apple: Update `vm_statistics64` with recently added fields ([#5253](https://github.com/rust-lang/libc/pull/5253))
- Apple: add `IN6_IFF_*` and `SIOCGIFAFLAG_IN6` ([#5239](https://github.com/rust-lang/libc/pull/5239))
- Dragonfly: Add `O_*`, `POSIX_FADV_*`, `NI*`, and a few other missing constants ([#5116](https://github.com/rust-lang/libc/pull/5116))
- Dragonfly: add `fdatasync`, `dlvsym`, `reallocarray`, `qsort_r`, `pthread_*affinity_np`, `ftok`, `extattr_*`, and `dup3` ([#5116](https://github.com/rust-lang/libc/pull/5116))
- Emscripten: Add `in6_pktinfo` ([#5256](https://github.com/rust-lang/libc/pull/5256))
- FreeBSD: Add SOL_LOCAL ([#5185](https://github.com/rust-lang/libc/pull/5185))
- FreeBSD: Add `DLT_*` constants ([#5235](https://github.com/rust-lang/libc/pull/5235))
- FreeBSD: Add `PROC_LOGSIGEXIT_*` and `PPROT_*` ([#4657](https://github.com/rust-lang/libc/pull/4657))
- FreeBSD: Add `SO_RERROR` ([#5260](https://github.com/rust-lang/libc/pull/5260))
- FreeBSD: add `IN6_IFF_*`, `in6_ifreq`, and `SIOCGIFAFLAG_IN6` ([#5239](https://github.com/rust-lang/libc/pull/5239))
- FreeBSD: add `_IO*` helpers from `sys/ioccom.h` ([#5239](https://github.com/rust-lang/libc/pull/5239))
- Glibc: Add `PTHREAD_*_MUTEX_INITIALIZER_NP` for riscv64 ([#5094](https://github.com/rust-lang/libc/pull/5094))
- Glibc: Add new fields to `struct tcp_info` ([#5215](https://github.com/rust-lang/libc/pull/5215))
- Linux: Add `OPEN_TREE_NAMESPACE` ([#5145](https://github.com/rust-lang/libc/pull/5145))
- Linux: Add `SECCOMP_IOCTL_*` constants ([#5224](https://github.com/rust-lang/libc/pull/5224))
- Linux: Add `SO_DETACH_REUSEPORT_BPF` ([#5081](https://github.com/rust-lang/libc/pull/5081))
- Linux: Add `futex_waitv` ([#5125](https://github.com/rust-lang/libc/pull/5125))
- Linux: Add constants for `fsopen`, `fsconfig`, `fsmount`, and `fspick` ([#5145](https://github.com/rust-lang/libc/pull/5145))
- Linux: Add fields to `statx` present since 6.16 ([#4621](https://github.com/rust-lang/libc/pull/4621))
- Linux: Add network entry API ([#5049](https://github.com/rust-lang/libc/pull/5049))
- Linux: add `ifaddrmsg` and `rtattr` ([#5234](https://github.com/rust-lang/libc/pull/5234))
- Linux: add `sockaddr_iucv` ([#5041](https://github.com/rust-lang/libc/pull/5041))
- MacOS: Add `ENOTCAPABLE` ([#4925](https://github.com/rust-lang/libc/pull/4925))
- Musl: Add `renameat2` ([#5113](https://github.com/rust-lang/libc/pull/5113))
- NuttX: Add `F_SETFD` ([#5258](https://github.com/rust-lang/libc/pull/5258))
- NuttX: Add `POLLRD*` and `POLLWR*` constants ([#5258](https://github.com/rust-lang/libc/pull/5258))
- NuttX: Add `SO_KEEPALIVE` and TCP keepalive constants ([#5111](https://github.com/rust-lang/libc/pull/5111))
- NuttX: Add `TCP_MAXSEG` ([#5258](https://github.com/rust-lang/libc/pull/5258))
- NuttX: Add `eventfd` and `EFD_*` constants ([#5258](https://github.com/rust-lang/libc/pull/5258))
- NuttX: Add `pipe2` ([#5258](https://github.com/rust-lang/libc/pull/5258))
- NuttX: Add `strerror_r` ([#5258](https://github.com/rust-lang/libc/pull/5258))
- NuttX: Add `netinet` structs and constants ([#5258](https://github.com/rust-lang/libc/pull/5258))
- NuttX: Add socket structs, functions and constants ([#5258](https://github.com/rust-lang/libc/pull/5258))
- QuRT: Add POSIX timer functions ([#5091](https://github.com/rust-lang/libc/pull/5091))
- QuRT: Add missing pthread functions from QuRT SDK headers ([#5091](https://github.com/rust-lang/libc/pull/5091))
- QuRT: Add missing unistd process and file functions ([#5091](https://github.com/rust-lang/libc/pull/5091))
- QuRT: Add mqueue subsystem (message queues, select/pselect) ([#5091](https://github.com/rust-lang/libc/pull/5091))
- Redox: Add `*at` and `dirent` functions ([#5117](https://github.com/rust-lang/libc/pull/5117))
- Solarish: Add IP TTL and IPv6 Hop Limit consts ([#5089](https://github.com/rust-lang/libc/pull/5089))
- Solarish: Add `port_alert` and `PORT_ALERT*` constants ([#5203](https://github.com/rust-lang/libc/pull/5203))
- Solarish: add AI_CANONNAME ([#5085](https://github.com/rust-lang/libc/pull/5085))
- aarch64: Add SYS_sendfile and SYS_fadvise64 constants ([#5133](https://github.com/rust-lang/libc/pull/5133))

### Deprecated

- Dragonfly: Deprecate compatibility aliases `CPUCTL_RSMSR` and `UTX_DB_LASTLOG` ([#5116](https://github.com/rust-lang/libc/pull/5116))

### Fixed

- **breaking** NetBSD: Correct `ts` from `*const timespec` to `*mut timespec` in _lwp_park` ([#5169](https://github.com/rust-lang/libc/pull/5169))
- **breaking** Linux GNU: Change overflowing `PTRACE_*ET_SYSCALL_USER_DISPATCH_CONFIG` constants from `u8` to `c_uint` ([#4936](https://github.com/rust-lang/libc/pull/4936))
- Fix the soundness bug in the representation of extern types ([#5021](https://github.com/rust-lang/libc/pull/5021))
- Cygwin: fix `cpuset_t` typo in `CPU_ZERO` ([#5098](https://github.com/rust-lang/libc/pull/5098))
- Dragonfly: ABI fixes including regex offsets, `ifaddrs`, pthread barriers, process sizing fields, and `mcontext` alignment ([#5116](https://github.com/rust-lang/libc/pull/5116))
- Dragonfly: Correct values of `CPUCTL_CPUID*`, `EV_HUP`, and `EV_SYSFLAGS` ([#5116](https://github.com/rust-lang/libc/pull/5116))
- Emscripten: fix pthread type sizes for wasm64 (MEMORY64) ([#5156](https://github.com/rust-lang/libc/pull/5156))
- Horizon: Fix the value of `POLLOUT` ([#5090](https://github.com/rust-lang/libc/pull/5090))
- Linux: Correct the value of `EPIOC[GS]PARAMS` with nonstandard _IOC ([#5188](https://github.com/rust-lang/libc/pull/5188))
- Make VxWorks shims `unsafe` ([#3727](https://github.com/rust-lang/libc/pull/3727))
- NetBSD: Correct getmntinfo to link `__getmntinfo13` ([#5251](https://github.com/rust-lang/libc/pull/5251))
- QNX: Fix the value of `PTHREAD_MUTEX_INITIALIZER` ([#5241](https://github.com/rust-lang/libc/pull/5241))
- QuRT: fix type and definition inaccuracies against SDK headers ([#5091](https://github.com/rust-lang/libc/pull/5091))
- Windows: Correctly link to 32-bit time routines on 32-bit platforms ([#5059](https://github.com/rust-lang/libc/pull/5059))
- uClibc: Fix constants accidentally removed ([#5141](https://github.com/rust-lang/libc/pull/5141))
- uclibc: Fix build issues ([#5046](https://github.com/rust-lang/libc/pull/5046))
- uclibc: Fix type of PRIO_PROCESS and friends ([#5046](https://github.com/rust-lang/libc/pull/5046))

### Changed

- AIX, TeeOS: Drop unneeded `-> c_void` ([#5240](https://github.com/rust-lang/libc/pull/5240))
- Apple: Change `AIO_LISTIO_MAX` to account for changes in macOS 27 ([#5253](https://github.com/rust-lang/libc/pull/5253))
- Glibc: Update the value of `MS_NOUSER` ([#5215](https://github.com/rust-lang/libc/pull/5215))
- L4Re: Update definitions and test infra ([#5275](https://github.com/rust-lang/libc/pull/5275))
- Linux: Update the value of `SW_MAX` and `SW_CNT` ([#5215](https://github.com/rust-lang/libc/pull/5215))
- MacOS: Add `swapped_count` to `vm_statistics64` ([#4926](https://github.com/rust-lang/libc/pull/4926))
- Windows: Windows-GNU now respects `libc_unstable_gnu_time_bits` for 64-bit `time_t` config ([#5062](https://github.com/rust-lang/libc/pull/5062))

### Removed

- Dragonfly: Remove FreeBSD-only `Elf32_Lword`, `ip_mreq_source`, and `IP_` constants ([#5116](https://github.com/rust-lang/libc/pull/5116))
- Dragonfly: Remove private VM type bindings ([#5116](https://github.com/rust-lang/libc/pull/5116))
- Linux: Remove `KERN_REALROOTDEV` and `VM_LAPTOP_MODE` ([#5177](https://github.com/rust-lang/libc/pull/5177))
- VxWorks: Remove non-user-facing (kernel) API ([#5129](https://github.com/rust-lang/libc/pull/5129))

### Other

- Print config information if `LIBC_BUILD_VERBOSE` is set ([#5272](https://github.com/rust-lang/libc/pull/5272))
- Annotate `*LAST` constants as potentially changing ([#5120](https://github.com/rust-lang/libc/pull/5120))
- Annotate `*MAX` constants as potentially changing ([#5122](https://github.com/rust-lang/libc/pull/5122))
- BSD: Annotate `ELAST` constants as potentially changing ([#5118](https://github.com/rust-lang/libc/pull/5118))
- FreeBSD: Annotate `RAND_MAX` as potentially changing ([#5119](https://github.com/rust-lang/libc/pull/5119))
- Linux, L4re: Annotate `*NUM` constants as potentially changing ([#5123](https://github.com/rust-lang/libc/pull/5123))
- QNX: Restructure to support new platforms ([#4984](https://github.com/rust-lang/libc/pull/4984))
- Unix: Annotate `*COUNT` constants as potentially changing ([#5121](https://github.com/rust-lang/libc/pull/5121))
- uClibc: Add unstable support of 64-bit `time_t` ([#5046](https://github.com/rust-lang/libc/pull/5046))
- (internal) FreeBSD: Replace unstable env to set version with an unstable cfg ([#5201](https://github.com/rust-lang/libc/pull/5201))
- (internal) Glibc: Remove public configuration for file offset bits ([#5268](https://github.com/rust-lang/libc/pull/5268))
- (internal) Linux: Delete config via `RUST_LIBC_UNSTABLE_LINUX_TIME_BITS64` ([#5197](https://github.com/rust-lang/libc/pull/5197))
- (internal) Replace `RUST_LIBC_UNSTABLE` env with `libc_unstable*` cfg ([#4977](https://github.com/rust-lang/libc/pull/4977))


## [0.2.186](https://github.com/rust-lang/libc/compare/0.2.185...0.2.186) - 2026-04-24

### Added

- Apple: Add `KEVENT_FLAG_*` constants ([#5070](https://github.com/rust-lang/libc/pull/5070))
- Linux: Add `PR_SET_MEMORY_MERGE` and `PR_GET_MEMORY_MERGE` ([#5060](https://github.com/rust-lang/libc/pull/5060))

### Changed

- CI: Migrate FreeBSD CI from Cirrus CI to GitHub Actions ([#5058](https://github.com/rust-lang/libc/pull/5058))

## [0.2.185](https://github.com/rust-lang/libc/compare/0.2.184...0.2.185) - 2026-04-13

### Added

- EspIDF: Add `espidf_picolibc` cfg for picolibc `O_*` flag values ([#5035](https://github.com/rust-lang/libc/pull/5035))
- Hexagon: add missing constants and fix types for linux-musl ([#5042](https://github.com/rust-lang/libc/pull/5042))
- Redox: Add semaphore functions ([#5051](https://github.com/rust-lang/libc/pull/5051))
- Windows: Add `sprintf`, `snprintf`, and the `scanf` family ([#5024](https://github.com/rust-lang/libc/pull/5024))

### Fixed

- Hexagon: Decouple `time64` types from musl symbol redirects ([#5040](https://github.com/rust-lang/libc/pull/5040))
- Horizon: Change `POLL` constants from `c_short` to `c_int` ([#5045](https://github.com/rust-lang/libc/pull/5045))


## [0.2.184](https://github.com/rust-lang/libc/compare/0.2.183...0.2.184) - 2026-04-01

### MSRV

This release increases the MSRV of `libc` to 1.65. With this update, you can now always use the
`core::ffi::c_*` types with `libc` definitions, since `libc` has been changed to reexport from
`core` rather than redefining them. (This _usually_ worked before but had edge cases.)
([#4972](https://github.com/rust-lang/libc/pull/4972))

### Added

- BSD: Add `IP_MINTTL` to bsd ([#5026](https://github.com/rust-lang/libc/pull/5026))
- Cygwin: Add `TIOCM_DSR` ([#5031](https://github.com/rust-lang/libc/pull/5031))
- FreeBSD: Added `xfile` structe and file descriptor types ([#5002](https://github.com/rust-lang/libc/pull/5002))
- Linux: Add CAN netlink bindings ([#5011](https://github.com/rust-lang/libc/pull/5011))
- Linux: Add `struct ethhdr` ([#4239](https://github.com/rust-lang/libc/pull/4239))
- Linux: Add `struct ifinfomsg` ([#5012](https://github.com/rust-lang/libc/pull/5012))
- Linux: Define `max_align_t` for riscv64 ([#5029](https://github.com/rust-lang/libc/pull/5029))
- NetBSD: Add missing `CLOCK_` constants ([#5020](https://github.com/rust-lang/libc/pull/5020))
- NuttX: Add `_SC_HOST_NAME_MAX` ([#5004](https://github.com/rust-lang/libc/pull/5004))
- VxWorks: Add `flock` and `F_*LCK` constants ([#4043](https://github.com/rust-lang/libc/pull/4043))
- WASI: Add all `_SC_*` sysconf constants ([#5023](https://github.com/rust-lang/libc/pull/5023))

### Deprecated

The remaining fixed-width integer aliases, `__uint128_t`, `__uint128`, `__int128_t`, and `__int128`,
have been deprecated. Use `i128` and `u128` instead. ([#4343](https://github.com/rust-lang/libc/pull/4343))

### Fixed

- **breaking** Redox: Fix signal action constant types ([#5009](https://github.com/rust-lang/libc/pull/5009))
- EspIDF: Correct the value of `DT_*` constants ([#5034](https://github.com/rust-lang/libc/pull/5034))
- Redox: Fix locale values and add `RTLD_NOLOAD`, some TCP constants ([#5025](https://github.com/rust-lang/libc/pull/5025))
- Various: Use `Padding::new(<zeroed>)` rather than `Padding::uninit()` ([#5036](https://github.com/rust-lang/libc/pull/5036))

### Changed

- **potentially breaking** Linux: Add new fields to `struct ptrace_syscall_info` ([#4966](https://github.com/rust-lang/libc/pull/4966))
- Re-export `core::ffi` integer types rather than redefining ([#5015](https://github.com/rust-lang/libc/pull/5015))
- Redox: Update `F_DUPFD`, `IP`, and `TCP` constants to match relibc  ([#4990](https://github.com/rust-lang/libc/pull/4990))



## [0.2.183](https://github.com/rust-lang/libc/compare/0.2.182...0.2.183) - 2026-03-08

### Added

- ESP-IDF: Add `SOMAXCONN` ([#4993](https://github.com/rust-lang/libc/pull/4993))
- Linux: Add `name_to_handle_at` and `open_by_handle_at` ([#4988](https://github.com/rust-lang/libc/pull/4988))
- NetBSD: Add `kinfo_file`, `kinfo_pcb`, and related constants ([#4985](https://github.com/rust-lang/libc/pull/4985))
- OpenBSD: Add `kinfo_file` and related constants ([#4991](https://github.com/rust-lang/libc/pull/4991))
- VxWorks: Add additional structs and defines ([#5003](https://github.com/rust-lang/libc/pull/5003))
- Various: Implement `Default` for `timeval` and `timespec` ([#4976](https://github.com/rust-lang/libc/pull/4976))

### Fixed

- Hexagon musl: Enable unstable 64-bit `time_t` support and `musl_v1_2_3` ([#4992](https://github.com/rust-lang/libc/pull/4992))
- Nintendo Switch: Fix target support ([#4982](https://github.com/rust-lang/libc/pull/4982))
- OpenBSD: Wrap an unused field in `Padding` ([#4997](https://github.com/rust-lang/libc/pull/4997))
- Redox: Change `sigaction.sa_flags` to `c_int` ([#4986](https://github.com/rust-lang/libc/pull/4986))
- Redox: Fix `blkcnt_t` type ([#4994](https://github.com/rust-lang/libc/pull/4994))

## [0.2.182](https://github.com/rust-lang/libc/compare/0.2.181...0.2.182) - 2026-02-13

### Added

- Android, Linux: Add `tgkill` ([#4970](https://github.com/rust-lang/libc/pull/4970))
- Redox: Add `RENAME_NOREPLACE` ([#4968](https://github.com/rust-lang/libc/pull/4968))
- Redox: Add `renameat2` ([#4968](https://github.com/rust-lang/libc/pull/4968))


## [0.2.181](https://github.com/rust-lang/libc/compare/0.2.180...0.2.181) - 2026-02-09

### Added

- Apple: Add `MADV_ZERO` ([#4924](https://github.com/rust-lang/libc/pull/4924))
- Redox: Add `makedev`, `major`, and `minor` ([#4928](https://github.com/rust-lang/libc/pull/4928))
- GLibc: Add `PTRACE_SET_SYSCALL_INFO` ([#4933](https://github.com/rust-lang/libc/pull/4933))
- OpenBSD: Add more kqueue related constants for ([#4945](https://github.com/rust-lang/libc/pull/4945))
- Linux: add CAN error types ([#4944](https://github.com/rust-lang/libc/pull/4944))
- OpenBSD: Add siginfo_t::si_status ([#4946](https://github.com/rust-lang/libc/pull/4946))
- QNX NTO: Add `max_align_t` ([#4927](https://github.com/rust-lang/libc/pull/4927))
- Illumos: Add `_CS_PATH` ([#4956](https://github.com/rust-lang/libc/pull/4956))
- OpenBSD: add `ppoll` ([#4957](https://github.com/rust-lang/libc/pull/4957))

### Fixed

- **breaking**: Redox: Fix the type of dev_t ([#4928](https://github.com/rust-lang/libc/pull/4928))
- AIX: Change 'tv_nsec' of 'struct timespec' to type 'c_long' ([#4931](https://github.com/rust-lang/libc/pull/4931))
- AIX: Use 'struct st_timespec' in 'struct stat{,64}' ([#4931](https://github.com/rust-lang/libc/pull/4931))
- Glibc: Link old version of `tc{g,s}etattr` ([#4938](https://github.com/rust-lang/libc/pull/4938))
- Glibc: Link the correct version of `cf{g,s}et{i,o}speed` on mips{32,64}r6 ([#4938](https://github.com/rust-lang/libc/pull/4938))
- OpenBSD: Fix constness of tm.tm_zone ([#4948](https://github.com/rust-lang/libc/pull/4948))
- OpenBSD: Fix the definition of `ptrace_thread_state` ([#4947](https://github.com/rust-lang/libc/pull/4947))
- QuRT: Fix type visibility and defs ([#4932](https://github.com/rust-lang/libc/pull/4932))
- Redox: Fix values for `PTHREAD_MUTEX_{NORMAL, RECURSIVE}` ([#4943](https://github.com/rust-lang/libc/pull/4943))
- Various: Mark additional fields as private padding ([#4922](https://github.com/rust-lang/libc/pull/4922))

### Changed

- Fuchsia: Update `SO_*` constants ([#4937](https://github.com/rust-lang/libc/pull/4937))
- Revert "musl: convert inline timespecs to timespec" (resolves build issues on targets only supported by Musl 1.2.3+ ) ([#4958](https://github.com/rust-lang/libc/pull/4958))


## [0.2.180](https://github.com/rust-lang/libc/compare/0.2.179...0.2.180) - 2026-01-08

### Added

- QNX: Add missing BPF and ifreq structures ([#4769](https://github.com/rust-lang/libc/pull/4769))

### Fixed

- Linux, L4Re: address soundness issues of `CMSG_NXTHDR` ([#4903](https://github.com/rust-lang/libc/pull/4903))
- Linux-like: Handle zero-sized payload differences in `CMSG_NXTHDR` ([#4903](https://github.com/rust-lang/libc/pull/4903))
- Musl: Fix incorrect definitions of struct stat on some 32-bit architectures ([#4914](https://github.com/rust-lang/libc/pull/4914))
- NetBSD: RISC-V 64: Correct `mcontext` type definitions ([#4886](https://github.com/rust-lang/libc/pull/4886))
- uClibc: Re-enable `__SIZEOF_PTHREAD_COND_T` on non-L4Re uclibc ([#4915](https://github.com/rust-lang/libc/pull/4915))
- uClibc: Restructure Linux `netlink` module to resolve build errors ([#4915](https://github.com/rust-lang/libc/pull/4915))


## [0.2.179](https://github.com/rust-lang/libc/compare/0.2.178...0.2.179) - 2025-01-03

With this release, we now have _unstable_ support for 64-bit `time_t` on 32-bit
platforms with both Musl and Glibc. Testing is appreciated!

For now, these can be enabled by setting environment variables during build:

```text
RUST_LIBC_UNSTABLE_MUSL_V1_2_3=1
RUST_LIBC_UNSTABLE_GNU_TIME_BITS=64
```

Note that the exact configuration will change in the future. Setting the
`MUSL_V1_2_3` variable also enables some newer API unrelated to `time_t`.

### Added

- L4Re: Add uclibc aarch64 support ([#4479](https://github.com/rust-lang/libc/pull/4479))
- Linux, Android: Add a generic definition for `XCASE` ([#4847](https://github.com/rust-lang/libc/pull/4847))
- Linux-like: Add `NAME_MAX` ([#4888](https://github.com/rust-lang/libc/pull/4888))
- Linux: Add `AT_EXECVE_CHECK` ([#4422](https://github.com/rust-lang/libc/pull/4422))
- Linux: Add the `SUN_LEN` macro ([#4269](https://github.com/rust-lang/libc/pull/4269))
- Linux: add `getitimer` and `setitimer` ([#4890](https://github.com/rust-lang/libc/pull/4890))
- Linux: add `pthread_tryjoin_n` and `pthread_timedjoin_np` ([#4887](https://github.com/rust-lang/libc/pull/4887))
- Musl: Add unstable support for 64-bit `time_t` on 32-bit platforms ([#4463](https://github.com/rust-lang/libc/pull/4463))
- NetBSD, OpenBSD: Add interface `LINK_STATE_*` definitions from `sys/net/if.h` ([#4751](https://github.com/rust-lang/libc/pull/4751))
- QuRT: Add support for Qualcomm QuRT ([#4845](https://github.com/rust-lang/libc/pull/4845))
- Types: Add Padding<T>::uninit() ([#4862](https://github.com/rust-lang/libc/pull/4862))

### Fixed

- Glibc: Link old version of `cf{g,s}et{i,o}speed` ([#4882](https://github.com/rust-lang/libc/pull/4882))
- L4Re: Fixes for `pthread` ([#4479](https://github.com/rust-lang/libc/pull/4479))
- L4re: Fix a wide variety of incorrect definitions ([#4479](https://github.com/rust-lang/libc/pull/4479))
- Musl: Fix the value of `CPU_SETSIZE` on musl 1.2+ ([#4865](https://github.com/rust-lang/libc/pull/4865))
- Musl: RISC-V: fix public padding fields in `stat/stat64` ([#4463](https://github.com/rust-lang/libc/pull/4463))
- Musl: s390x: Fix definition of `SIGSTKSZ`/`MINSIGSTKSZ` ([#4884](https://github.com/rust-lang/libc/pull/4884))
- NetBSD: Arm: Fix `PT_{GET,SET}FPREGS`, `_REG_TIPDR`, and `_REG_{LR,SP}` ([#4899](https://github.com/rust-lang/libc/pull/4899))
- NetBSD: Fix `if_msghdr` alignment ([#4902](https://github.com/rust-lang/libc/pull/4902))
- NetBSD: Fix `siginfo_t` layout on 32-bit platforms ([#4904](https://github.com/rust-lang/libc/pull/4904))
- NetBSD: change definition of `pthread_spin_t` to allow arch redefinition. ([#4899](https://github.com/rust-lang/libc/pull/4899))
- Newlib: Fix ambiguous glob exports and other warnings for Vita and 3DS ([#4875](https://github.com/rust-lang/libc/pull/4875))
- QNX: Fix build error ([#4879](https://github.com/rust-lang/libc/pull/4879))

### Changed

- CI: Update CI images to FreeBSD 15.0-release ([#4857](https://github.com/rust-lang/libc/pull/4857))
- L4Re: Make `pthread` struct fields private ([#4876](https://github.com/rust-lang/libc/pull/4876))
- Linux, Fuchsia: Mark mq_attr padding area as such ([#4858](https://github.com/rust-lang/libc/pull/4858))
- Types: Wrap a number of private fields in the `Padding` type ([#4862](https://github.com/rust-lang/libc/pull/4862))

### Removed

- Build: Remove `RUST_LIBC_UNSTABLE_LINUX_TIME_BITS64` ([#4865](https://github.com/rust-lang/libc/pull/4865))
- WASI: Remove nonexistent clocks ([#4880](https://github.com/rust-lang/libc/pull/4880))


## [0.2.178](https://github.com/rust-lang/libc/compare/0.2.177...0.2.178) - 2025-12-01

### Added

- BSD: Add `issetugid` ([#4744](https://github.com/rust-lang/libc/pull/4744))
- Cygwin: Add missing utmp/x.h, grp.h, and stdio.h interfaces ([#4827](https://github.com/rust-lang/libc/pull/4827))
- Linux s390x musl: Add `__psw_t`/`fprefset_t`/`*context_t` ([#4726](https://github.com/rust-lang/libc/pull/4726))
- Linux, Android: Add definition for IUCLC ([#4846](https://github.com/rust-lang/libc/pull/4846))
- Linux, FreeBSD: Add `AT_HWCAP{3,4}` ([#4734](https://github.com/rust-lang/libc/pull/4734))
- Linux: Add definitions from linux/can/bcm.h ([#4683](https://github.com/rust-lang/libc/pull/4683))
- Linux: Add syscalls 451-469 for m68k ([#4850](https://github.com/rust-lang/libc/pull/4850))
- Linux: PowerPC: Add 'ucontext.h' definitions ([#4696](https://github.com/rust-lang/libc/pull/4696))
- NetBSD: Define `eventfd` ([#4830](https://github.com/rust-lang/libc/pull/4830))
- Newlib: Add missing constants from `unistd.h` ([#4811](https://github.com/rust-lang/libc/pull/4811))
- QNX NTO: Add `cfmakeraw` ([#4704](https://github.com/rust-lang/libc/pull/4704))
- QNX NTO: Add `cfsetspeed` ([#4704](https://github.com/rust-lang/libc/pull/4704))
- Redox: Add `getresgid` and `getresuid` ([#4752](https://github.com/rust-lang/libc/pull/4752))
- Redox: Add `setresgid` and `setresuid` ([#4752](https://github.com/rust-lang/libc/pull/4752))
- VxWorks: Add definitions from `select.h`, `stat.h`, `poll.h`, `ttycom.h`, `utsname.h`, `resource.h`, `mman.h`, `udp.h`, `in.h`, `in6.h`, `if.h`, `fnmatch.h`, and `sioLibCommon.h` ([#4781](https://github.com/rust-lang/libc/pull/4781))
- VxWorks: Add missing defines/functions needed by rust stdlib ([#4779](https://github.com/rust-lang/libc/pull/4779))
- WASI: Add more definitions for libstd ([#4747](https://github.com/rust-lang/libc/pull/4747))

### Deprecated

- Apple: Deprecate `TIOCREMOTE` ([#4764](https://github.com/rust-lang/libc/pull/4764))

### Fixed

Note that there were a large number of fixes on NetBSD for this `libc` release, some of which include minor breakage.

- AIX: Change errno `EWOULDBLOCK` to make it an alias of `EAGAIN` ([#4790](https://github.com/rust-lang/libc/pull/4790))
- AIX: Resolve function comparison and `unnecessary_transmutes` warnings ([#4780](https://github.com/rust-lang/libc/pull/4780))
- Apple: Correct the value of `SF_SETTABLE` ([#4764](https://github.com/rust-lang/libc/pull/4764))
- DragonflyBSD: Fix the type of `mcontext_t.mc_fpregs` ([#]())
- EspIDF: Fix the duplicate definition of `gethostname` ([#4773](https://github.com/rust-lang/libc/pull/4773))
- L4Re: Update available pthread API ([#4836](https://github.com/rust-lang/libc/pull/4836))
- Linux: Correct the value of `NFT_MSG_MAX` ([#4761](https://github.com/rust-lang/libc/pull/4761))
- Linux: Remove incorrect `repr(align(8))` for `canxl_frame` ([#4760](https://github.com/rust-lang/libc/pull/4760))
- Make `eventfd` argument names match OS docs/headers ([#4830](https://github.com/rust-lang/libc/pull/4830))
- NetBSD: Account for upstream changes to ptrace with LWP ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Correct `ipc_perm`, split from OpenBSD as `ipc.rs` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Correct a number of symbol link names ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Correct the type of `kinfo_vmentry.kve_path` ([#]())
- NetBSD: Fix `uucred.cr_ngroups` from `int` to `short` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Fix the type of `kevent.udata` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Fix the type of `mcontext_t.__fpregs` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Fix the value of `PT_SUSPEND` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Fix the values of FNM_* constants ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Increase the size of `sockaddr_dl.sdl_data` from 12 to 24 ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Introduce `if_.rs`, fix the definition of `ifreq` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Introduce `time.rs`, fix the values of `CLOCK_*_CPUTIME_ID` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Introduce `timex.rs` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Introduce `types.rs`, correct the definition of `lwpid_t` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Introduce `utmp_.rs`, correct the definition of `lastlog` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Introduce `utmpx_.rs`, correct utmpx definitions ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Make `_cpuset` an extern type ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: RISC-V 64: Fix the `mcontext` types ([#4782](https://github.com/rust-lang/libc/pull/4782))
- Nuttx: Resolve warnings ([#4773](https://github.com/rust-lang/libc/pull/4773))
- OHOS: Don't emit duplicate lfs64 definitions ([#4804](https://github.com/rust-lang/libc/pull/4804))
- Redox: Fix the type of `pid_t` ([#4825](https://github.com/rust-lang/libc/pull/4825))
- WASI: Gate `__wasilibc_register_preopened_fd`  ([#4837](https://github.com/rust-lang/libc/pull/4837))
- Wali: Fix unknown config ([#4773](https://github.com/rust-lang/libc/pull/4773))

### Changed

- AIX: Declare field 'tv_nsec' of structure 'timespec' as 'i32' in both 32-bit and 64-bit modes ([#4750](https://github.com/rust-lang/libc/pull/4750))
- DragonFly: Avoid usage of `thread_local` ([#3653](https://github.com/rust-lang/libc/pull/3653))
- Linux: Update the definition for `ucontext_t` and unskip its tests ([#4760](https://github.com/rust-lang/libc/pull/4760))
- MinGW: Set `L_tmpnam` and `TMP_MAX` to the UCRT value ([#4566](https://github.com/rust-lang/libc/pull/4566))
- WASI: More closely align pthread type reprs ([#4747](https://github.com/rust-lang/libc/pull/4747))
- Simplify rustc-check-cfg emission in build.rs ([#4724](https://github.com/rust-lang/libc/pull/4724))
- Transition a number of definitions to the new source structure (internal change)

### Removed

- MIPS Musl: Remove rogue definition of `SIGSTKFLT` ([#4749](https://github.com/rust-lang/libc/pull/4749))
- NetBSD: Make `statvfs.f_spare` non-public ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Remove BPF constants ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Remove `*_MAXID` constants and `AT_SUN_LDPGSIZE` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Remove `IFF_NOTRAILERS` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Remove `vm_size_t` ([#4782](https://github.com/rust-lang/libc/pull/4782))
- NetBSD: Replace REG_ENOSYS with REG_ILLSEQ ([#4782](https://github.com/rust-lang/libc/pull/4782))


## [0.2.177](https://github.com/rust-lang/libc/compare/0.2.176...0.2.177) - 2025-10-09

### Added

- Apple: Add `TIOCGETA`, `TIOCSETA`, `TIOCSETAW`, `TIOCSETAF` constants ([#4736](https://github.com/rust-lang/libc/pull/4736))
- Apple: Add `pthread_cond_timedwait_relative_np` ([#4719](https://github.com/rust-lang/libc/pull/4719))
- BSDs: Add `_CS_PATH` constant ([#4738](https://github.com/rust-lang/libc/pull/4738))
- Linux-like: Add `SIGEMT` for mips* and sparc* architectures ([#4730](https://github.com/rust-lang/libc/pull/4730))
- OpenBSD: Add `elf_aux_info` ([#4729](https://github.com/rust-lang/libc/pull/4729))
- Redox: Add more sysconf constants ([#4728](https://github.com/rust-lang/libc/pull/4728))
- Windows: Add `wcsnlen` ([#4721](https://github.com/rust-lang/libc/pull/4721))

### Changed

- WASIP2: Invert conditional to include p2 APIs ([#4733](https://github.com/rust-lang/libc/pull/4733))

## [0.2.176](https://github.com/rust-lang/libc/compare/0.2.175...0.2.176) - 2025-09-23

### Support

- The default FreeBSD version has been raised from 11 to 12. This matches `rustc` since 1.78. ([#2406](https://github.com/rust-lang/libc/pull/2406))
- `Debug` is now always implemented, rather than being gated behind the `extra_traits` feature. ([#4624](https://github.com/rust-lang/libc/pull/4624))

### Added

- AIX: Restore some non-POSIX functions guarded by the `_KERNEL` macro. ([#4607](https://github.com/rust-lang/libc/pull/4607))
- FreeBSD 14: Add `st_fileref` to `struct stat` ([#4642](https://github.com/rust-lang/libc/pull/4642))
- Haiku: Add the `accept4` POSIX call ([#4586](https://github.com/rust-lang/libc/pull/4586))
- Introduce a wrapper for representing padding ([#4632](https://github.com/rust-lang/libc/pull/4632))
- Linux: Add `EM_RISCV` ([#4659](https://github.com/rust-lang/libc/pull/4659))
- Linux: Add `MS_NOSYMFOLLOW` ([#4389](https://github.com/rust-lang/libc/pull/4389))
- Linux: Add `backtrace_symbols(_fd)` ([#4668](https://github.com/rust-lang/libc/pull/4668))
- Linux: Add missing `SOL_PACKET` optnames ([#4669](https://github.com/rust-lang/libc/pull/4669))
- Musl s390x: Add `SYS_mseal` ([#4549](https://github.com/rust-lang/libc/pull/4549))
- NuttX: Add `__errno` ([#4687](https://github.com/rust-lang/libc/pull/4687))
- Redox: Add `dirfd`, `VDISABLE`, and resource consts ([#4660](https://github.com/rust-lang/libc/pull/4660))
- Redox: Add more `resource.h`, `fcntl.h` constants ([#4666](https://github.com/rust-lang/libc/pull/4666))
- Redox: Enable `strftime` and `mkostemp[s]` ([#4629](https://github.com/rust-lang/libc/pull/4629))
- Unix, Windows: Add `qsort_r` (Unix), and `qsort(_s)` (Windows) ([#4677](https://github.com/rust-lang/libc/pull/4677))
- Unix: Add `dlvsym` for Linux-gnu, FreeBSD, and NetBSD ([#4671](https://github.com/rust-lang/libc/pull/4671))
- Unix: Add `sigqueue` ([#4620](https://github.com/rust-lang/libc/pull/4620))

### Changed

- FreeBSD 15: Mark `kinfo_proc` as non-exhaustive ([#4553](https://github.com/rust-lang/libc/pull/4553))
- FreeBSD: Set the ELF symbol version for `readdir_r` ([#4694](https://github.com/rust-lang/libc/pull/4694))
- Linux: Correct the config for whether or not `epoll_event` is packed ([#4639](https://github.com/rust-lang/libc/pull/4639))
- Tests: Replace the old `ctest` with the much more reliable new implementation ([#4655](https://github.com/rust-lang/libc/pull/4655) and many related PRs)

### Fixed

- AIX: Fix the type of the 4th arguement of `getgrnam_r` ([#4656](https://github.com/rust-lang/libc/pull/4656
- FreeBSD: Limit `P_IDLEPROC` to FreeBSD 15 ([#4640](https://github.com/rust-lang/libc/pull/4640))
- FreeBSD: Limit `mcontext_t::mc_tlsbase` to FreeBSD 15 ([#4640](https://github.com/rust-lang/libc/pull/464))
- FreeBSD: Update gating of `mcontext_t.mc_tlsbase` ([#4703](https://github.com/rust-lang/libc/pull/4703))
- Musl s390x: Correct the definition of `statfs[64]` ([#4549](https://github.com/rust-lang/libc/pull/4549))
- Musl s390x: Make `fpreg_t` a union ([#4549](https://github.com/rust-lang/libc/pull/4549))
- Redox: Fix the types of `gid_t` and `uid_t` ([#4689](https://github.com/rust-lang/libc/pull/4689))
- Redox: Fix the value of `MAP_FIXED` ([#4684](https://github.com/rust-lang/libc/pull/4684))

### Deprecated

- Apple: Correct the `deprecated` attribute for `iconv` ([`a97a0b53`](https://github.com/rust-lang/libc/commit/a97a0b53fb7faf5f99cd720ab12b1b8a5bf9f950))
- FreeBSD: Deprecate `TIOCMGDTRWAIT` and `TIOCMSDTRWAIT` ([#4685](https://github.com/rust-lang/libc/pull/4685))

### Removed

- FreeBSD: Remove `JAIL_{GET,SET}_MASK`, `_MC_FLAG_MASK` ([#4691](https://github.com/rust-lang/libc/pull/4691))

## [0.2.175](https://github.com/rust-lang/libc/compare/0.2.174...0.2.175) - 2025-08-10

### Added

- AIX: Add `getpeereid` ([#4524](https://github.com/rust-lang/libc/pull/4524))
- AIX: Add `struct ld_info` and friends ([#4578](https://github.com/rust-lang/libc/pull/4578))
- AIX: Retore `struct winsize` ([#4577](https://github.com/rust-lang/libc/pull/4577))
- Android: Add UDP socket option constants ([#4619](https://github.com/rust-lang/libc/pull/4619))
- Android: Add `CLONE_CLEAR_SIGHAND` and `CLONE_INTO_CGROUP` ([#4502](https://github.com/rust-lang/libc/pull/4502))
- Android: Add more `prctl` constants ([#4531](https://github.com/rust-lang/libc/pull/4531))
- FreeBSD Add further TCP stack-related constants ([#4196](https://github.com/rust-lang/libc/pull/4196))
- FreeBSD x86-64: Add `mcontext_t.mc_tlsbase ` ([#4503](https://github.com/rust-lang/libc/pull/4503))
- FreeBSD15: Add `kinfo_proc.ki_uerrmsg` ([#4552](https://github.com/rust-lang/libc/pull/4552))
- FreeBSD: Add `in_conninfo` ([#4482](https://github.com/rust-lang/libc/pull/4482))
- FreeBSD: Add `xinpgen` and related types ([#4482](https://github.com/rust-lang/libc/pull/4482))
- FreeBSD: Add `xktls_session` ([#4482](https://github.com/rust-lang/libc/pull/4482))
- Haiku: Add functionality from `libbsd` ([#4221](https://github.com/rust-lang/libc/pull/4221))
- Linux: Add `SECBIT_*` ([#4480](https://github.com/rust-lang/libc/pull/4480))
- NetBSD, OpenBSD: Export `ioctl` request generator macros ([#4460](https://github.com/rust-lang/libc/pull/4460))
- NetBSD: Add `ptsname_r` ([#4608](https://github.com/rust-lang/libc/pull/4608))
- RISCV32: Add time-related syscalls ([#4612](https://github.com/rust-lang/libc/pull/4612))
- Solarish: Add `strftime*` ([#4453](https://github.com/rust-lang/libc/pull/4453))
- linux: Add `EXEC_RESTRICT_*` and `EXEC_DENY_*` ([#4545](https://github.com/rust-lang/libc/pull/4545))

### Changed

- AIX: Add `const` to signatures to be consistent with other platforms ([#4563](https://github.com/rust-lang/libc/pull/4563))

### Fixed

- AIX: Fix the type of `struct statvfs.f_fsid` ([#4576](https://github.com/rust-lang/libc/pull/4576))
- AIX: Fix the type of constants for the `ioctl` `request` argument ([#4582](https://github.com/rust-lang/libc/pull/4582))
- AIX: Fix the types of `stat{,64}.st_*tim` ([#4597](https://github.com/rust-lang/libc/pull/4597))
- AIX: Use unique `errno` values ([#4507](https://github.com/rust-lang/libc/pull/4507))
- Build: Fix an incorrect `target_os` -> `target_arch` check ([#4550](https://github.com/rust-lang/libc/pull/4550))
- FreeBSD: Fix the type of `xktls_session_onedir.ifnet` ([#4552](https://github.com/rust-lang/libc/pull/4552))
- Mips64 musl: Fix the type of `nlink_t` ([#4509](https://github.com/rust-lang/libc/pull/4509))
- Mips64 musl: Use a special MIPS definition of `stack_t` ([#4528](https://github.com/rust-lang/libc/pull/4528))
- Mips64: Fix `SI_TIMER`, `SI_MESGQ` and `SI_ASYNCIO` definitions ([#4529](https://github.com/rust-lang/libc/pull/4529))
- Musl Mips64: Swap the order of `si_errno` and `si_code` in `siginfo_t` ([#4530](https://github.com/rust-lang/libc/pull/4530))
- Musl Mips64: Use a special MIPS definition of `statfs` ([#4527](https://github.com/rust-lang/libc/pull/4527))
- Musl: Fix the definition of `fanotify_event_metadata` ([#4510](https://github.com/rust-lang/libc/pull/4510))
- NetBSD: Correct `enum fae_action` to be `#[repr(C)]` ([#60a8cfd5](https://github.com/rust-lang/libc/commit/60a8cfd564f83164d45b9533ff7a0d7371878f2a))
- PSP: Correct `char` -> `c_char` ([eaab4fc3](https://github.com/rust-lang/libc/commit/eaab4fc3f05dc646a953d4fd5ba46dfa1f8bd6f6))
- PowerPC musl: Fix `termios` definitions ([#4518](https://github.com/rust-lang/libc/pull/4518))
- PowerPC musl: Fix the definition of `EDEADLK` ([#4517](https://github.com/rust-lang/libc/pull/4517))
- PowerPC musl: Fix the definition of `NCCS` ([#4513](https://github.com/rust-lang/libc/pull/4513))
- PowerPC musl: Fix the definitions of `MAP_LOCKED` and `MAP_NORESERVE` ([#4516](https://github.com/rust-lang/libc/pull/4516))
- PowerPC64 musl: Fix the definition of `shmid_ds` ([#4519](https://github.com/rust-lang/libc/pull/4519))

### Deprecated

- Linux: `MAP_32BIT` is only defined on x86 on non-x86 architectures ([#4511](https://github.com/rust-lang/libc/pull/4511))

### Removed

- AIX: Remove duplicate constant definitions `FIND` and `ENTER` ([#4588](https://github.com/rust-lang/libc/pull/4588))
- s390x musl: Remove `O_FSYNC` ([#4515](https://github.com/rust-lang/libc/pull/4515))
- s390x musl: Remove `RTLD_DEEPBIND` ([#4515](https://github.com/rust-lang/libc/pull/4515))


## [0.2.174](https://github.com/rust-lang/libc/compare/0.2.173...0.2.174) - 2025-06-17

### Added

- Linux: Make `pidfd_info` fields pub ([#4487](https://github.com/rust-lang/libc/pull/4487))

### Fixed

- Gnu x32: Add missing `timespec.tv_nsec` ([#4497](https://github.com/rust-lang/libc/pull/4497))
- NuttX: Use `nlink_t` type for `st_nlink` in `struct stat` definition ([#4483](https://github.com/rust-lang/libc/pull/4483))

### Other

- Allow new `unpredictable_function_pointer_comparisons` lints ([#4489](https://github.com/rust-lang/libc/pull/4489))
- OpenBSD: Fix some clippy warnings to use `pointer::cast`. ([#4490](https://github.com/rust-lang/libc/pull/4490))
- Remove unessecary semicolons from definitions of `CMSG_NXTHDR`. ([#4492](https://github.com/rust-lang/libc/pull/4492))


## [0.2.173](https://github.com/rust-lang/libc/compare/0.2.172...0.2.173) - 2025-06-09

### Added

- AIX: Add an AIX triple to Cargo.toml for doc ([#4475](https://github.com/rust-lang/libc/pull/4475))
- FreeBSD: Add the `SO_SPLICE` socket option support for FreeBSD >= 14.2 ([#4451](https://github.com/rust-lang/libc/pull/4451))
- Linux GNU: Prepare for supporting `_TIME_BITS=64` ([#4433](https://github.com/rust-lang/libc/pull/4433))
- Linux: Add constant PACKET_IGNORE_OUTGOING ([#4319](https://github.com/rust-lang/libc/pull/4319))
- Linux: Add constants and types for `nsfs` ioctls ([#4436](https://github.com/rust-lang/libc/pull/4436))
- Linux: Add constants for Memory-Deny-Write-Execute `prctls` ([#4400](https://github.com/rust-lang/libc/pull/4400))
- Linux: Add constants from `linux/cn_proc.h` and `linux/connector.h` ([#4434](https://github.com/rust-lang/libc/pull/4434))
- Linux: Add new flags for `pwritev2` and `preadv2` ([#4452](https://github.com/rust-lang/libc/pull/4452))
- Linux: Add pid_type enum values ([#4403](https://github.com/rust-lang/libc/pull/4403))
- Linux: Update pidfd constants and types (Linux 6.9-6.15) ([#4402](https://github.com/rust-lang/libc/pull/4402))
- Loongarch64 musl: Define the `MADV_SOFT_OFFLINE` constant ([#4448](https://github.com/rust-lang/libc/pull/4448))
- Musl: Add new fields since 1.2.0/1.2.2 to `struct tcp_info` ([#4443](https://github.com/rust-lang/libc/pull/4443))
- Musl: Prepare for supporting v1.2.3 ([#4443](https://github.com/rust-lang/libc/pull/4443))
- NuttX: Add `arc4random` and `arc4random_buf` ([#4464](https://github.com/rust-lang/libc/pull/4464))
- RISC-V Musl: Add `MADV_SOFT_OFFLINE` definition ([#4447](https://github.com/rust-lang/libc/pull/4447))
- Redox: Define SCM_RIGHTS ([#4440](https://github.com/rust-lang/libc/pull/4440))
- VxWorks: Add missing UTIME defines and TASK_RENAME_LENGTH ([#4407](https://github.com/rust-lang/libc/pull/4407))
- Windows: Add more `time.h` functions ([#4427](https://github.com/rust-lang/libc/pull/4427))

### Changed

- Redox: Update `SA_` constants. ([#4426](https://github.com/rust-lang/libc/pull/4426))
- Redox: make `CMSG_ALIGN`, `CMSG_LEN`, and `CMSG_SPACE` const functions ([#4441](https://github.com/rust-lang/libc/pull/4441))

### Fixed

- AIX: Enable libc-test and fix definitions/declarations. ([#4450](https://github.com/rust-lang/libc/pull/4450))
- Emscripten: Fix querying emcc on windows (use emcc.bat) ([#4248](https://github.com/rust-lang/libc/pull/4248))
- Hurd: Fix build from missing `fpos_t` ([#4472](https://github.com/rust-lang/libc/pull/4472))
- Loongarch64 Musl: Fix the `struct ipc_perm` bindings ([#4384](https://github.com/rust-lang/libc/pull/4384))
- Musl: Fix the `O_LARGEFILE` constant value. ([#4443](https://github.com/rust-lang/libc/pull/4443))

## [0.2.172](https://github.com/rust-lang/libc/compare/0.2.171...0.2.172) - 2025-04-14

### Added

- Android: Add `getauxval` for 32-bit targets ([#4338](https://github.com/rust-lang/libc/pull/4338))
- Android: Add `if_tun.h` ioctls ([#4379](https://github.com/rust-lang/libc/pull/4379))
- Android: Define `SO_BINDTOIFINDEX` ([#4391](https://github.com/rust-lang/libc/pull/4391))
- Cygwin: Add `posix_spawn_file_actions_add[f]chdir[_np]` ([#4387](https://github.com/rust-lang/libc/pull/4387))
- Cygwin: Add new socket options ([#4350](https://github.com/rust-lang/libc/pull/4350))
- Cygwin: Add statfs & fcntl ([#4321](https://github.com/rust-lang/libc/pull/4321))
- FreeBSD: Add `filedesc` and `fdescenttbl` ([#4327](https://github.com/rust-lang/libc/pull/4327))
- Glibc: Add unstable support for _FILE_OFFSET_BITS=64 ([#4345](https://github.com/rust-lang/libc/pull/4345))
- Hermit: Add `AF_UNSPEC` ([#4344](https://github.com/rust-lang/libc/pull/4344))
- Hermit: Add `AF_VSOCK` ([#4344](https://github.com/rust-lang/libc/pull/4344))
- Illumos, NetBSD: Add `timerfd` APIs ([#4333](https://github.com/rust-lang/libc/pull/4333))
- Linux: Add `_IO`, `_IOW`, `_IOR`, `_IOWR` to the exported API ([#4325](https://github.com/rust-lang/libc/pull/4325))
- Linux: Add `tcp_info` to uClibc bindings ([#4347](https://github.com/rust-lang/libc/pull/4347))
- Linux: Add further BPF program flags ([#4356](https://github.com/rust-lang/libc/pull/4356))
- Linux: Add missing INPUT_PROP_XXX flags from `input-event-codes.h` ([#4326](https://github.com/rust-lang/libc/pull/4326))
- Linux: Add missing TLS bindings ([#4296](https://github.com/rust-lang/libc/pull/4296))
- Linux: Add more constants from `seccomp.h` ([#4330](https://github.com/rust-lang/libc/pull/4330))
- Linux: Add more glibc `ptrace_sud_config` and related `PTRACE_*ET_SYSCALL_USER_DISPATCH_CONFIG`. ([#4386](https://github.com/rust-lang/libc/pull/4386))
- Linux: Add new netlink flags ([#4288](https://github.com/rust-lang/libc/pull/4288))
- Linux: Define ioctl codes on more architectures ([#4382](https://github.com/rust-lang/libc/pull/4382))
- Linux: Add missing `pthread_attr_setstack` ([#4349](https://github.com/rust-lang/libc/pull/4349))
- Musl: Add missing `utmpx` API ([#4332](https://github.com/rust-lang/libc/pull/4332))
- Musl: Enable `getrandom` on all platforms ([#4346](https://github.com/rust-lang/libc/pull/4346))
- NuttX: Add more signal constants ([#4353](https://github.com/rust-lang/libc/pull/4353))
- QNX: Add QNX 7.1-iosock and 8.0 to list of additional cfgs ([#4169](https://github.com/rust-lang/libc/pull/4169))
- QNX: Add support for alternative Neutrino network stack `io-sock` ([#4169](https://github.com/rust-lang/libc/pull/4169))
- Redox: Add more `sys/socket.h` and `sys/uio.h` definitions ([#4388](https://github.com/rust-lang/libc/pull/4388))
- Solaris: Temporarily define `O_DIRECT` and `SIGINFO` ([#4348](https://github.com/rust-lang/libc/pull/4348))
- Solarish: Add `secure_getenv` ([#4342](https://github.com/rust-lang/libc/pull/4342))
- VxWorks: Add missing `d_type` member to `dirent` ([#4352](https://github.com/rust-lang/libc/pull/4352))
- VxWorks: Add missing signal-related constsants ([#4352](https://github.com/rust-lang/libc/pull/4352))
- VxWorks: Add more error codes ([#4337](https://github.com/rust-lang/libc/pull/4337))

### Deprecated

- FreeBSD: Deprecate `TCP_PCAP_OUT` and `TCP_PCAP_IN` ([#4381](https://github.com/rust-lang/libc/pull/4381))

### Fixed

- Cygwin: Fix member types of `statfs` ([#4324](https://github.com/rust-lang/libc/pull/4324))
- Cygwin: Fix tests  ([#4357](https://github.com/rust-lang/libc/pull/4357))
- Hermit: Make `AF_INET = 3` ([#4344](https://github.com/rust-lang/libc/pull/4344))
- Musl: Fix the syscall table on RISC-V-32 ([#4335](https://github.com/rust-lang/libc/pull/4335))
- Musl: Fix the value of `SA_ONSTACK` on RISC-V-32 ([#4335](https://github.com/rust-lang/libc/pull/4335))
- VxWorks: Fix a typo in the `waitpid` parameter name ([#4334](https://github.com/rust-lang/libc/pull/4334))

### Removed

- Musl: Remove `O_FSYNC` on RISC-V-32 (use `O_SYNC` instead) ([#4335](https://github.com/rust-lang/libc/pull/4335))
- Musl: Remove `RTLD_DEEPBIND` on RISC-V-32 ([#4335](https://github.com/rust-lang/libc/pull/4335))

### Other

- CI: Add matrix env variables to the environment ([#4345](https://github.com/rust-lang/libc/pull/4345))
- CI: Always deny warnings ([#4363](https://github.com/rust-lang/libc/pull/4363))
- CI: Always upload successfully created artifacts ([#4345](https://github.com/rust-lang/libc/pull/4345))
- CI: Install musl from source for loongarch64 ([#4320](https://github.com/rust-lang/libc/pull/4320))
- CI: Revert "Also skip `MFD_EXEC` and `MFD_NOEXEC_SEAL` on sparc64" ([#]())
- CI: Use `$PWD` instead of `$(pwd)` in run-docker ([#4345](https://github.com/rust-lang/libc/pull/4345))
- Solarish: Restrict `openpty` and `forkpty` polyfills to Illumos, replace Solaris implementation with bindings ([#4329](https://github.com/rust-lang/libc/pull/4329))
- Testing: Ensure the makedev test does not emit unused errors ([#4363](https://github.com/rust-lang/libc/pull/4363))

## [0.2.171](https://github.com/rust-lang/libc/compare/0.2.170...0.2.171) - 2025-03-11

### Added

- Android: Add `if_nameindex`/`if_freenameindex` support ([#4247](https://github.com/rust-lang/libc/pull/4247))
- Apple: Add missing proc types and constants ([#4310](https://github.com/rust-lang/libc/pull/4310))
- BSD: Add `devname` ([#4285](https://github.com/rust-lang/libc/pull/4285))
- Cygwin: Add PTY and group API ([#4309](https://github.com/rust-lang/libc/pull/4309))
- Cygwin: Add support ([#4279](https://github.com/rust-lang/libc/pull/4279))
- FreeBSD: Make `spawn.h` interfaces available on all FreeBSD-like systems ([#4294](https://github.com/rust-lang/libc/pull/4294))
- Linux: Add `AF_XDP` structs for all Linux environments ([#4163](https://github.com/rust-lang/libc/pull/4163))
- Linux: Add SysV semaphore constants ([#4286](https://github.com/rust-lang/libc/pull/4286))
- Linux: Add `F_SEAL_EXEC` ([#4316](https://github.com/rust-lang/libc/pull/4316))
- Linux: Add `SO_PREFER_BUSY_POLL` and `SO_BUSY_POLL_BUDGET` ([#3917](https://github.com/rust-lang/libc/pull/3917))
- Linux: Add `devmem` structs ([#4299](https://github.com/rust-lang/libc/pull/4299))
- Linux: Add socket constants up to `SO_DEVMEM_DONTNEED` ([#4299](https://github.com/rust-lang/libc/pull/4299))
- NetBSD, OpenBSD, DragonflyBSD: Add `closefrom` ([#4290](https://github.com/rust-lang/libc/pull/4290))
- NuttX: Add `pw_passwd` field to `passwd` ([#4222](https://github.com/rust-lang/libc/pull/4222))
- Solarish: define `IP_BOUND_IF` and `IPV6_BOUND_IF` ([#4287](https://github.com/rust-lang/libc/pull/4287))
- Wali: Add bindings for `wasm32-wali-linux-musl` target ([#4244](https://github.com/rust-lang/libc/pull/4244))

### Changed

- AIX: Use `sa_sigaction` instead of a union ([#4250](https://github.com/rust-lang/libc/pull/4250))
- Make `msqid_ds.__msg_cbytes` public ([#4301](https://github.com/rust-lang/libc/pull/4301))
- Unix: Make all `major`, `minor`, `makedev` into `const fn` ([#4208](https://github.com/rust-lang/libc/pull/4208))

### Deprecated

- Linux: Deprecate obsolete packet filter interfaces ([#4267](https://github.com/rust-lang/libc/pull/4267))

### Fixed

- Cygwin: Fix strerror_r ([#4308](https://github.com/rust-lang/libc/pull/4308))
- Cygwin: Fix usage of f! ([#4308](https://github.com/rust-lang/libc/pull/4308))
- Hermit: Make `stat::st_size` signed ([#4298](https://github.com/rust-lang/libc/pull/4298))
- Linux: Correct values for `SI_TIMER`, `SI_MESGQ`, `SI_ASYNCIO` ([#4292](https://github.com/rust-lang/libc/pull/4292))
- NuttX: Update `tm_zone` and `d_name` fields to use `c_char` type ([#4222](https://github.com/rust-lang/libc/pull/4222))
- Xous: Include the prelude to define `c_int` ([#4304](https://github.com/rust-lang/libc/pull/4304))

### Other

- Add labels to FIXMEs ([#4231](https://github.com/rust-lang/libc/pull/4231), [#4232](https://github.com/rust-lang/libc/pull/4232), [#4234](https://github.com/rust-lang/libc/pull/4234), [#4235](https://github.com/rust-lang/libc/pull/4235), [#4236](https://github.com/rust-lang/libc/pull/4236))
- CI: Fix "cannot find libc" error on Sparc64 ([#4317](https://github.com/rust-lang/libc/pull/4317))
- CI: Fix "cannot find libc" error on s390x ([#4317](https://github.com/rust-lang/libc/pull/4317))
- CI: Pass `--no-self-update` to `rustup update` ([#4306](https://github.com/rust-lang/libc/pull/4306))
- CI: Remove tests for the `i586-pc-windows-msvc` target ([#4311](https://github.com/rust-lang/libc/pull/4311))
- CI: Remove the `check_cfg` job ([#4322](https://github.com/rust-lang/libc/pull/4312))
- Change the range syntax that is giving `ctest` problems ([#4311](https://github.com/rust-lang/libc/pull/4311))
- Linux: Split out the stat struct for gnu/b32/mips ([#4276](https://github.com/rust-lang/libc/pull/4276))

### Removed

- NuttX: Remove `pthread_set_name_np` ([#4251](https://github.com/rust-lang/libc/pull/4251))

## [0.2.170](https://github.com/rust-lang/libc/compare/0.2.169...0.2.170) - 2025-02-23

### Added

- Android: Declare `setdomainname` and `getdomainname` <https://github.com/rust-lang/libc/pull/4212>
- FreeBSD: Add `evdev` structures <https://github.com/rust-lang/libc/pull/3756>
- FreeBSD: Add the new `st_filerev` field to `stat32` ([#4254](https://github.com/rust-lang/libc/pull/4254))
- Linux: Add `SI_*`` and `TRAP_*`` signal codes <https://github.com/rust-lang/libc/pull/4225>
- Linux: Add experimental configuration to enable 64-bit time in kernel APIs, set by `RUST_LIBC_UNSTABLE_LINUX_TIME_BITS64`. <https://github.com/rust-lang/libc/pull/4148>
- Linux: Add recent socket timestamping flags <https://github.com/rust-lang/libc/pull/4273>
- Linux: Added new CANFD_FDF flag for the flags field of canfd_frame <https://github.com/rust-lang/libc/pull/4223>
- Musl: add CLONE_NEWTIME <https://github.com/rust-lang/libc/pull/4226>
- Solarish: add the posix_spawn family of functions <https://github.com/rust-lang/libc/pull/4259>

### Deprecated

- Linux: deprecate kernel modules syscalls <https://github.com/rust-lang/libc/pull/4228>

### Changed

- Emscripten: Assume version is at least 3.1.42 <https://github.com/rust-lang/libc/pull/4243>

### Fixed

- BSD: Correct the definition of `WEXITSTATUS` <https://github.com/rust-lang/libc/pull/4213>
- Hurd: Fix CMSG_DATA on 64bit systems ([#4240](https://github.com/rust-lang/libc/pull/424))
- NetBSD: fix `getmntinfo` ([#4265](https://github.com/rust-lang/libc/pull/4265)
- VxWorks: Fix the size of `time_t` <https://github.com/rust-lang/libc/pull/426>

### Other

- Add labels to FIXMEs <https://github.com/rust-lang/libc/pull/4230>, <https://github.com/rust-lang/libc/pull/4229>, <https://github.com/rust-lang/libc/pull/4237>
- CI: Bump FreeBSD CI to 13.4 and 14.2 <https://github.com/rust-lang/libc/pull/4260>
- Copy definitions from core::ffi and centralize them <https://github.com/rust-lang/libc/pull/4256>
- Define c_char at top-level and remove per-target c_char definitions <https://github.com/rust-lang/libc/pull/4202>
- Port style.rs to syn and add tests for the style checker <https://github.com/rust-lang/libc/pull/4220>

## [0.2.169](https://github.com/rust-lang/libc/compare/0.2.168...0.2.169) - 2024-12-18

### Added

- FreeBSD: add more socket TCP stack constants <https://github.com/rust-lang/libc/pull/4193>
- Fuchsia: add a `sockaddr_vm` definition <https://github.com/rust-lang/libc/pull/4194>

### Fixed

**Breaking**: [rust-lang/rust#132975](https://github.com/rust-lang/rust/pull/132975) corrected the signedness of `core::ffi::c_char` on various Tier 2 and Tier 3 platforms (mostly Arm and RISC-V) to match Clang. This release contains the corresponding changes to `libc`, including the following specific pull requests:

- ESP-IDF: Replace arch-conditional `c_char` with a reexport <https://github.com/rust-lang/libc/pull/4195>
- Fix `c_char` on various targets <https://github.com/rust-lang/libc/pull/4199>
- Mirror `c_char` configuration from `rust-lang/rust` <https://github.com/rust-lang/libc/pull/4198>

### Cleanup

- Do not re-export `c_void` in target-specific code <https://github.com/rust-lang/libc/pull/4200>

## [0.2.168](https://github.com/rust-lang/libc/compare/0.2.167...0.2.168) - 2024-12-09

### Added

- Linux: Add new process flags ([#4174](https://github.com/rust-lang/libc/pull/4174))
- Linux: Make `IFA_*` constants available on all Linux targets <https://github.com/rust-lang/libc/pull/4185>
- Linux: add `MAP_DROPPABLE` <https://github.com/rust-lang/libc/pull/4173>
- Solaris, Illumos: add `SIGRTMIN` and `SIGRTMAX` <https://github.com/rust-lang/libc/pull/4171>
- Unix, Linux: adding POSIX `memccpy` and `mempcpy` GNU extension <https://github.com/rust-lang/libc/pull/4186.

### Deprecated

- FreeBSD: Deprecate the CAP_UNUSED* and CAP_ALL* constants ([#4183](https://github.com/rust-lang/libc/pull/4183))

### Fixed

- Make the `Debug` implementation for unions opaque ([#4176](https://github.com/rust-lang/libc/pull/4176))

### Other

- Allow the `unpredictable_function_pointer_comparisons` lint where needed <https://github.com/rust-lang/libc/pull/4177>
- CI: Upload artifacts created by libc-test <https://github.com/rust-lang/libc/pull/4180>
- CI: Use workflow commands to group output by target <https://github.com/rust-lang/libc/pull/4179>
- CI: add caching <https://github.com/rust-lang/libc/pull/4183>

## [0.2.167](https://github.com/rust-lang/libc/compare/0.2.166...0.2.167) - 2024-11-28

### Added

- Solarish: add `st_fstype` to `stat` <https://github.com/rust-lang/libc/pull/4145>
- Trusty: Add `intptr_t` and `uintptr_t` ([#4161](https://github.com/rust-lang/libc/pull/4161))

### Fixed

- Fix the build with `rustc-dep-of-std` <https://github.com/rust-lang/libc/pull/4158>
- Wasi: Add back unsafe block for `clockid_t` static variables ([#4157](https://github.com/rust-lang/libc/pull/4157))

### Cleanup

- Create an internal prelude <https://github.com/rust-lang/libc/pull/4161>
- Fix `unused_qualifications`<https://github.com/rust-lang/libc/pull/4132>

### Other

- CI: Check various FreeBSD versions ([#4159](https://github.com/rust-lang/libc/pull/4159))
- CI: add a timeout for all jobs <https://github.com/rust-lang/libc/pull/4164>
- CI: verify MSRV for `wasm32-wasi` <https://github.com/rust-lang/libc/pull/4157>
- Migrate to the 2021 edition <https://github.com/rust-lang/libc/pull/4132>

### Removed

- Remove one unused import after the edition 2021 bump

## [0.2.166](https://github.com/rust-lang/libc/compare/0.2.165...0.2.166) - 2024-11-26

### Fixed

This release resolves two cases of unintentional breakage from the previous release:

- Revert removal of array size hacks [#4150](https://github.com/rust-lang/libc/pull/4150)
- Ensure `const extern` functions are always enabled [#4151](https://github.com/rust-lang/libc/pull/4151)

## [0.2.165](https://github.com/rust-lang/libc/compare/0.2.164...0.2.165) - 2024-11-25

### Added

- Android: add `mkostemp`, `mkostemps` <https://github.com/rust-lang/libc/pull/3601>
- Android: add a few API 30 calls <https://github.com/rust-lang/libc/pull/3604>
- Android: add missing syscall constants <https://github.com/rust-lang/libc/pull/3558>
- Apple: add `in6_ifreq` <https://github.com/rust-lang/libc/pull/3617>
- Apple: add missing `sysctl` net types <https://github.com/rust-lang/libc/pull/4022> (before release: remove `if_family_id` ([#4137](https://github.com/rust-lang/libc/pulls/4137)))
- Freebsd: add `kcmp` call support <https://github.com/rust-lang/libc/pull/3746>
- Hurd: add `MAP_32BIT` and `MAP_EXCL` <https://github.com/rust-lang/libc/pull/4127>
- Hurd: add `domainname` field to `utsname` ([#4089](https://github.com/rust-lang/libc/pulls/4089))
- Linux GNU: add `f_flags` to struct `statfs` for arm, mips, powerpc and x86 <https://github.com/rust-lang/libc/pull/3663>
- Linux GNU: add `malloc_stats` <https://github.com/rust-lang/libc/pull/3596>
- Linux: add ELF relocation-related structs <https://github.com/rust-lang/libc/pull/3583>
- Linux: add `ptp_*` structs <https://github.com/rust-lang/libc/pull/4113>
- Linux: add `ptp_clock_caps` <https://github.com/rust-lang/libc/pull/4128>
- Linux: add `ptp_pin_function` and most `PTP_` constants <https://github.com/rust-lang/libc/pull/4114>
- Linux: add missing AF_XDP structs & constants <https://github.com/rust-lang/libc/pull/3956>
- Linux: add missing netfilter consts ([#3734](https://github.com/rust-lang/libc/pulls/3734))
- Linux: add struct and constants for the `mount_setattr` syscall <https://github.com/rust-lang/libc/pull/4046>
- Linux: add wireless API <https://github.com/rust-lang/libc/pull/3441>
- Linux: expose the `len8_dlc` field of `can_frame` <https://github.com/rust-lang/libc/pull/3357>
- Musl: add `utmpx` API <https://github.com/rust-lang/libc/pull/3213>
- Musl: add missing syscall constants <https://github.com/rust-lang/libc/pull/4028>
- NetBSD: add `mcontext`-related data for RISCV64 <https://github.com/rust-lang/libc/pull/3468>
- Redox: add new `netinet` constants <https://github.com/rust-lang/libc/pull/3586>)
- Solarish: add `_POSIX_VDISABLE` ([#4103](https://github.com/rust-lang/libc/pulls/4103))
- Tests: Add a test that the `const extern fn` macro works <https://github.com/rust-lang/libc/pull/4134>
- Tests: Add test of primitive types against `std` <https://github.com/rust-lang/libc/pull/3616>
- Unix: Add `htonl`, `htons`, `ntohl`, `ntohs` <https://github.com/rust-lang/libc/pull/3669>
- Unix: add `aligned_alloc` <https://github.com/rust-lang/libc/pull/3843>
- Windows: add `aligned_realloc` <https://github.com/rust-lang/libc/pull/3592>

### Fixed

- **breaking** Hurd: fix `MAP_HASSEMAPHORE` name ([#4127](https://github.com/rust-lang/libc/pulls/4127))
- **breaking** ulibc Mips: fix `SA_*` mismatched types ([#3211](https://github.com/rust-lang/libc/pulls/3211))
- Aix: fix an enum FFI safety warning <https://github.com/rust-lang/libc/pull/3644>
- Haiku: fix some typos ([#3664](https://github.com/rust-lang/libc/pulls/3664))
- Tests: fix `Elf{32,64}_Relr`-related tests <https://github.com/rust-lang/libc/pull/3647>
- Tests: fix libc-tests for `loongarch64-linux-musl`
- Tests: fix some clippy warnings <https://github.com/rust-lang/libc/pull/3855>
- Tests: fix tests on `riscv64gc-unknown-freebsd` <https://github.com/rust-lang/libc/pull/4129>

### Deprecated

- Apple: deprecate `iconv_open` <https://github.com/rust-lang/libc/commit/25e022a22eca3634166ef472b748c297e60fcf7f>
- Apple: deprecate `mach_task_self` <https://github.com/rust-lang/libc/pull/4095>
- Apple: update `mach` deprecation notices for things that were removed in `main` <https://github.com/rust-lang/libc/pull/4097>

### Cleanup

- Adjust the `f!` macro to be more flexible <https://github.com/rust-lang/libc/pull/4107>
- Aix: remove duplicate constants <https://github.com/rust-lang/libc/pull/3643>
- CI: make scripts more uniform <https://github.com/rust-lang/libc/pull/4042>
- Drop the `libc_align` conditional <https://github.com/rust-lang/libc/commit/b5b553d0ee7de0d4781432a9a9a0a6445dd7f34f>
- Drop the `libc_cfg_target_vendor` conditional <https://github.com/rust-lang/libc/pull/4060>
- Drop the `libc_const_size_of` conditional <https://github.com/rust-lang/libc/commit/5a43dd2754366f99b3a83881b30246ce0e51833c>
- Drop the `libc_core_cvoid` conditional <https://github.com/rust-lang/libc/pull/4060>
- Drop the `libc_int128` conditional <https://github.com/rust-lang/libc/pull/4060>
- Drop the `libc_non_exhaustive` conditional <https://github.com/rust-lang/libc/pull/4060>
- Drop the `libc_packedN` conditional <https://github.com/rust-lang/libc/pull/4060>
- Drop the `libc_priv_mod_use` conditional <https://github.com/rust-lang/libc/commit/19c59376d11b015009fb9b04f233a30a1bf50a91>
- Drop the `libc_union` conditional <https://github.com/rust-lang/libc/commit/b9e4d8012f612dfe24147da3e69522763f92b6e3>
- Drop the `long_array` conditional <https://github.com/rust-lang/libc/pull/4096>
- Drop the `ptr_addr_of` conditional <https://github.com/rust-lang/libc/pull/4065>
- Drop warnings about deprecated cargo features <https://github.com/rust-lang/libc/pull/4060>
- Eliminate uses of `struct_formatter` <https://github.com/rust-lang/libc/pull/4074>
- Fix a few other array size hacks <https://github.com/rust-lang/libc/commit/d63be8b69b0736753213f5d933767866a5801ee7>
- Glibc: remove redundant definitions ([#3261](https://github.com/rust-lang/libc/pulls/3261))
- Musl: remove redundant definitions ([#3261](https://github.com/rust-lang/libc/pulls/3261))
- Musl: unify definitions of `siginfo_t` ([#3261](https://github.com/rust-lang/libc/pulls/3261))
- Musl: unify definitions of statfs and statfs64 ([#3261](https://github.com/rust-lang/libc/pulls/3261))
- Musl: unify definitions of statvfs and statvfs64 ([#3261](https://github.com/rust-lang/libc/pulls/3261))
- Musl: unify statx definitions ([#3978](https://github.com/rust-lang/libc/pulls/3978))
- Remove array size hacks for Rust < 1.47 <https://github.com/rust-lang/libc/commit/27ee6fe02ca0848b2af3cd747536264e4c7b697d>
- Remove repetitive words <https://github.com/rust-lang/libc/commit/77de375891285e18a81616f7dceda6d52732eed6>
- Use #[derive] for Copy/Clone in s! and friends <https://github.com/rust-lang/libc/pull/4038>
- Use some tricks to format macro bodies <https://github.com/rust-lang/libc/pull/4107>

### Other

- Apply formatting to macro bodies <https://github.com/rust-lang/libc/pull/4107>
- Bump libc-test to Rust 2021 Edition <https://github.com/rust-lang/libc/pull/3905>
- CI: Add a check that semver files don't contain duplicate entries <https://github.com/rust-lang/libc/pull/4087>
- CI: Add `fanotify_event_info_fid` to FAM-exempt types <https://github.com/rust-lang/libc/pull/4038>
- CI: Allow rustfmt to organize imports ([#4136](https://github.com/rust-lang/libc/pulls/4136))
- CI: Always run rustfmt <https://github.com/rust-lang/libc/pull/4120>
- CI: Change 32-bit Docker images to use EOL repos <https://github.com/rust-lang/libc/pull/4120>
- CI: Change 64-bit Docker images to ubuntu:24.10 <https://github.com/rust-lang/libc/pull/4120>
- CI: Disable the check for >1 s! invocation <https://github.com/rust-lang/libc/pull/4107>
- CI: Ensure build channels get run even if FILTER is unset <https://github.com/rust-lang/libc/pull/4125>
- CI: Ensure there is a fallback for no_std <https://github.com/rust-lang/libc/pull/4125>
- CI: Fix cases where unset variables cause errors <https://github.com/rust-lang/libc/pull/4108>
- CI: Naming adjustments and cleanup <https://github.com/rust-lang/libc/pull/4124>
- CI: Only invoke rustup if running in CI <https://github.com/rust-lang/libc/pull/4107>
- CI: Remove the logic to handle old rust versions <https://github.com/rust-lang/libc/pull/4068>
- CI: Set -u (error on unset) in all script files <https://github.com/rust-lang/libc/pull/4108>
- CI: add support for `loongarch64-unknown-linux-musl` <https://github.com/rust-lang/libc/pull/4092>
- CI: make `aarch64-apple-darwin` not a nightly-only target <https://github.com/rust-lang/libc/pull/4068>
- CI: run shellcheck on all scripts <https://github.com/rust-lang/libc/pull/4042>
- CI: update musl headers to Linux 6.6 <https://github.com/rust-lang/libc/pull/3921>
- CI: use qemu-sparc64 to run sparc64 tests <https://github.com/rust-lang/libc/pull/4133>
- Drop the `libc_const_extern_fn` conditional <https://github.com/rust-lang/libc/commit/674cc1f47f605038ef1aa2cce8e8bc9dac128276>
- Drop the `libc_underscore_const_names` conditional <https://github.com/rust-lang/libc/commit/f0febd5e2e50b38e05259d3afad3c9783711bcf0>
- Explicitly set the edition to 2015 <https://github.com/rust-lang/libc/pull/4058>
- Introduce a `git-blame-ignore-revs` file <https://github.com/rust-lang/libc/pull/4107>
- Tests: Ignore fields as required on Ubuntu 24.10 <https://github.com/rust-lang/libc/pull/4120>
- Tests: skip `ATF_*` constants for OpenBSD <https://github.com/rust-lang/libc/pull/4088>
- Triagebot: Add an autolabel for CI <https://github.com/rust-lang/libc/pull/4052>

## [0.2.164](https://github.com/rust-lang/libc/compare/0.2.163...0.2.164) - 2024-11-16

### MSRV

This release increases the MSRV of `libc` to 1.63.

### Other

- CI: remove tests with rust < 1.63 <https://github.com/rust-lang/libc/pull/4051>
- MSRV: document the MSRV of the stable channel to be 1.63 <https://github.com/rust-lang/libc/pull/4040>
- MacOS: move ifconf to s_no_extra_traits <https://github.com/rust-lang/libc/pull/4051>

## [0.2.163](https://github.com/rust-lang/libc/compare/0.2.162...0.2.163) - 2024-11-16

### Added

- Aix: add more `dlopen` flags <https://github.com/rust-lang/libc/pull/4044>
- Android: add group calls <https://github.com/rust-lang/libc/pull/3499>
- FreeBSD: add `TCP_FUNCTION_BLK` and `TCP_FUNCTION_ALIAS` <https://github.com/rust-lang/libc/pull/4047>
- Linux: add `confstr` <https://github.com/rust-lang/libc/pull/3612>
- Solarish: add `aio` <https://github.com/rust-lang/libc/pull/4033>
- Solarish: add `arc4random*` <https://github.com/rust-lang/libc/pull/3944>

### Changed

- Emscripten: upgrade emsdk to 3.1.68 <https://github.com/rust-lang/libc/pull/3962>
- Hurd: use more standard types <https://github.com/rust-lang/libc/pull/3733>
- Hurd: use the standard `ssize_t = isize` <https://github.com/rust-lang/libc/pull/4029>
- Solaris: fix `confstr` and `ucontext_t` <https://github.com/rust-lang/libc/pull/4035>

### Other

- CI: add Solaris <https://github.com/rust-lang/libc/pull/4035>
- CI: add `i686-unknown-freebsd` <https://github.com/rust-lang/libc/pull/3997>
- CI: ensure that calls to `sort` do not depend on locale <https://github.com/rust-lang/libc/pull/4026>
- Specify `rust-version` in `Cargo.toml` <https://github.com/rust-lang/libc/pull/4041>

## [0.2.162](https://github.com/rust-lang/libc/compare/0.2.161...0.2.162) - 2024-11-07

### Added

- Android: fix the alignment of `uc_mcontext` on arm64 <https://github.com/rust-lang/libc/pull/3894>
- Apple: add `host_cpu_load_info` <https://github.com/rust-lang/libc/pull/3916>
- ESP-IDF: add a time flag <https://github.com/rust-lang/libc/pull/3993>
- FreeBSD: add the `CLOSE_RANGE_CLOEXEC` flag<https://github.com/rust-lang/libc/pull/3996>
- FreeBSD: fix test errors regarding `__gregset_t` <https://github.com/rust-lang/libc/pull/3995>
- FreeBSD: fix tests on x86 FreeBSD 15 <https://github.com/rust-lang/libc/pull/3948>
- FreeBSD: make `ucontext_t` and `mcontext_t` available on all architectures  <https://github.com/rust-lang/libc/pull/3848>
- Haiku: add `getentropy` <https://github.com/rust-lang/libc/pull/3991>
- Illumos: add `syncfs` <https://github.com/rust-lang/libc/pull/3990>
- Illumos: add some recently-added constants <https://github.com/rust-lang/libc/pull/3999>
- Linux: add `ioctl` flags <https://github.com/rust-lang/libc/pull/3960>
- Linux: add epoll busy polling parameters <https://github.com/rust-lang/libc/pull/3922>
- NuttX: add `pthread_[get/set]name_np` <https://github.com/rust-lang/libc/pull/4003>
- RTEMS: add `arc4random_buf` <https://github.com/rust-lang/libc/pull/3989>
- Trusty OS: add initial support <https://github.com/rust-lang/libc/pull/3942>
- WASIp2: expand socket support <https://github.com/rust-lang/libc/pull/3981>

### Fixed

- Emscripten: don't pass `-lc` <https://github.com/rust-lang/libc/pull/4002>
- Hurd: change `st_fsid` field to `st_dev` <https://github.com/rust-lang/libc/pull/3785>
- Hurd: fix the definition of `utsname` <https://github.com/rust-lang/libc/pull/3992>
- Illumos/Solaris: fix `FNM_CASEFOLD` definition <https://github.com/rust-lang/libc/pull/4004>
- Solaris: fix all tests <https://github.com/rust-lang/libc/pull/3864>

### Other

- CI: Add loongarch64 <https://github.com/rust-lang/libc/pull/4000>
- CI: Check that semver files are sorted <https://github.com/rust-lang/libc/pull/4018>
- CI: Re-enable the FreeBSD 15 job <https://github.com/rust-lang/libc/pull/3988>
- Clean up imports and `extern crate` usage <https://github.com/rust-lang/libc/pull/3897>
- Convert `mode_t` constants to octal <https://github.com/rust-lang/libc/pull/3634>
- Remove the `wasm32-wasi` target that has been deleted upstream <https://github.com/rust-lang/libc/pull/4013>

## [0.2.161](https://github.com/rust-lang/libc/compare/0.2.160...0.2.161) - 2024-10-17

### Fixed

- OpenBSD: fix `FNM_PATHNAME` and `FNM_NOESCAPE` values <https://github.com/rust-lang/libc/pull/3983>

## [0.2.160](https://github.com/rust-lang/libc/compare/0.2.159...0.2.160) - 2024-10-17

### Added

- Android: add `PR_GET_NAME` and `PR_SET_NAME` <https://github.com/rust-lang/libc/pull/3941>
- Apple: add `F_TRANSFEREXTENTS` <https://github.com/rust-lang/libc/pull/3925>
- Apple: add `mach_error_string` <https://github.com/rust-lang/libc/pull/3913>
- Apple: add additional `pthread` APIs <https://github.com/rust-lang/libc/pull/3846>
- Apple: add the `LOCAL_PEERTOKEN` socket option <https://github.com/rust-lang/libc/pull/3929>
- BSD: add `RTF_*`, `RTA_*`, `RTAX_*`, and `RTM_*` definitions <https://github.com/rust-lang/libc/pull/3714>
- Emscripten: add `AT_EACCESS` <https://github.com/rust-lang/libc/pull/3911>
- Emscripten: add `getgrgid`, `getgrnam`, `getgrnam_r` and `getgrgid_r` <https://github.com/rust-lang/libc/pull/3912>
- Emscripten: add `getpwnam_r` and `getpwuid_r` <https://github.com/rust-lang/libc/pull/3906>
- FreeBSD: add `POLLRDHUP` <https://github.com/rust-lang/libc/pull/3936>
- Haiku: add `arc4random` <https://github.com/rust-lang/libc/pull/3945>
- Illumos: add `ptsname_r` <https://github.com/rust-lang/libc/pull/3867>
- Linux: add `fanotify` interfaces <https://github.com/rust-lang/libc/pull/3695>
- Linux: add `tcp_info` <https://github.com/rust-lang/libc/pull/3480>
- Linux: add additional AF_PACKET options <https://github.com/rust-lang/libc/pull/3540>
- Linux: make Elf constants always available <https://github.com/rust-lang/libc/pull/3938>
- Musl x86: add `iopl` and `ioperm` <https://github.com/rust-lang/libc/pull/3720>
- Musl: add `posix_spawn` chdir functions <https://github.com/rust-lang/libc/pull/3949>
- Musl: add `utmpx.h` constants <https://github.com/rust-lang/libc/pull/3908>
- NetBSD: add `sysctlnametomib`, `CLOCK_THREAD_CPUTIME_ID` and `CLOCK_PROCESS_CPUTIME_ID` <https://github.com/rust-lang/libc/pull/3927>
- Nuttx: initial support <https://github.com/rust-lang/libc/pull/3909>
- RTEMS: add `getentropy` <https://github.com/rust-lang/libc/pull/3973>
- RTEMS: initial support <https://github.com/rust-lang/libc/pull/3866>
- Solarish: add `POLLRDHUP`, `POSIX_FADV_*`, `O_RSYNC`, and `posix_fallocate` <https://github.com/rust-lang/libc/pull/3936>
- Unix: add `fnmatch.h` <https://github.com/rust-lang/libc/pull/3937>
- VxWorks: add riscv64 support <https://github.com/rust-lang/libc/pull/3935>
- VxWorks: update constants related to the scheduler  <https://github.com/rust-lang/libc/pull/3963>

### Changed

- Redox: change `ino_t` to be `c_ulonglong` <https://github.com/rust-lang/libc/pull/3919>

### Fixed

- ESP-IDF: fix mismatched constants and structs <https://github.com/rust-lang/libc/pull/3920>
- FreeBSD: fix `struct stat` on FreeBSD 12+ <https://github.com/rust-lang/libc/pull/3946>

### Other

- CI: Fix CI for FreeBSD 15 <https://github.com/rust-lang/libc/pull/3950>
- Docs: link to `windows-sys` <https://github.com/rust-lang/libc/pull/3915>

## [0.2.159](https://github.com/rust-lang/libc/compare/0.2.158...0.2.159) - 2024-09-24

### Added

- Android: add more `AT_*` constants in <https://github.com/rust-lang/libc/pull/3779>
- Apple: add missing `NOTE_*` constants in <https://github.com/rust-lang/libc/pull/3883>
- Hermit: add missing error numbers in <https://github.com/rust-lang/libc/pull/3858>
- Hurd: add `__timeval` for 64-bit support in <https://github.com/rust-lang/libc/pull/3786>
- Linux: add `epoll_pwait2` in <https://github.com/rust-lang/libc/pull/3868>
- Linux: add `mq_notify` in <https://github.com/rust-lang/libc/pull/3849>
- Linux: add missing `NFT_CT_*` constants in <https://github.com/rust-lang/libc/pull/3844>
- Linux: add the `fchmodat2` syscall in <https://github.com/rust-lang/libc/pull/3588>
- Linux: add the `mseal` syscall in <https://github.com/rust-lang/libc/pull/3798>
- OpenBSD: add `sendmmsg` and `recvmmsg` in <https://github.com/rust-lang/libc/pull/3831>
- Unix: add `IN6ADDR_ANY_INIT` and `IN6ADDR_LOOPBACK_INIT` in <https://github.com/rust-lang/libc/pull/3693>
- VxWorks: add `S_ISVTX` in <https://github.com/rust-lang/libc/pull/3768>
- VxWorks: add `vxCpuLib` and `taskLib` functions <https://github.com/rust-lang/libc/pull/3861>
- WASIp2: add definitions for `std::net` support in <https://github.com/rust-lang/libc/pull/3892>

### Fixed

- Correctly handle version checks when `clippy-driver` is used <https://github.com/rust-lang/libc/pull/3893>

### Changed

- EspIdf: change signal constants to c_int in <https://github.com/rust-lang/libc/pull/3895>
- HorizonOS: update network definitions in <https://github.com/rust-lang/libc/pull/3863>
- Linux: combine `ioctl` APIs in <https://github.com/rust-lang/libc/pull/3722>
- WASI: enable CI testing in <https://github.com/rust-lang/libc/pull/3869>
- WASIp2: enable CI testing in <https://github.com/rust-lang/libc/pull/3870>

## [0.2.158](https://github.com/rust-lang/libc/compare/0.2.157...0.2.158) - 2024-08-19

### Other
- WASI: fix missing `Iterator` with `rustc-dep-of-std` in <https://github.com/rust-lang/libc/pull/3856#event-13924913068>

## [0.2.157](https://github.com/rust-lang/libc/compare/0.2.156...0.2.157) - 2024-08-17

### Added

- Apple: add `_NSGetArgv`, `_NSGetArgc` and `_NSGetProgname` in <https://github.com/rust-lang/libc/pull/3702>
- Build: add `RUSTC_WRAPPER` support in <https://github.com/rust-lang/libc/pull/3845>
- FreeBSD: add `execvpe` support from 14.1 release in <https://github.com/rust-lang/libc/pull/3745>
- Fuchsia: add `SO_BINDTOIFINDEX`
- Linux: add `klogctl` in <https://github.com/rust-lang/libc/pull/3777>
- MacOS: add `fcntl` OFD commands in <https://github.com/rust-lang/libc/pull/3563>
- NetBSD: add `_lwp_park` in <https://github.com/rust-lang/libc/pull/3721>
- Solaris: add missing networking support in <https://github.com/rust-lang/libc/pull/3717>
- Unix: add `pthread_equal` in <https://github.com/rust-lang/libc/pull/3773>
- WASI: add `select`, `FD_SET`, `FD_ZERO`, `FD_ISSET ` in <https://github.com/rust-lang/libc/pull/3681>

### Fixed
- TEEOS: fix octal notation for `O_*` constants in <https://github.com/rust-lang/libc/pull/3841>

### Changed
- FreeBSD: always use freebsd12 when `rustc_dep_of_std` is set in <https://github.com/rust-lang/libc/pull/3723>

## [0.2.156](https://github.com/rust-lang/libc/compare/v0.2.155...v0.2.156) - 2024-08-15

### Added
- Apple: add `F_ALLOCATEPERSIST` in <https://github.com/rust-lang/libc/pull/3712>
- Apple: add `os_sync_wait_on_address` and related definitions in <https://github.com/rust-lang/libc/pull/3769>
- BSD: generalise `IPV6_DONTFRAG` to all BSD targets in <https://github.com/rust-lang/libc/pull/3716>
- FreeBSD/DragonFly: add `IP_RECVTTL`/`IPV6_RECVHOPLIMIT` in <https://github.com/rust-lang/libc/pull/3751>
- Hurd: add `XATTR_CREATE`, `XATTR_REPLACE` in <https://github.com/rust-lang/libc/pull/3739>
- Linux GNU: `confstr` API and `_CS_*` in <https://github.com/rust-lang/libc/pull/3771>
- Linux musl: add `preadv2` and `pwritev2` (1.2.5 min.) in <https://github.com/rust-lang/libc/pull/3762>
- VxWorks: add the constant `SOMAXCONN` in <https://github.com/rust-lang/libc/pull/3761>
- VxWorks: add a few errnoLib related constants in <https://github.com/rust-lang/libc/pull/3780>

### Fixed
- Solaris/illumos: Change `ifa_flags` type to u64 in <https://github.com/rust-lang/libc/pull/3729>
- QNX 7.0: Disable `libregex` in <https://github.com/rust-lang/libc/pull/3775>

### Changed
- QNX NTO: update platform support in <https://github.com/rust-lang/libc/pull/3815>
- `addr_of!(EXTERN_STATIC)` is now considered safe in <https://github.com/rust-lang/libc/pull/3776>

### Removed
- Apple: remove `rmx_state` in <https://github.com/rust-lang/libc/pull/3776>

### Other
- Update or remove CI tests that have been failing
