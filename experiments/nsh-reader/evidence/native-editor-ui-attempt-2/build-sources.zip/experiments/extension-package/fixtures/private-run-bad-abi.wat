(module
  (import "qusor" "call" (func $call (param i32 i32 i32 i32) (result i32)))
  (memory (export "memory") 2 2)
  (func (export "alloc") (param i32) (result i32) i32.const 1024)
  (func (export "run") (result i32 i32) i32.const 0 i32.const 0)
  (func (export "qusor_abi_version") (result i32) i32.const 99)
  (func (export "qusor_state_check") (param i32 i32 i32) (result i32)
    (local.get 0) (i32.const 1) (i32.ne) (if (then i32.const 1 return))
    i32.const 0))
