/** UI-only identity/delivery state. It grants no Host authority and never parses
 * paragraphs, constructs document text, or rebases a row to a new revision. */
export type RowIdentity={binding:string;frame:string;query:string;revision:number;handle:string;ordinal:number};
export type InputInstance={identity:Readonly<RowIdentity>;token:object};
export type RowDelivery={identity:Readonly<RowIdentity>;sequence:number;text:string};
/** Tombstone for the old row identity after its delivery committed. The identity
 * itself is intentionally left untouched: this metadata only proves that any
 * further local text must be recovered through the new committed row, never
 * sent as another command carrying this old base/revision/ordinal. */
export type PostCommitTombstone={revision:number;submitted:string};
export type ParagraphInput={identity:Readonly<RowIdentity>;local:string;baseline:string;composing:boolean;next:number;
 inflight?:RowDelivery;unknown:boolean;conflict?:{committedRevision:number;submitted:string;retained:string};rejected?:string;
 postCommit?:Readonly<PostCommitTombstone>};
export function sameRow(a:RowIdentity,b:RowIdentity):boolean {
 return a.binding===b.binding&&a.frame===b.frame&&a.query===b.query&&a.revision===b.revision&&a.handle===b.handle&&a.ordinal===b.ordinal;
}
export function rowInput(identity:RowIdentity,text:string):ParagraphInput {
 return {identity:Object.freeze({...identity}),local:text,baseline:text,composing:false,next:1,unknown:false};
}
/** Parent owns this registry. A delayed ref/change from an old frame cannot
 * reactivate it. Callbacks carry the exact object, never only a row index/key. */
export class ParagraphInputs {
 private visible=false;
 private current=new Map<string,InputInstance>();
 private attached=new Set<object>();
 private binding="";
 private frame="";
 show(binding:string,frame:string,instances:InputInstance[]):void {
  this.binding=binding;this.frame=frame;this.visible=true;
  this.current=new Map(instances.map(i=>[i.identity.handle,i]));
  const live=new Set(instances.map(i=>i.token));
  this.attached=new Set([...this.attached].filter(t=>live.has(t)));
 }
 hide():void {this.visible=false;this.attached.clear();}
 attach(instance:InputInstance,node:unknown):boolean {
  if(!this.owned(instance))return false;
  if(node)this.attached.add(instance.token);else this.attached.delete(instance.token);
  return this.active(instance);
 }
 private owned(instance:InputInstance):boolean {
  return this.current.get(instance.identity.handle)===instance&&instance.identity.binding===this.binding&&instance.identity.frame===this.frame;
 }
 currentInstance(instance:InputInstance):boolean {return this.visible&&this.owned(instance);}
 active(instance:InputInstance):boolean {return this.currentInstance(instance)&&this.attached.has(instance.token);}
 change(state:ParagraphInput,instance:InputInstance,text:string):ParagraphInput {
  if(!this.active(instance)||!sameRow(state.identity,instance.identity))return state;
  const next:ParagraphInput={...state,local:text,rejected:text===state.rejected?state.rejected:undefined};
  if(next.postCommit)next.conflict=text===next.postCommit.submitted?undefined:{
   committedRevision:next.postCommit.revision,submitted:next.postCommit.submitted,retained:text};
  return next;
 }
 composition(state:ParagraphInput,instance:InputInstance,composing:boolean):ParagraphInput {
  return this.active(instance)&&sameRow(state.identity,instance.identity)?{...state,composing}:state;
 }
}
export function rowDirty(s:ParagraphInput):boolean {return s.local!==s.baseline;}
export function mustKeepInput(s:ParagraphInput):boolean {return s.composing||rowDirty(s)||!!s.inflight||s.unknown||!!s.conflict;}
export function rowDelivery(s:ParagraphInput):{state:ParagraphInput;command:RowDelivery}|null {
 if(s.composing||s.postCommit||s.inflight||s.unknown||s.conflict||!rowDirty(s)||s.local===s.rejected||!Number.isSafeInteger(s.next+1))return null;
 const command={identity:s.identity,sequence:s.next,text:s.local};
 return {state:{...s,inflight:command,next:s.next+1},command};
}
function matches(s:ParagraphInput,c:RowDelivery):boolean {
 const i=s.inflight;return !!i&&i.sequence===c.sequence&&i.text===c.text&&sameRow(i.identity,c.identity)&&sameRow(s.identity,c.identity);
}
export function rowUnknown(s:ParagraphInput,c:RowDelivery):ParagraphInput {return matches(s,c)?{...s,unknown:true}:s;}
export function rowRejected(s:ParagraphInput,c:RowDelivery):ParagraphInput {
 return matches(s,c)?{...s,inflight:undefined,unknown:false,rejected:c.text}:s;
}
/** A successful commit always leaves a post-commit tombstone on the old row
 * identity. If all local text was submitted the state is clean and the window
 * may move; retained text (for example queued LF input) stays as an explicit
 * conflict and can never be delivered under the old base again. */
export function rowCommitted(s:ParagraphInput,c:RowDelivery,revision:number):ParagraphInput {
 if(!matches(s,c))return s;
 if(!Number.isSafeInteger(revision)||revision!==c.identity.revision+1)return rowUnknown(s,c);
 const retained=s.local;
 const next:ParagraphInput={...s,inflight:undefined,unknown:false,baseline:c.text,
  postCommit:{revision,submitted:c.text}};
 if(retained===c.text)delete next.conflict;
 else next.conflict={committedRevision:revision,submitted:c.text,retained};
 return next;
}
export function rowRetry(s:ParagraphInput):{state:ParagraphInput;command:RowDelivery}|null {
 if(s.postCommit||!s.unknown||!s.inflight||s.composing)return null;
 return {state:{...s,unknown:false},command:s.inflight};
}
/** A coordinator stores only latest viewport intent. While this returns false,
 * it must not call project, replace its row array, or unmount the active Input.
 * Commit still requires explicit resolution of retained post-submit input. */
export function canReplaceWindow(s:ParagraphInput|null):boolean {return !s||!mustKeepInput(s);}
