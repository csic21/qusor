import assert from "node:assert/strict";
import {ParagraphInputs,rowInput,rowDelivery,rowCommitted,rowRetry,rowUnknown,rowRejected,canReplaceWindow,type InputInstance} from "./paragraph-input-state.ts";
const identity={binding:"draft-a",frame:"frame-1",query:"query-1",revision:1,handle:"row-1",ordinal:0};
const old:InputInstance={identity,token:{}};
const registry=new ParagraphInputs();registry.show(identity.binding,identity.frame,[old]);
assert.equal(registry.attach(old,{}),true);
let s=rowInput(identity,"a");
s=registry.change(s,old,"x\ny");
assert.equal(canReplaceWindow(s),false);
const delivery=rowDelivery(s)!;s=delivery.state;
s=registry.change(s,old,"x\nyz");
const committed=rowCommitted(s,delivery.command,2);
assert.equal(committed.identity.revision,1); // never implicitly rebase row ordinal
assert.equal(committed.local,"x\nyz");assert.equal(committed.conflict?.submitted,"x\ny");
assert.equal(rowDelivery(committed),null);assert.equal(canReplaceWindow(committed),false);
// Same row string at a new frame is a different actual native instance.
const fresh:InputInstance={identity:{...identity,frame:"frame-2"},token:{}};
registry.show(identity.binding,"frame-2",[fresh]);registry.attach(fresh,{});
assert.equal(registry.attach(old,{}),false);
assert.equal(registry.change(committed,old,"late"),committed);
assert.equal(registry.composition(committed,old,true),committed);
registry.hide();assert.equal(registry.active(fresh),false);
assert.equal(registry.change(rowInput(fresh.identity,"kept"),fresh,"late").local,"kept");
// Unknown means replay exact same base/full payload, no opportunistic new event.
const uncertain=rowUnknown(delivery.state,delivery.command);
const retry=rowRetry(uncertain)!;assert.deepEqual(retry.command,delivery.command);
assert.equal(rowDelivery(uncertain),null);
const rejected=rowRejected(delivery.state,delivery.command);
assert.equal(rejected.local,"x\ny");assert.equal(rowDelivery(rejected),null);
// Old receipt cannot mutate another binding or sequence.
assert.deepEqual(rowCommitted({...delivery.state,identity:{...identity,binding:"other"}},delivery.command,2),{...delivery.state,identity:{...identity,binding:"other"}});
// Composition pins the actual native control even when the text is unchanged.
assert.equal(canReplaceWindow({...rowInput(identity,"a"),composing:true}),false);

// A normal commit with no retained text must close the old delivery state and
// allow the coordinator to move to the newly committed row.
const normalIdentity={...identity,handle:"row-normal",ordinal:1};
const normalInstance:InputInstance={identity:normalIdentity,token:{}};
const imeIdentity={...identity,handle:"row-ime",ordinal:2};
const imeInstance:InputInstance={identity:imeIdentity,token:{}};
registry.show(identity.binding,identity.frame,[normalInstance,imeInstance]);
assert.equal(registry.attach(normalInstance,{}),true);
assert.equal(registry.attach(imeInstance,{}),true);
let normal=registry.change(rowInput(normalIdentity,"base"),normalInstance,"sent");
const normalDelivery=rowDelivery(normal)!;normal=normalDelivery.state;
const normalCommitted=rowCommitted(normal,normalDelivery.command,normalIdentity.revision+1);
assert.equal(normalCommitted.identity.revision,normalIdentity.revision);
assert.equal(normalCommitted.local,"sent");assert.equal(normalCommitted.baseline,"sent");
assert.equal(normalCommitted.inflight,undefined);assert.equal(normalCommitted.unknown,false);
assert.equal(normalCommitted.conflict,undefined);
assert.deepEqual(normalCommitted.postCommit,{revision:normalIdentity.revision+1,submitted:"sent"});
assert.equal(rowDelivery(normalCommitted),null);
assert.equal(canReplaceWindow(normalCommitted),true);
// A late callback still belongs to the old identity: retain its text for explicit
// recovery, but never send another command using the committed row base.
const late=registry.change(normalCommitted,normalInstance,"sent late");
assert.equal(late.local,"sent late");assert.equal(late.baseline,"sent");
assert.equal(late.inflight,undefined);assert.deepEqual(late.postCommit,normalCommitted.postCommit);
assert.equal(rowDelivery(late),null);assert.equal(rowRetry(late),null);
assert.equal(rowRetry({...normalCommitted,unknown:true,inflight:normalDelivery.command}),null);
assert.equal(canReplaceWindow(late),false);
// The same holds for IME text arriving after the receipt: keep it out of the
// old command stream and never bump the old identity or reuse its sequence.
const lateIme=registry.composition(late,normalInstance,true);
const lateImeChanged=registry.change(lateIme,normalInstance,"sent late ime");
assert.equal(lateImeChanged.local,"sent late ime");assert.equal(lateImeChanged.composing,true);
assert.equal(lateImeChanged.identity.revision,normalIdentity.revision);
assert.equal(lateImeChanged.next,normal.next);assert.notEqual(lateImeChanged.postCommit,undefined);
assert.equal(rowDelivery(lateImeChanged),null);assert.equal(canReplaceWindow(lateImeChanged),false);

// Queued LF input preserves submitted text, retained text, and the accepted base.
assert.equal(committed.baseline,"x\ny");
assert.deepEqual(committed.conflict,{committedRevision:2,submitted:"x\ny",retained:"x\nyz"});

// A commit receipt during composition keeps the actual Input mounted. Text that
// changes afterwards stays local-only, while an unchanged composition can finish
// and release the window.
let ime=registry.change(rowInput(imeIdentity,"start"),imeInstance,"sent");
const imeDelivery=rowDelivery(ime)!;ime=imeDelivery.state;
ime=registry.composition(ime,imeInstance,true);
const imeCommitted=rowCommitted(ime,imeDelivery.command,imeIdentity.revision+1);
assert.equal(imeCommitted.composing,true);assert.equal(imeCommitted.local,"sent");
assert.equal(imeCommitted.baseline,"sent");assert.equal(imeCommitted.conflict,undefined);
assert.notEqual(imeCommitted.postCommit,undefined);
assert.equal(rowDelivery(imeCommitted),null);assert.equal(canReplaceWindow(imeCommitted),false);
const imeChanged=registry.change(imeCommitted,imeInstance,"sent ime");
assert.equal(imeChanged.local,"sent ime");assert.equal(imeChanged.composing,true);
assert.equal(rowDelivery(imeChanged),null);
const imeCanceledChanged=registry.composition(imeChanged,imeInstance,false);
assert.equal(imeCanceledChanged.local,"sent ime");assert.equal(imeCanceledChanged.composing,false);
assert.equal(rowDelivery(imeCanceledChanged),null);assert.equal(canReplaceWindow(imeCanceledChanged),false);
const imeCanceledUnchanged=registry.composition(imeCommitted,imeInstance,false);
assert.equal(imeCanceledUnchanged.composing,false);
assert.equal(rowDelivery(imeCanceledUnchanged),null);
assert.equal(canReplaceWindow(imeCanceledUnchanged),true);

// Unknown delivery still retries the original base command byte-for-byte.
assert.equal(retry.state.unknown,false);assert.equal(retry.state.inflight?.sequence,delivery.command.sequence);
assert.equal(retry.command.identity.revision,identity.revision);

