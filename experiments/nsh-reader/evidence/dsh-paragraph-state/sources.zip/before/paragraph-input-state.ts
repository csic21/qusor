/** UI-only identity/delivery state. It grants no Host authority and never parses
 * paragraphs, constructs document text, or rebases a row to a new revision. */
export type RowIdentity={binding:string;frame:string;query:string;revision:number;handle:string;ordinal:number};
export type InputInstance={identity:Readonly<RowIdentity>;token:object};
export type RowDelivery={identity:Readonly<RowIdentity>;sequence:number;text:string};
export type ParagraphInput={identity:Readonly<RowIdentity>;local:string;baseline:string;composing:boolean;next:number;
 inflight?:RowDelivery;unknown:boolean;conflict?:{committedRevision:number;submitted:string;retained:string};rejected?:string};
export function sameRow(a:RowIdentity,b:RowIdentity):boolean {
 return a.binding===b.binding&&a.frame===b.frame&&a.query===b.query&&a.revision===b.revision&&a.handle===b.handle&&a.ordinal===b.ordinal;
}
export function rowInput(identity:RowIdentity,text:string):ParagraphInput {
 return {identity:Object.freeze({...identity}),local:text,baseline:text,composing:false,next:1,unknown:false};
}
/** Parent owns this registry. A delayed ref/change from an old frame cannot
 * reactivate it. Callbacks carry the exact object, never only a row index/key. */
export class ParagraphInputs {
 private visible=false;
 private current=new Map<string,InputInstance>();
 private attached=new Set<object>();
 private binding="";
 private frame="";
 show(binding:string,frame:string,instances:InputInstance[]):void {
  this.binding=binding;this.frame=frame;this.visible=true;
  this.current=new Map(instances.map(i=>[i.identity.handle,i]));
  const live=new Set(instances.map(i=>i.token));
  this.attached=new Set([...this.attached].filter(t=>live.has(t)));
 }
 hide():void {this.visible=false;this.attached.clear();}
 attach(instance:InputInstance,node:unknown):boolean {
  if(!this.owned(instance))return false;
  if(node)this.attached.add(instance.token);else this.attached.delete(instance.token);
  return this.active(instance);
 }
 private owned(instance:InputInstance):boolean {
  return this.current.get(instance.identity.handle)===instance&&instance.identity.binding===this.binding&&instance.identity.frame===this.frame;
 }
 currentInstance(instance:InputInstance):boolean {return this.visible&&this.owned(instance);}
 active(instance:InputInstance):boolean {return this.currentInstance(instance)&&this.attached.has(instance.token);}
 change(state:ParagraphInput,instance:InputInstance,text:string):ParagraphInput {
  if(!this.active(instance)||!sameRow(state.identity,instance.identity))return state;
  return {...state,local:text,rejected:text===state.rejected?state.rejected:undefined};
 }
 composition(state:ParagraphInput,instance:InputInstance,composing:boolean):ParagraphInput {
  return this.active(instance)&&sameRow(state.identity,instance.identity)?{...state,composing}:state;
 }
}
export function rowDirty(s:ParagraphInput):boolean {return s.local!==s.baseline;}
export function mustKeepInput(s:ParagraphInput):boolean {return s.composing||rowDirty(s)||!!s.inflight||s.unknown||!!s.conflict;}
export function rowDelivery(s:ParagraphInput):{state:ParagraphInput;command:RowDelivery}|null {
 if(s.composing||s.inflight||s.unknown||s.conflict||!rowDirty(s)||s.local===s.rejected||!Number.isSafeInteger(s.next+1))return null;
 const command={identity:s.identity,sequence:s.next,text:s.local};
 return {state:{...s,inflight:command,next:s.next+1},command};
}
function matches(s:ParagraphInput,c:RowDelivery):boolean {
 const i=s.inflight;return !!i&&i.sequence===c.sequence&&i.text===c.text&&sameRow(i.identity,c.identity)&&sameRow(s.identity,c.identity);
}
export function rowUnknown(s:ParagraphInput,c:RowDelivery):ParagraphInput {return matches(s,c)?{...s,unknown:true}:s;}
export function rowRejected(s:ParagraphInput,c:RowDelivery):ParagraphInput {
 return matches(s,c)?{...s,inflight:undefined,unknown:false,rejected:c.text}:s;
}
/** Never carry queued whole old-row input to new revision/index, even if no LF
 * was typed: the public contract supplies no range continuity proof. */
export function rowCommitted(s:ParagraphInput,c:RowDelivery,revision:number):ParagraphInput {
 if(!matches(s,c))return s;
 if(!Number.isSafeInteger(revision)||revision!==c.identity.revision+1)return rowUnknown(s,c);
 return {...s,inflight:undefined,unknown:false,baseline:c.text,
  conflict:{committedRevision:revision,submitted:c.text,retained:s.local}};
}
export function rowRetry(s:ParagraphInput):{state:ParagraphInput;command:RowDelivery}|null {
 if(!s.unknown||!s.inflight||s.composing)return null;
 return {state:{...s,unknown:false},command:s.inflight};
}
/** A coordinator stores only latest viewport intent. While this returns false,
 * it must not call project, replace its row array, or unmount the active Input.
 * Commit still requires explicit resolution of retained post-submit input. */
export function canReplaceWindow(s:ParagraphInput|null):boolean {return !s||!mustKeepInput(s);}
