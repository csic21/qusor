import assert from "node:assert/strict";
import {ParagraphInputs,rowInput,rowDelivery,rowCommitted,rowRetry,rowUnknown,rowRejected,canReplaceWindow,type InputInstance} from "./paragraph-input-state.ts";
const identity={binding:"draft-a",frame:"frame-1",query:"query-1",revision:1,handle:"row-1",ordinal:0};
const old:InputInstance={identity,token:{}};
const registry=new ParagraphInputs();registry.show(identity.binding,identity.frame,[old]);
assert.equal(registry.attach(old,{}),true);
let s=rowInput(identity,"a");
s=registry.change(s,old,"x\ny");
assert.equal(canReplaceWindow(s),false);
const delivery=rowDelivery(s)!;s=delivery.state;
s=registry.change(s,old,"x\nyz");
const committed=rowCommitted(s,delivery.command,2);
assert.equal(committed.identity.revision,1); // never implicitly rebase row ordinal
assert.equal(committed.local,"x\nyz");assert.equal(committed.conflict?.submitted,"x\ny");
assert.equal(rowDelivery(committed),null);assert.equal(canReplaceWindow(committed),false);
// Same row string at a new frame is a different actual native instance.
const fresh:InputInstance={identity:{...identity,frame:"frame-2"},token:{}};
registry.show(identity.binding,"frame-2",[fresh]);registry.attach(fresh,{});
assert.equal(registry.attach(old,{}),false);
assert.equal(registry.change(committed,old,"late"),committed);
assert.equal(registry.composition(committed,old,true),committed);
registry.hide();assert.equal(registry.active(fresh),false);
assert.equal(registry.change(rowInput(fresh.identity,"kept"),fresh,"late").local,"kept");
// Unknown means replay exact same base/full payload, no opportunistic new event.
const uncertain=rowUnknown(delivery.state,delivery.command);
const retry=rowRetry(uncertain)!;assert.deepEqual(retry.command,delivery.command);
assert.equal(rowDelivery(uncertain),null);
const rejected=rowRejected(delivery.state,delivery.command);
assert.equal(rejected.local,"x\ny");assert.equal(rowDelivery(rejected),null);
// Old receipt cannot mutate another binding or sequence.
assert.deepEqual(rowCommitted({...delivery.state,identity:{...identity,binding:"other"}},delivery.command,2),{...delivery.state,identity:{...identity,binding:"other"}});
// Composition pins the actual native control even when the text is unchanged.
assert.equal(canReplaceWindow({...rowInput(identity,"a"),composing:true}),false);
