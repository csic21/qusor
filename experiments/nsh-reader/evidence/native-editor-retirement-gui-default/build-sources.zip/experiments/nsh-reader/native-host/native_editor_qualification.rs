//! Feature-only real OS retirement qualification. Not a guest/JS capability.
use super::*;
#[derive(Default)]
struct Plan {
    point: Option<&'static str>,
    short_wait: bool,
    injected: usize,
    reaps: Vec<String>,
}
static PLAN: Mutex<Plan> = Mutex::new(Plan {
    point: None,
    short_wait: false,
    injected: 0,
    reaps: Vec::new(),
});
pub(super) fn fault(point: &str) -> Result<()> {
    let mut p = PLAN.lock().unwrap();
    if p.point == Some(point) {
        p.point = None;
        p.injected += 1;
        return Err(format!("qualification injected {point}"));
    }
    Ok(())
}
pub(super) fn observed_reap(run: &str) {
    PLAN.lock().unwrap().reaps.push(run.into());
}
pub(super) fn wait_limit() -> Duration {
    let mut p = PLAN.lock().unwrap();
    if p.short_wait {
        p.short_wait = false;
        Duration::ZERO
    } else {
        Duration::from_secs(8)
    }
}
fn leases() -> Result<Vec<extension_store::WorkerLease>> {
    let s = service()?;
    let mut g = mutex(&s.gate)?;
    g.host
        .with_component_authority(|store, _| store.worker_leases().map_err(text))
}
fn report(label: &str) -> Result<()> {
    let p = PLAN.lock().unwrap();
    let rows = leases()?;
    println!(
        "NATIVE_RETIREMENT_CASE {}",
        json!({"case":label,"faults":p.injected,"actual_reaped":p.reaps,"leases":rows.len()})
    );
    Ok(())
}
fn input_revision() -> Result<u64> {
    let slot = mutex(&EDITOR)?;
    let e = slot.as_ref().ok_or("no editor")?;
    Ok(e.drafts
        .read_chunk(&e.draft, None, 0, 512)
        .map_err(text)?
        .revision)
}
fn fault_case(label: &str) -> Result<()> {
    let (_fixture, _, binding) = fixture::Fixture::new(label);
    *PLAN.lock().unwrap() = Plan {
        point: if label == "unknown_wait" {
            None
        } else {
            Some(match label {
                "invocation" => "invocation",
                "gate" => "gate",
                _ => "finish",
            })
        },
        short_wait: label == "unknown_wait",
        ..Plan::default()
    };
    let result = apply(
        binding.clone(),
        input_revision()?,
        "retirement fixture input".into(),
    );
    if result.is_ok() {
        return Err(format!("{label} did not fault"));
    }
    if label == "finish" || label == "unknown_wait" {
        {
            let slot = mutex(&EDITOR)?;
            let e = slot.as_ref().unwrap();
            let owner = e.pending_run.as_ref().ok_or("pending owner lost")?;
            let p = owner.lock().unwrap();
            if label == "finish" && (!p.reaped || p.lease_finished) {
                return Err("finish failure lost real reap/lease stage".into());
            }
            if label == "unknown_wait" && p.reaped {
                return Err("unknown wait unexpectedly already reaped".into());
            }
        }
        if leases()?.is_empty() {
            return Err("unresolved run lost SQL lease".into());
        }
        {
            let mut slot = mutex(&EDITOR)?;
            let e = slot.as_mut().unwrap();
            let _ = resume_run(e);
            if e.pending_run.is_some() {
                return Err("second drain did not retire".into());
            }
        }
    }
    {
        let slot = mutex(&EDITOR)?;
        if slot.as_ref().unwrap().pending_run.is_some() {
            return Err("retired run owner still pending".into());
        }
    }
    if PLAN.lock().unwrap().reaps.len() != 1 {
        return Err("expected one actual Controller Reaped".into());
    }
    if !leases()?.is_empty() {
        return Err("own lease not cleared after actual reap".into());
    }
    discard(binding)?;
    report(label)
}
// Keep a real Controller child at GuardReady while exercising unrelated discard.
fn guarded_lease(same_install: bool) -> Result<()> {
    let label = if same_install {
        "same_install"
    } else {
        "foreign_install"
    };
    let (_fixture, _, binding) = fixture::Fixture::new(label);
    *PLAN.lock().unwrap() = Plan::default();
    // First A completes authentic guest work and all of its actual reaps.
    apply(binding.clone(), input_revision()?, "A settled".into())?;
    let controller = Controller::new().map_err(text)?;
    let boot = if same_install {
        "abcdef0123456789abcdef0123456789"
    } else {
        "0123456789abcdef0123456789abcdef"
    };
    let run = format!("{boot}-1");
    {
        let s = service()?;
        let mut g = mutex(&s.gate)?;
        g.host.with_component_authority(|store, _| {
            let receipt = if same_install {
                let slot = mutex(&EDITOR)?;
                store
                    .current(&slot.as_ref().unwrap().package.manifest().package_id)
                    .map_err(text)?
            } else {
                let root = Path::new(env!("CARGO_MANIFEST_DIR"))
                    .join("../../capture-core/evidence/component-author-b-projection");
                let key =
                    std::fs::read_to_string(root.join("publisher-public-key.txt")).map_err(text)?;
                let package = extension_package::package::verify_for_host(
                    &std::fs::read(root.join("provider-b.qpk")).map_err(text)?,
                    key.trim(),
                    &SUPPORTED_HOST_APIS,
                )
                .map_err(text)?;
                store
                    .install("qualification-install-b", 0, &package)
                    .map_err(text)?
            };
            store
                .prepare_worker_lease(
                    &receipt,
                    boot,
                    &run,
                    &runtime_process::current().map_err(text)?,
                )
                .map_err(text)?;
            store.mark_worker_spawn_attempted(&run).map_err(text)
        })?;
    }
    let handle = controller
        .start(WorkerLaunch {
            run_id: run.clone(),
            startup_timeout: Duration::from_secs(2),
            execution_timeout: ExecutionLimits::default().deadline,
        })
        .map_err(text)?;
    let deadline = Instant::now() + Duration::from_secs(2);
    let mut guarded = false;
    while !guarded && Instant::now() < deadline {
        for event in controller.poll() {
            if let ProcessEvent::Guarded { identity, .. } = event {
                let s = service()?;
                let mut g = mutex(&s.gate)?;
                g.host.with_component_authority(|store, _| {
                    store.bind_worker_lease(&run, identity).map_err(text)
                })?;
                guarded = true;
            }
        }
        if !guarded {
            thread::sleep(Duration::from_millis(1));
        }
    }
    if !guarded {
        return Err("real GuardReady missing".into());
    }
    let before = serde_json::to_string(&leases()?).map_err(text)?;
    let outcome = discard(binding.clone());
    let after = serde_json::to_string(&leases()?).map_err(text)?;
    let checked = if before != after {
        Err("discard changed other/unknown worker lease".into())
    } else if same_install && outcome.is_ok() {
        Err("same-install live lease failed to block".into())
    } else if !same_install && outcome.is_err() {
        Err(format!(
            "foreign installation blocked A discard: {outcome:?}"
        ))
    } else {
        Ok(())
    };
    controller.terminate(&handle).map_err(text)?;
    let until = Instant::now() + Duration::from_secs(8);
    let mut reaped = false;
    while !reaped && Instant::now() < until {
        for event in controller.poll() {
            if let ProcessEvent::Reaped { handle: h, .. } = event
                && h.run_id() == run
            {
                reaped = true;
            }
        }
        if !reaped {
            thread::sleep(Duration::from_millis(1));
        }
    }
    if !reaped {
        return Err("guarded fixture cleanup unconfirmed; lease retained".into());
    }
    {
        let s = service()?;
        let mut g = mutex(&s.gate)?;
        g.host
            .with_component_authority(|store, _| store.finish_worker_lease(&run).map_err(text))?;
    }
    controller.forget(&handle).map_err(text)?;
    checked?;
    if same_install {
        discard(binding)?;
    }
    println!(
        "NATIVE_RETIREMENT_CASE {}",
        json!({"case":label,"guarded":true,"actual_reaped":true,"lease_record_unchanged":before==after,"remaining_leases":leases()?.len()})
    );
    Ok(())
}
pub fn run_cases() -> Result<()> {
    for label in ["invocation", "gate", "finish", "unknown_wait"] {
        fault_case(label)?;
    }
    guarded_lease(false)?;
    guarded_lease(true)?;
    println!(
        "NATIVE_RETIREMENT_PASSED cases=6 budgets=250ms/1000000fuel/8calls backpressure=unverified native_release_ack=unverified"
    );
    Ok(())
}
