import { Scroll, View } from "nsh";
import { ActionButton, Body, InlineStatus, NoteEditor, QuoteBlock } from "./ui";
import { editorRows, editorRowKey, type Draft } from "./reader-state";
export function CapturePanel(props:{draft:()=>Draft|null;close:()=>void;save:()=>void;discard:()=>void;copy:()=>void;copyStatus:string;leaveUncertain:()=>void;retryEnabled:boolean;editingEnabled:boolean; saveEnabled:boolean; deliveryStatus:string; canPause:boolean;canRetry:boolean;preparing:boolean;needsPreparation:boolean;retryInput:()=>void; pauseInput:()=>void; nativeBinding:string;composition:(id:string,binding:string,nativeBinding:string,token:object,composing:boolean)=>void;inputRef:(node:any,editable:boolean,token:object)=>void;change:(id:string,binding:string,nativeBinding:string,token:object,value:string)=>void}) {
 return <Scroll style={{flex:1}} contentStyle={{padding:24,gap:20}}>
  <View style={{flexDirection:"row",alignItems:"center",gap:8}}><View style={{flex:1}}><Body title>{props.draft()?.phase==="saved"?"已保存的摘录":"写想法"}</Body></View><ActionButton label="返回正文" onPress={props.close} compact/></View>
  <Each of={editorRows(props.draft(),props.nativeBinding,props.editingEnabled)} key={editorRowKey}>{(entry)=>{const current=()=>entry().draft;const row=entry();const inputToken={};const identity={id:row.draft.id,binding:row.draft.binding,nativeBinding:row.nativeBinding,editable:row.editable};return <View style={{gap:16}}>
   <Body muted>{`${current()!.title} · 第 ${current()!.page+1} 页`}</Body>
   <QuoteBlock text={current()!.quote}/>
   <NoteEditor value={current()!.note} readonly={!entry().editable} inputRef={(node)=>props.inputRef(node,identity.editable,inputToken)} onComposition={(value)=>props.composition(identity.id,identity.binding,identity.nativeBinding,inputToken,value)} onChange={(value)=>props.change(identity.id,identity.binding,identity.nativeBinding,inputToken,value)}/>
   <If when={current()!.phase==="editing"}><InlineStatus>未保存 · 仅保留在当前会话</InlineStatus><View style={{flexDirection:"row",flexWrap:"wrap",gap:8}}><ActionButton label="保存想法" primary disabled={!props.saveEnabled} onPress={props.save}/><ActionButton label="放弃草稿…" disabled={!props.editingEnabled} onPress={props.discard}/></View><Body muted>保存或放弃后可重新选文、换页和缩放。阅读区仍可滚动。</Body></If>
   <If when={!!props.deliveryStatus}><InlineStatus>{props.deliveryStatus}</InlineStatus><View style={{flexDirection:"row",gap:8}}><If when={props.canPause}><ActionButton label="暂停处理" onPress={props.pauseInput}/></If><If when={props.needsPreparation}><ActionButton label="重试准备" disabled={props.preparing} onPress={props.retryInput}/></If><If when={!props.needsPreparation&&props.canRetry}><ActionButton label="原样重试输入" onPress={props.retryInput}/></If><ActionButton label="复制内容" onPress={props.copy}/></View></If>
   <If when={current()!.phase==="saving"}><InlineStatus>正在保存，想法已保留…</InlineStatus></If>
   <If when={current()!.phase==="uncertain"}><InlineStatus danger>保存结果尚未确认。内容已锁定，可原样重试。</InlineStatus><If when={current()!.sourceUnavailable}><Body muted>{current()!.submission?.editor?"原页面已不可用，仍可原样重试确认这次保存。":"原页面已不可用，暂不能重试此保存。可复制内容后明确离开。"}</Body></If><ActionButton label="原样重试保存" primary disabled={!props.retryEnabled} onPress={props.save}/><ActionButton label="复制引文与想法" onPress={props.copy}/><ActionButton label="离开此草稿…" onPress={props.leaveUncertain}/></If>
   <If when={current()!.phase==="saved"}><InlineStatus success>已保存到本机</InlineStatus><ActionButton label="继续阅读" primary onPress={props.close}/><ActionButton label="复制引文与想法" onPress={props.copy}/><Body muted>当前组件可查看这次保存的内容；暂不支持修改已保存笔记。</Body></If>
   <If when={current()!.phase==="detached"}><InlineStatus danger>原想法仍保留在当前会话，原阅读来源已不可用。可选中复制内容。</InlineStatus><ActionButton label="复制引文与想法" onPress={props.copy}/><ActionButton label="放弃此草稿…" disabled={!props.editingEnabled} onPress={props.discard}/></If>
   <If when={!!props.copyStatus}><InlineStatus>{props.copyStatus}</InlineStatus></If>
  </View>;}}</Each>
 </Scroll>;
}
