//! Experimental Linux-only native ownership observations.
//!
//! This vertical slice never returns a release ACK: task/decode/cache and
//! native-child coverage are deliberately still missing. Object finalization
//! and snapshot participation are separate facts, not physical presentation.
use crate::{mount::Mounter, view::NshView};
#[cfg(test)]
use gtk4::glib;
use gtk4::prelude::*;
use nsh_core::{ImageData, MountBatch, MountItem, NodeId, ViewKind};
use std::{
    cell::RefCell,
    collections::{HashMap, HashSet},
    rc::Rc,
    sync::Arc,
};

const MAX_OWNERS: usize = 8;
const MAX_NODES: usize = 4096;

/// Trusted adapter-local identity. Deliberately nonserializable and !Send.
#[derive(Clone)]
pub struct NativeOwner(Rc<RefCell<Facts>>);
struct Facts {
    identity: Arc<()>,
    work: crate::retirement_work::WorkTracker,
    images: Option<crate::image::OwnerImages>,
    root: Option<NodeId>,
    closing: bool,
    failure: Option<&'static str>,
    live: HashSet<NodeId>,
    generations: HashMap<NodeId, u64>,
    next_generation: u64,
    total_deleted: u64,
    total_finalized: u64,
    total_retired: u64,
    deleted: HashSet<NodeId>,
    finalized: HashSet<NodeId>,
    next_stamp: u64,
    frame: Option<ExpectedFrame>,
    snapshot: Option<SnapshotEvidence>,
    snapshots: u64,
}
struct ExpectedFrame {
    stamp: FrameStamp,
    data: ImageData,
    pixels: (i32, i32),
}
/// Opaque, own-mount, strictly increasing frame identity.
#[derive(Clone, Debug)]
pub struct FrameStamp {
    identity: Arc<()>,
    ordinal: u64,
}
impl PartialEq for FrameStamp {
    fn eq(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.identity, &other.identity) && self.ordinal == other.ordinal
    }
}
impl Eq for FrameStamp {}
/// An actual image append in a GTK snapshot. This is not a display-present fence.
#[derive(Clone, Debug, PartialEq)]
pub struct SnapshotEvidence {
    /// Opaque trusted frame identity.
    pub stamp: FrameStamp,
    /// Native node observed at the append.
    pub node: NodeId,
    /// Actual appended texture pixel dimensions.
    pub pixels: (i32, i32),
    /// Image view logical width and height.
    pub bounds_dip: (f32, f32),
    /// Observed surface scale.
    pub scale: f32,
    /// Monotonic per-owner snapshot observation sequence.
    pub sequence: u64,
}
/// Partial evidence only. `Unprovable` must never be converted to a Host ACK.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PartialRetirement {
    /// Real boundary native node, once consumed.
    pub root: Option<NodeId>,
    /// New owned mutations and frame admission are closed.
    pub closing: bool,
    /// Nodes without a qdata finalization-stage notification yet.
    pub live_nodes: usize,
    /// Owned node Delete operations actually applied.
    pub delete_applied: u64,
    /// Qdata destroy notification reached; not a finalizer-return fence.
    pub finalization_reached_nodes: u64,
    /// Sticky bounded failure classification.
    pub failure: Option<&'static str>,
    /// Missing coverage; always prevents release acknowledgment.
    pub unprovable: &'static str,
}
/// Partial controlled PNG pipeline counts, never a release acknowledgment.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ImageCounts {
    /// Queued or running physical decode closures.
    pub decode: u64,
    /// Reserved or queued main-thread result deliveries.
    pub delivery: u64,
    /// Live owned decoded pixel containers.
    pub pixels: u64,
    /// Textures without their qdata finalization-stage notification.
    pub texture_finalization_pending: u64,
    /// Owner-private decoded cache entries.
    pub cache_entries: usize,
    /// Owner-private entries pinned by leases.
    pub cache_in_use: usize,
    /// Owner-private cache budget charge.
    pub cache_bytes: usize,
    /// Sticky work accounting/admission failure.
    pub failed: bool,
}
impl NativeOwner {
    /// Close new native/frame admission. Existing objects continue their real lifetime.
    pub fn begin_close(&self) {
        let (old, work) = {
            let mut f = self.0.borrow_mut();
            f.closing = true;
            (f.frame.take(), f.work.clone())
        };
        work.close();
        // Payloads may report lifecycle facts on Drop. Never run those
        // destructors while holding the owner's RefCell borrow.
        drop(old);
    }
    /// Actual owner image facts; zero values do not cover native children/outro.
    pub fn image_counts(&self) -> ImageCounts {
        let (work, images) = {
            let f = self.0.borrow();
            (f.work.clone(), f.images.clone())
        };
        let w = work.snapshot();
        let (entries, in_use, bytes) = images.map(|i| i.usage()).unwrap_or_default();
        ImageCounts {
            decode: w.decode,
            delivery: w.delivery,
            pixels: w.pixels,
            texture_finalization_pending: w.textures,
            cache_entries: entries,
            cache_in_use: in_use,
            cache_bytes: bytes,
            failed: w.failure,
        }
    }
    /// Clears only this owner cache after actual decode/delivery and leases end.
    /// Native pixel/GSK references may still remain and are reported separately.
    pub fn clear_image_cache(&self) -> Result<ImageCounts, &'static str> {
        let (closing, live, work, images) = {
            let f = self.0.borrow();
            (
                f.closing,
                !f.live.is_empty(),
                f.work.clone(),
                f.images.clone(),
            )
        };
        let w = work.snapshot();
        if !closing || live || w.failure || w.decode != 0 || w.delivery != 0 {
            return Err("owner image work not drained");
        }
        if let Some(images) = images {
            if images.usage().1 != 0 {
                return Err("owner image leases remain");
            }
            images.clear_unused();
        }
        let counts = self.image_counts();
        if counts.cache_entries != 0 || counts.cache_in_use != 0 || counts.cache_bytes != 0 {
            return Err("owner cache did not clear");
        }
        Ok(counts)
    }
    pub(crate) fn is_closing(&self) -> bool {
        let f = self.0.borrow();
        f.closing || f.failure.is_some()
    }
    pub(crate) fn work(&self) -> crate::retirement_work::WorkTracker {
        self.0.borrow().work.clone()
    }
    pub(crate) fn images(&self) -> Result<crate::image::OwnerImages, String> {
        if let Some(images) = self.0.borrow().images.clone() {
            return Ok(images);
        }
        let images = crate::image::OwnerImages::new(self.work())?;
        let old = { self.0.borrow_mut().images.replace(images.clone()) };
        drop(old);
        Ok(images)
    }
    /// Diagnostic evidence; node zero is insufficient to release a mount.
    pub fn status(&self) -> PartialRetirement {
        let f = self.0.borrow();
        PartialRetirement {
            root: f.root,
            closing: f.closing,
            live_nodes: f.live.len(),
            delete_applied: f.total_deleted,
            finalization_reached_nodes: f.total_finalized,
            failure: f.failure,
            unprovable: "native children, tasks, decode and cache not yet covered",
        }
    }
    /// Bind exact ImageData identity supplied by the trusted Rust renderer, not URI/text props.
    pub fn register_frame(
        &self,
        data: ImageData,
        pixels: (i32, i32),
    ) -> Result<FrameStamp, &'static str> {
        let (stamp, old) = {
            let mut f = self.0.borrow_mut();
            if f.closing || f.failure.is_some() || pixels.0 <= 0 || pixels.1 <= 0 || data.is_empty()
            {
                return Err("frame admission rejected");
            }
            f.next_stamp = f.next_stamp.checked_add(1).ok_or("frame stamp exhausted")?;
            let stamp = FrameStamp {
                identity: f.identity.clone(),
                ordinal: f.next_stamp,
            };
            let old = f.frame.replace(ExpectedFrame {
                stamp: stamp.clone(),
                data,
                pixels,
            });
            f.snapshot = None;
            (stamp, old)
        };
        drop(old);
        Ok(stamp)
    }
    /// Last actual append observation, with bounded storage.
    pub fn snapshot(&self) -> Option<SnapshotEvidence> {
        self.0.borrow().snapshot.clone()
    }
    pub(crate) fn snapshotted(
        &self,
        node: NodeId,
        data: Option<&ImageData>,
        pixels: (i32, i32),
        bounds: (f32, f32),
        scale: f32,
    ) {
        let mut f = self.0.borrow_mut();
        if f.closing
            || f.failure.is_some()
            || !f.live.contains(&node)
            || !bounds.0.is_finite()
            || !bounds.1.is_finite()
            || bounds.0 <= 0.0
            || bounds.1 <= 0.0
            || !scale.is_finite()
            || scale <= 0.0
        {
            return;
        }
        let Some(frame) = &f.frame else { return };
        if data != Some(&frame.data) || pixels != frame.pixels {
            return;
        }
        let stamp = frame.stamp.clone();
        let Some(sequence) = f.snapshots.checked_add(1) else {
            f.failure = Some("snapshot sequence exhausted");
            return;
        };
        f.snapshots = sequence;
        f.snapshot = Some(SnapshotEvidence {
            stamp,
            node,
            pixels,
            bounds_dip: bounds,
            scale,
            sequence,
        });
    }
    pub(crate) fn mark_unprovable(&self, reason: &'static str) {
        self.fail(reason);
    }
    fn fail(&self, reason: &'static str) {
        self.0.borrow_mut().failure.get_or_insert(reason);
    }
}

/// This guard is owned by GObject qdata, not by a Rust wrapper or weak-ref.
/// A private key is installed once and never explicitly cleared/replaced.
/// GTK object destruction stays on its main thread. Observation is polled
/// separately on the GTK thread; this notification only proves the qdata
/// finalization stage was reached, not that the complete native finalizer
/// returned. No reentrant Host callback occurs here.
struct Finalization {
    owner: NativeOwner,
    node: NodeId,
    generation: u64,
}
impl Drop for Finalization {
    fn drop(&mut self) {
        let mut f = self.owner.0.borrow_mut();
        if f.generations.get(&self.node) != Some(&self.generation) {
            return;
        }
        f.live.remove(&self.node);
        if f.finalized.insert(self.node) {
            match f.total_finalized.checked_add(1) {
                Some(n) => f.total_finalized = n,
                None => f.failure = Some("finalization counter exhausted"),
            }
        }
    }
}
#[derive(Default)]
pub(crate) struct Registry {
    registrations: HashMap<String, NativeOwner>,
    spent: HashSet<String>,
    owners: Vec<NativeOwner>,
    nodes: HashMap<NodeId, NativeOwner>,
    installed: HashSet<NodeId>,
}
impl Registry {
    pub(crate) fn register(&mut self, factory: &str) -> Result<NativeOwner, &'static str> {
        if factory.is_empty()
            || factory.len() > 128
            || self.owners.len() >= MAX_OWNERS
            || (self.registrations.contains_key(factory) || self.spent.contains(factory))
        {
            return Err("boundary registration rejected");
        }
        let owner = NativeOwner(Rc::new(RefCell::new(Facts {
            identity: Arc::new(()),
            work: Default::default(),
            images: None,
            root: None,
            closing: false,
            failure: None,
            live: HashSet::new(),
            generations: HashMap::new(),
            next_generation: 0,
            total_deleted: 0,
            total_finalized: 0,
            total_retired: 0,
            deleted: HashSet::new(),
            finalized: HashSet::new(),
            next_stamp: 0,
            frame: None,
            snapshot: None,
            snapshots: 0,
        })));
        self.registrations.insert(factory.into(), owner.clone());
        self.owners.push(owner.clone());
        Ok(owner)
    }
    /// Resolve the complete batch before any Create/source property can start work.
    pub(crate) fn prepare(
        &mut self,
        batch: &MountBatch,
        mounter: &Mounter,
    ) -> Result<(), &'static str> {
        self.collect_retired();
        match self.plan(batch, mounter) {
            Ok((planned, roots)) => {
                for (name, node, owner) in roots {
                    owner.0.borrow_mut().root = Some(node);
                    self.registrations.remove(&name);
                    self.spent.insert(name);
                }
                self.nodes = planned;
                Ok(())
            }
            Err(e) => {
                for owner in &self.owners {
                    owner.fail(e);
                }
                Err(e)
            }
        }
    }
    fn plan(
        &self,
        batch: &MountBatch,
        mounter: &Mounter,
    ) -> Result<
        (
            HashMap<NodeId, NativeOwner>,
            Vec<(String, NodeId, NativeOwner)>,
        ),
        &'static str,
    > {
        let mut nodes = self.nodes.clone();
        let mut roots = Vec::new();
        let mut used = HashSet::new();
        let mut created = HashMap::new();
        let mut parents = HashMap::new();
        for item in &batch.items {
            match item {
                MountItem::Create { id, kind } => {
                    if created.insert(*id, *kind).is_some() || nodes.contains_key(id) {
                        return Err("node identity reused");
                    }
                }
                MountItem::Insert { parent, child, .. } => {
                    parents.insert(*child, *parent);
                }
                MountItem::Component { id, name } => {
                    if let Some(owner) = self.registrations.get(name.as_ref()) {
                        if !used.insert(name.to_string()) || owner.0.borrow().closing {
                            return Err("one-shot boundary reused or closed");
                        }
                        if nodes.insert(*id, owner.clone()).is_some() {
                            return Err("boundary identity reused");
                        }
                        roots.push((name.to_string(), *id, owner.clone()));
                    } else if self.spent.contains(name.as_ref())
                        || self.owners.iter().any(|o| o.0.borrow().root == Some(*id))
                    {
                        return Err("boundary component replaced");
                    }
                }
                _ => {}
            }
        }
        for (_, node, _) in &roots {
            if created.get(node) != Some(&ViewKind::Native) {
                return Err("boundary must be a newly created native node");
            }
        }
        for child in parents.keys() {
            let mut cursor = *child;
            let mut seen = HashSet::new();
            while let Some(parent) = parents.get(&cursor) {
                if !seen.insert(cursor) {
                    return Err("native parent cycle");
                }
                cursor = *parent;
            }
        }
        for _ in 0..=parents.len() {
            let mut changed = false;
            for (child, parent) in &parents {
                if let Some(owner) = nodes.get(parent).cloned() {
                    if let Some(old) = nodes.get(child) {
                        if !Rc::ptr_eq(&old.0, &owner.0) {
                            return Err("cross-owner reparent");
                        }
                    } else {
                        if !created.contains_key(child) || mounter.views.contains_key(child) {
                            return Err("retroactive owner binding");
                        }
                        if owner.0.borrow().closing {
                            return Err("closed owner admission");
                        }
                        nodes.insert(*child, owner);
                        changed = true;
                    }
                }
            }
            if !changed {
                break;
            }
        }
        for (child, parent) in &parents {
            if nodes.contains_key(child)
                && !nodes.contains_key(parent)
                && !roots.iter().any(|(_, root, _)| root == child)
                && !self
                    .owners
                    .iter()
                    .any(|o| o.0.borrow().root == Some(*child))
            {
                return Err("owned node moved outside boundary");
            }
        }
        if nodes.len() > MAX_NODES {
            return Err("native node observation limit");
        }
        for (id, owner) in &nodes {
            if !self.nodes.contains_key(id) {
                if owner.0.borrow().closing
                    || !created.contains_key(id)
                    || mounter.views.contains_key(id)
                {
                    return Err("late boundary admission");
                }
                match created[id] {
                    ViewKind::View
                    | ViewKind::Text
                    | ViewKind::Input
                    | ViewKind::Image
                    | ViewKind::Scroll
                    | ViewKind::Native => {}
                    _ => owner.fail("unsupported native resource kind"),
                }
            }
        }
        // Once closed, retain old resources only; reject state-changing operations
        // instead of executing a late Image/source/command on an old owner.
        for item in &batch.items {
            match item {
                MountItem::Delete { .. } | MountItem::Remove { .. } => {}
                _ if mutation_node(item)
                    .and_then(|id| nodes.get(&id))
                    .is_some_and(|o| o.0.borrow().closing) =>
                {
                    return Err("closed owner mutation rejected");
                }
                MountItem::Animation(_) if self.owners.iter().any(|o| o.0.borrow().closing) => {
                    return Err("global animation mutation during close unproved");
                }
                _ => {}
            }
        }
        Ok((nodes, roots))
    }
    pub(crate) fn created(&mut self, view: &NshView) {
        let Some(owner) = self.nodes.get(&view.id()).cloned() else {
            return;
        };
        if !self.installed.insert(view.id()) {
            owner.fail("duplicate finalization registration");
            return;
        }
        let generation = {
            let mut f = owner.0.borrow_mut();
            let Some(generation) = f.next_generation.checked_add(1) else {
                f.failure = Some("native incarnation exhausted");
                return;
            };
            f.next_generation = generation;
            f.generations.insert(view.id(), generation);
            f.live.insert(view.id());
            generation
        };
        view.state_mut().retirement_owner = Some(owner.clone());
        // SAFETY: private key, installed once, never read/removed/replaced; the
        // value owns no GObject reference. GObject destroys it at finalization.
        unsafe {
            view.set_data(
                "qusor-retirement-finalization-913-v1",
                Finalization {
                    owner,
                    node: view.id(),
                    generation,
                },
            );
        }
    }
    // Only node-object records retire here. Physical work/pixel/cache owners
    // have separate records/counters and remain unprovable until they drain.
    fn collect_retired(&mut self) {
        let retired: Vec<_> = self
            .nodes
            .iter()
            .filter_map(|(id, o)| {
                let f = o.0.borrow();
                (f.deleted.contains(id) && f.finalized.contains(id) && !f.live.contains(id))
                    .then_some(*id)
            })
            .collect();
        for id in retired {
            let owner = self.nodes.remove(&id).expect("selected current node");
            self.installed.remove(&id);
            let mut f = owner.0.borrow_mut();
            f.deleted.remove(&id);
            f.finalized.remove(&id);
            f.generations.remove(&id);
            match f.total_retired.checked_add(1) {
                Some(n) => f.total_retired = n,
                None => f.failure = Some("retired counter exhausted"),
            }
        }
    }
    pub(crate) fn deleted(&mut self, node: NodeId) {
        if let Some(owner) = self.nodes.get(&node) {
            let mut f = owner.0.borrow_mut();
            if f.deleted.insert(node) {
                match f.total_deleted.checked_add(1) {
                    Some(n) => f.total_deleted = n,
                    None => f.failure = Some("delete counter exhausted"),
                }
            }
        }
    }
}

fn mutation_node(item: &MountItem) -> Option<NodeId> {
    match item {
        MountItem::Create { id, .. } => Some(*id),
        MountItem::TrackStates { id, .. } => Some(*id),
        MountItem::ProjectStates { id, .. } => Some(*id),
        MountItem::Remove { id, .. } => Some(*id),
        MountItem::Delete { id, .. } => Some(*id),
        MountItem::Frame { id, .. } => Some(*id),
        MountItem::Overflow { id, .. } => Some(*id),
        MountItem::ViewStyle { id, .. } => Some(*id),
        MountItem::Text { id, .. } => Some(*id),
        MountItem::Events { id, .. } => Some(*id),
        MountItem::Image { id, .. } => Some(*id),
        MountItem::ScrollConfig { id, .. } => Some(*id),
        MountItem::ScrollContent { id, .. } => Some(*id),
        MountItem::ScrollBy { id, .. } => Some(*id),
        MountItem::StickyCells { id, .. } => Some(*id),
        MountItem::ScrollBehavior { id, .. } => Some(*id),
        MountItem::Refreshing { id, .. } => Some(*id),
        MountItem::Canvas { id, .. } => Some(*id),
        MountItem::Shader { id, .. } => Some(*id),
        MountItem::ShaderTransition { id, .. } => Some(*id),
        MountItem::NavShader { id, .. } => Some(*id),
        MountItem::ShaderInput { id, .. } => Some(*id),
        MountItem::AnimationBindings { id, .. } => Some(*id),
        MountItem::Gestures { id, .. } => Some(*id),
        MountItem::ViewProps { id, .. } => Some(*id),
        MountItem::AccessibilityLabel { id, .. } => Some(*id),
        MountItem::Input { id, .. } => Some(*id),
        MountItem::InputValue { id, .. } => Some(*id),
        MountItem::InputContent { id, .. } => Some(*id),
        MountItem::ScreenConfig { id, .. } => Some(*id),
        MountItem::NativeProps { id, .. } => Some(*id),
        MountItem::ModalConfig { id, .. } => Some(*id),
        MountItem::Component { id, .. } => Some(*id),
        MountItem::ComponentPropSlots { id, .. } => Some(*id),
        MountItem::ComponentProps { id, .. } => Some(*id),
        MountItem::Command { id, .. } => Some(*id),
        MountItem::Insert { child, .. } => Some(*child),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gtk_test;
    fn create_boundary(surface: &Rc<crate::surface::Surface>, kind: ViewKind) -> NativeOwner {
        let owner = surface
            .retirement
            .borrow_mut()
            .register("fixture/one-shot")
            .unwrap();
        surface.apply(&MountBatch {
            items: vec![
                MountItem::Create {
                    id: 2,
                    kind: ViewKind::Native,
                },
                MountItem::Create { id: 3, kind },
                // Deliberately children before boundary and parent: ownership is
                // planned over the full batch, not assigned after Insert.
                MountItem::Insert {
                    parent: 2,
                    child: 3,
                    before: None,
                },
                MountItem::Component {
                    id: 2,
                    name: "fixture/one-shot".into(),
                },
                MountItem::Insert {
                    parent: nsh_core::ROOT_ID,
                    child: 2,
                    before: None,
                },
            ],
        });
        assert_eq!(owner.status().root, Some(2));
        assert_eq!(owner.status().live_nodes, 2);
        owner
    }
    #[test]
    fn retirement_frame_identity_and_payload_drop_are_owner_safe() {
        thread_local! { static REPORT_OWNER: RefCell<Option<NativeOwner>> = const { RefCell::new(None) }; }
        struct ReportingBytes(Vec<u8>);
        impl AsRef<[u8]> for ReportingBytes {
            fn as_ref(&self) -> &[u8] {
                &self.0
            }
        }
        impl Drop for ReportingBytes {
            fn drop(&mut self) {
                REPORT_OWNER.with_borrow(|owner| {
                    let _ = owner.as_ref().unwrap().status();
                });
            }
        }
        let mut registry = Registry::default();
        let a = registry.register("owner-a").unwrap();
        let b = registry.register("owner-b").unwrap();
        let bytes = ImageData::new(vec![1, 2, 3]);
        let first_a = a.register_frame(bytes.clone(), (1, 1)).unwrap();
        let first_b = b.register_frame(bytes, (1, 1)).unwrap();
        assert_eq!(first_a.ordinal, first_b.ordinal);
        assert_ne!(
            first_a, first_b,
            "same bytes/ordinal must not cross owner identity"
        );
        assert_eq!(first_a, first_a.clone());
        REPORT_OWNER.with_borrow_mut(|slot| *slot = Some(a.clone()));
        a.register_frame(ImageData::new(ReportingBytes(vec![4])), (1, 1))
            .unwrap();
        // Both replacement and closing run payload Drop after the owner borrow.
        a.register_frame(ImageData::new(ReportingBytes(vec![5])), (1, 1))
            .unwrap();
        a.begin_close();
        REPORT_OWNER.with_borrow_mut(|slot| *slot = None);
    }
    #[test]
    fn retirement_node_budget_counts_inflight_not_4353_historical_creates() {
        gtk_test::run(|| {
            let s=gtk_test::surface();let o=create_boundary(&s,ViewKind::View);
            let held=gtk_test::view(&s,3);let original_generation=o.0.borrow().generations[&3];
            s.apply(&MountBatch{items:vec![MountItem::Delete{id:3}]});
            let iterations=MAX_NODES+257;
            for id in 4..4+iterations as u32 {
                s.apply(&MountBatch{items:vec![MountItem::Create{id,kind:ViewKind::View},MountItem::Insert{parent:2,child:id,before:None}]});
                assert!(s.mounter.borrow().views.contains_key(&id));
                assert!(s.retirement.borrow().nodes.len()<=3);
                s.apply(&MountBatch{items:vec![MountItem::Delete{id}]});
            }
            assert_eq!(o.status().live_nodes,2,"original strong clone remains live");
            drop(held);s.apply(&MountBatch::default());assert_eq!(s.retirement.borrow().nodes.len(),1);
            s.apply(&MountBatch{items:vec![MountItem::Create{id:3,kind:ViewKind::View},MountItem::Insert{parent:2,child:3,before:None}]});
            let generation=o.0.borrow().generations[&3];assert_ne!(generation,original_generation);
            drop(Finalization{owner:o.clone(),node:3,generation:original_generation});
            assert!(o.0.borrow().live.contains(&3),"late wrong incarnation cannot retire new native object");
            let mut over=vec![];
            for id in 10000..10000+MAX_NODES as u32 {over.push(MountItem::Create{id,kind:ViewKind::View});over.push(MountItem::Insert{parent:2,child:id,before:None});}
            s.apply(&MountBatch{items:over});assert!(!s.mounter.borrow().views.contains_key(&10000));
            assert!(s.mounter.borrow().views.contains_key(&3));
            assert_eq!(o.status().failure,Some("native node observation limit"));
            eprintln!("OBSERVER_NODE_BUDGET historical_creates={} retained_clone=true peak_records=3 same_id_new_incarnation=true real_overlimit_rejected=true",iterations);
        }).expect("real GTK display required");
    }
    #[test]
    fn retirement_real_finalization_waits_for_clone_and_survives_dispose() {
        gtk_test::run(|| {
            let s=gtk_test::surface(); let o=create_boundary(&s,ViewKind::View);
            let held=gtk_test::view(&s,3); let clone=held.clone();
            o.begin_close();
            s.apply(&MountBatch{items:vec![MountItem::Delete{id:2},MountItem::Delete{id:3}]});
            assert_eq!(o.status().delete_applied,2);
            assert_eq!(o.status().live_nodes,1,"real GTK clone must hold native object");
            // SAFETY: dedicated detached fixture on GTK's main thread; we keep
            // strong refs intentionally to distinguish dispose from finalize.
            unsafe { held.run_dispose(); }
            assert_eq!(o.status().live_nodes,1,"run_dispose must not fake finalization");
            drop(held); assert_eq!(o.status().live_nodes,1);
            drop(clone); assert_eq!(o.status().live_nodes,0);
            assert_eq!(o.status().finalization_reached_nodes,2);
            assert!(!o.status().unprovable.is_empty(),"nodes alone never ACK");
            eprintln!("OBSERVER_REAL_FINALIZATION clones_blocked=true dispose_not_ack=true qdata_finalization_reached=2 finalizer_return_claimed=false unprovable=true");
        }).expect("real GTK display required for this qualification test");
    }
    #[test]
    fn retirement_one_shot_closed_admission_and_foreign_owner_fail_closed() {
        gtk_test::run(|| {
            let s = gtk_test::surface();
            let o = create_boundary(&s, ViewKind::View);
            assert!(
                s.retirement
                    .borrow_mut()
                    .register("fixture/one-shot")
                    .is_err()
            );
            o.begin_close();
            let late = MountBatch {
                items: vec![
                    MountItem::Create {
                        id: 4,
                        kind: ViewKind::View,
                    },
                    MountItem::Insert {
                        parent: 2,
                        child: 4,
                        before: None,
                    },
                ],
            };
            s.apply(&late);
            assert!(!s.mounter.borrow().views.contains_key(&4));
            assert!(o.register_frame(ImageData::new(vec![1]), (1, 1)).is_err());
            assert!(o.status().failure.is_some());
            let foreign = gtk_test::surface();
            let f = foreign
                .retirement
                .borrow_mut()
                .register("fixture/one-shot")
                .unwrap();
            assert!(f.status().root.is_none());
            assert_eq!(f.status().live_nodes, 0);
            eprintln!(
                "OBSERVER_ADMISSION one_shot=true late_create_rejected=true foreign_isolated=true"
            );
        })
        .expect("real GTK display required for this qualification test");
    }
    #[test]
    fn retirement_actual_image_snapshot_matches_exact_frame_identity() {
        gtk_test::run(|| {
            let s=gtk_test::surface();let o=create_boundary(&s,ViewKind::Image);
            let mut bytes=std::io::Cursor::new(Vec::new());
            image::RgbaImage::from_pixel(2,2,image::Rgba([60,90,120,255]))
                .write_to(&mut bytes,image::ImageFormat::Png).unwrap();
            let data=ImageData::new(bytes.into_inner());
            let stamp=o.register_frame(data.clone(),(2,2)).unwrap();
            assert!(o.snapshot().is_none(),"registration/load is not snapshot participation");
            s.apply(&MountBatch{items:vec![
                MountItem::Frame{id:2,frame:gtk_test::frame(0.,0.,100.,100.)},
                MountItem::Frame{id:3,frame:gtk_test::frame(0.,0.,100.,100.)},
                MountItem::Image{id:3,source:Some(nsh_core::ImageSource{uri:"blob:observer-fixture".into(),size:None,scales:nsh_core::ImageScales::NONE,data:Some(data)}),resize_mode:nsh_core::ResizeMode::Contain,options:Default::default()},
            ]});
            let window=gtk_test::show(&s);
            assert!(gtk_test::wait_until(|| o.snapshot().is_some()));
            let evidence=o.snapshot().unwrap();assert_eq!(evidence.stamp,stamp);assert_eq!(evidence.node,3);
            let different=ImageData::new(vec![9]);o.register_frame(different,(2,2)).unwrap();
            gtk_test::view(&s,3).queue_draw();
            while glib::MainContext::default().pending() { glib::MainContext::default().iteration(false); }
            assert!(o.snapshot().is_none(),"wrong ImageData must not certify old pixels");
            o.begin_close();assert!(!o.status().unprovable.is_empty());window.close();
            eprintln!("OBSERVER_SNAPSHOT actual_append=true exact_identity=true physical_present_claimed=false");
        }).expect("real GTK display required for this qualification test");
    }
}
