//! Physical background/queued-delivery accounting. No GTK or Host callbacks.
use std::sync::{Arc, Condvar, Mutex};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) struct WorkSnapshot {
    pub decode: u64,
    pub delivery: u64,
    pub pixels: u64,
    pub textures: u64,
    pub completed_decode: u64,
    pub completed_delivery: u64,
    pub closed: bool,
    pub failure: bool,
}
#[derive(Clone, Default)]
pub(crate) struct WorkTracker(Arc<(Mutex<WorkSnapshot>, Condvar)>);
#[derive(Clone, Copy)]
enum Kind {
    Decode,
    Delivery,
    Pixels,
    Texture,
}
struct Completion {
    tracker: WorkTracker,
    kind: Kind,
}
impl WorkTracker {
    pub(crate) fn snapshot(&self) -> WorkSnapshot {
        *self.0.0.lock().unwrap_or_else(|poison| {
            let mut state = poison.into_inner();
            state.failure = true;
            state
        })
    }
    pub(crate) fn close(&self) {
        self.0.0.lock().unwrap_or_else(|p| p.into_inner()).closed = true;
    }
    fn acquire(&self, kind: Kind) -> Result<Box<dyn Send + Sync>, String> {
        let mut state = self
            .0
            .0
            .lock()
            .map_err(|_| "observer work mutex poisoned")?;
        if (state.closed && matches!(kind, Kind::Decode | Kind::Delivery)) || state.failure {
            return Err("observer work admission closed".into());
        }
        let count = match kind {
            Kind::Decode => &mut state.decode,
            Kind::Delivery => &mut state.delivery,
            Kind::Pixels => &mut state.pixels,
            Kind::Texture => &mut state.textures,
        };
        if *count >= 64 {
            state.failure = true;
            return Err("observer in-flight work limit".into());
        }
        *count += 1;
        Ok(Box::new(Completion {
            tracker: self.clone(),
            kind,
        }))
    }
    pub(crate) fn decode(&self) -> Result<Box<dyn Send>, String> {
        self.acquire(Kind::Decode)
            .map(|guard| guard as Box<dyn Send>)
    }
    pub(crate) fn delivery(&self) -> Result<Box<dyn Send>, String> {
        self.acquire(Kind::Delivery)
            .map(|guard| guard as Box<dyn Send>)
    }
    pub(crate) fn pixels(&self) -> Result<Box<dyn Send + Sync>, String> {
        self.acquire(Kind::Pixels)
    }
    pub(crate) fn texture(&self) -> Result<Box<dyn Send + Sync>, String> {
        self.acquire(Kind::Texture)
    }
    #[cfg(test)]
    pub(crate) fn wait_idle(&self, timeout: std::time::Duration) -> bool {
        let state = self.0.0.lock().unwrap();
        let (state, _) = self
            .0
            .1
            .wait_timeout_while(state, timeout, |s| s.decode != 0 || s.delivery != 0)
            .unwrap();
        state.decode == 0 && state.delivery == 0 && !state.failure
    }
}
impl Drop for Completion {
    fn drop(&mut self) {
        let mut s = self.tracker.0.0.lock().unwrap_or_else(|p| p.into_inner());
        let (active, done) = match self.kind {
            Kind::Decode => (s.decode, s.completed_decode),
            Kind::Delivery => (s.delivery, s.completed_delivery),
            Kind::Pixels => (s.pixels, 0),
            Kind::Texture => (s.textures, 0),
        };
        let Some(active) = active.checked_sub(1) else {
            s.failure = true;
            return;
        };
        let Some(done) = done.checked_add(1) else {
            s.failure = true;
            return;
        };
        match self.kind {
            Kind::Decode => {
                s.decode = active;
                s.completed_decode = done
            }
            Kind::Delivery => {
                s.delivery = active;
                s.completed_delivery = done
            }
            Kind::Pixels => s.pixels = active,
            Kind::Texture => s.textures = active,
        }
        self.tracker.0.1.notify_all();
    }
}
