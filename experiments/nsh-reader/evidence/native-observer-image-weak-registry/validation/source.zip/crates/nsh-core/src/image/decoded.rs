//! Decoded images at display size (L4 of `docs/dev/image-loading-design.md`)
//! over the shared [`Loader`]: a backend gives [`Images`] its decoder (bytes
//! to its texture type at a size) and asks for images at the size a view
//! shows them.
//!
//! An image is decoded at the [`bucket`] covering what its view needs
//! ([`Want`]), never above its natural size (an SVG: within
//! [`crate::svg::MAX_SIDE`]), and kept by (source key, bucket, frames)
//! ([`Key`]): views of similar sizes share an entry, one that grows asks
//! for the next bucket. One decode per key runs at a time; the natural sizes
//! read from the bytes' headers are kept while a decoded entry remains, so
//! cached images are answered without reading anything. Evicting the last
//! entry of a source releases its natural-size metadata too.

use std::{
    collections::HashMap,
    sync::{
        Arc, Mutex, MutexGuard,
        atomic::{AtomicU64, Ordering},
    },
};

use super::{
    Budget, ImageData, Lease, MemoryCache,
    loader::{Context, Loader, Location, Priority, Progress, Ticket, loader},
    memory::{bucket, wanted},
};
use crate::{
    ResizeMode,
    geometry::{Points, Size, size},
};

/// The longest side an SVG is drawn at (`svg::MAX_SIDE`).
const VECTOR_SIDE: u32 = 8192;

/// An image's own size.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Natural {
    /// A bitmap's pixels.
    Pixels(u32, u32),
    /// An SVG's intrinsic size in points.
    Vector(Size<Points>),
}

impl Natural {
    /// Its size in points: a bitmap's pixels over its file name's
    /// `density`.
    pub fn points(self, density: f32) -> Size<Points> {
        match self {
            Natural::Pixels(w, h) => size(Points(w as f32 / density), Points(h as f32 / density)),
            Natural::Vector(points) => points,
        }
    }

    /// The natural size of the encoded `bytes`, from their header (an SVG:
    /// parsed), when it can be read without decoding them.
    pub fn of(bytes: &[u8]) -> Option<Natural> {
        #[cfg(feature = "svg")]
        if crate::svg::sniff(bytes) {
            return crate::svg::size(bytes).ok().map(Natural::Vector);
        }
        let size = imagesize::blob_size(bytes).ok()?;
        let side = |n: usize| u32::try_from(n).ok().filter(|n| *n > 0);
        Some(Natural::Pixels(side(size.width)?, side(size.height)?))
    }
}

/// Which frames of an animated image a decode keeps.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum Frames {
    /// Every frame (an image view plays it).
    #[default]
    All,
    /// The first (a canvas draws a bitmap).
    First,
}

/// The size a view shows an image at.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Want {
    /// The view's box; empty: the image's natural size.
    pub size: Size<Points>,
    /// Device pixels per point.
    pub scale: f32,
    /// How the box fits it.
    pub mode: ResizeMode,
}

impl Want {
    /// The natural size at `scale` device pixels per point.
    pub fn natural(scale: f32) -> Self {
        Want {
            size: Size::default(),
            scale,
            mode: ResizeMode::Center,
        }
    }

    /// The longest side, in pixels, to decode an image of `natural` size
    /// at (`declared`: the size its source gives, in points).
    pub fn longest(&self, natural: Natural, density: f32, declared: Option<Size<Points>>) -> u32 {
        let points = declared
            .filter(|s| s.width.0 > 0.0 && s.height.0 > 0.0)
            .unwrap_or_else(|| natural.points(density));
        let mut px = (wanted(points, self.size, self.mode) as f32 * self.scale).ceil() as u32;
        match natural {
            Natural::Pixels(w, h) => bucket(w.max(h), px),
            Natural::Vector(points) => {
                if px == 0 {
                    px = (points.width.0.max(points.height.0) * self.scale).ceil() as u32;
                }
                bucket(VECTOR_SIDE, px.max(1))
            }
        }
    }
}

/// What a decode makes: the image at a size.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Target {
    /// The image's own size (`None`: its header did not say; decode it at
    /// its natural size).
    pub natural: Option<Natural>,
    /// The longest side to decode at, in pixels (at most the natural one).
    pub longest: u32,
    /// The frames to keep.
    pub frames: Frames,
}

/// A decoded image's entry key.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Key {
    /// The source key ([`Location::key`]).
    pub source: String,
    /// Its bucket ([`Target::longest`]; 0: natural, its size unknown).
    pub longest: u32,
    /// The frames kept.
    pub frames: Frames,
}

/// A decoded image.
#[derive(Clone)]
pub struct Decoded<V> {
    /// The backend's picture of it.
    pub value: V,
    /// Its own size, whatever size it was decoded at.
    pub natural: Natural,
}

/// A request for an image.
#[derive(Clone)]
pub struct Request {
    /// Where its bytes are.
    pub location: Location,
    /// What the load goes through.
    pub context: Context,
    /// The size its source declares, in points (a bundled asset's).
    pub declared: Option<Size<Points>>,
    /// The size its view shows it at.
    pub want: Want,
    /// The frames its view needs.
    pub frames: Frames,
    /// Where it goes in the queues.
    pub priority: Priority,
    /// Hears the download's progress.
    pub progress: Option<Progress>,
}

/// Decodes `bytes` at `target` into a backend's picture, its natural size
/// and its cost in bytes (pixels, GPU copies).
pub type Decoder<V> =
    dyn Fn(&ImageData, &Target) -> Result<(V, Natural, usize), String> + Send + Sync;

/// Called with an image and the lease that keeps it, or why there is none.
pub type Done<V> = Box<dyn FnOnce(Result<(Decoded<V>, Lease), String>) + Send>;

/// A backend's decoded images: decodes by [`Key`], in one budget.
pub struct Images<V> {
    memory: MemoryCache<Key, Decoded<V>>,
    shared: Arc<Shared<V>>,
    loader: &'static Loader,
}

impl<V> Clone for Images<V> {
    fn clone(&self) -> Self {
        Images {
            memory: self.memory.clone(),
            shared: self.shared.clone(),
            loader: self.loader,
        }
    }
}

struct Shared<V> {
    decoder: Box<Decoder<V>>,
    job_observer: Option<Box<dyn Fn() -> Result<Box<dyn Send>, String> + Send + Sync>>,
    /// Decodes running, by key: who waits for them.
    pending: Mutex<HashMap<Key, Pending<V>>>,
    /// Natural sizes and the number of decoded entries that keep them.
    naturals: Arc<Mutex<HashMap<String, (Natural, usize)>>>,
    waiters: AtomicU64,
}

struct Pending<V> {
    waiters: Vec<(u64, Done<V>)>,
    ticket: Option<Ticket>,
}

fn lock<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

/// A request's stages: the read, then its place among a decode's waiters.
#[derive(Default)]
struct Stage {
    cancelled: bool,
    read: Option<Ticket>,
    decode: Option<Key>,
}

impl<V: Clone + Send + Sync + 'static> Images<V> {
    /// Images decoded by `decoder`, kept in `budget`.
    pub fn new(
        budget: &Arc<Budget>,
        decoder: impl Fn(&ImageData, &Target) -> Result<(V, Natural, usize), String>
        + Send
        + Sync
        + 'static,
    ) -> Self {
        Self::with_on_evict(budget, decoder, |_| {})
    }

    /// [`Images::new`], calling `on_evict` with each picture dropped (to
    /// release its GPU copy where it lives).
    pub fn with_on_evict(
        budget: &Arc<Budget>,
        decoder: impl Fn(&ImageData, &Target) -> Result<(V, Natural, usize), String>
        + Send
        + Sync
        + 'static,
        on_evict: impl Fn(&V) + Send + Sync + 'static,
    ) -> Self {
        let naturals = Arc::new(Mutex::new(HashMap::<String, (Natural, usize)>::new()));
        let retained = naturals.clone();
        let memory = MemoryCache::with_on_evict(budget, move |key: &Key, d: &Decoded<V>| {
            {
                let mut naturals = lock(&retained);
                if let Some((_, entries)) = naturals.get_mut(&key.source) {
                    *entries -= 1;
                    if *entries == 0 {
                        naturals.remove(&key.source);
                    }
                }
            }
            on_evict(&d.value);
        });
        Images {
            loader: loader(),
            memory,
            shared: Arc::new(Shared {
                decoder: Box::new(decoder),
                job_observer: None,
                pending: Mutex::default(),
                naturals,
                waiters: AtomicU64::new(0),
            }),
        }
    }

    /// Installs an optional physical-decode completion factory before this
    /// Images instance is shared. No policy/business types cross this hook.
    pub fn with_job_observer(
        mut self,
        observer: impl Fn() -> Result<Box<dyn Send>, String> + Send + Sync + 'static,
    ) -> Result<Self, &'static str> {
        let shared = Arc::get_mut(&mut self.shared).ok_or("images already shared")?;
        shared.job_observer = Some(Box::new(observer));
        Ok(self)
    }

    /// These images, loaded by `loader` (tests: a loader of their own).
    #[cfg(test)]
    pub(crate) fn on(mut self, loader: &'static Loader) -> Self {
        self.loader = loader;
        self
    }

    /// The decoded entries.
    pub fn memory(&self) -> &MemoryCache<Key, Decoded<V>> {
        &self.memory
    }

    /// The natural size of `source` (a source key), while a decoded entry remains.
    pub fn natural(&self, source: &str) -> Option<Natural> {
        lock(&self.shared.naturals)
            .get(source)
            .map(|(natural, _)| *natural)
    }

    /// The key `request` is decoded by, once its natural size is known.
    fn key(&self, request: &Request, source: &str, natural: Option<Natural>) -> (Key, Target) {
        let longest = natural.map_or(0, |n| {
            request
                .want
                .longest(n, request.location.density(), request.declared)
        });
        let target = Target {
            natural,
            longest,
            frames: request.frames,
        };
        let key = Key {
            source: source.to_owned(),
            longest,
            frames: request.frames,
        };
        (key, target)
    }

    /// The key `request`'s image, of natural size `natural`, is kept under
    /// (to count what it costs elsewhere: [`MemoryCache::add_cost`]).
    pub fn key_of(&self, request: &Request, natural: Natural) -> Key {
        self.key(request, &request.location.key(), Some(natural)).0
    }

    /// The decoded image `request` asks for, when it is in memory.
    pub fn cached(&self, request: &Request) -> Option<(Decoded<V>, Lease)> {
        let source = request.location.key();
        let natural = self.natural(&source)?;
        self.memory
            .get(&self.key(request, &source, Some(natural)).0)
    }

    /// Loads `request`'s image and calls `done` with it: here and now when
    /// it is in memory, else on a loader thread. Dropping the ticket gives
    /// up waiting (and cancels the load when nobody else waits).
    pub fn load(&self, request: Request, done: Done<V>) -> Ticket {
        if let Some(hit) = self.cached(&request) {
            done(Ok(hit));
            return Ticket::done();
        }
        let id = self.shared.waiters.fetch_add(1, Ordering::Relaxed) + 1;
        let stage = Arc::new(Mutex::new(Stage::default()));
        let images = self.clone();
        let decode_stage = stage.clone();
        let source = request.location.key();
        let priority = request.priority;
        let read_request = request.clone();
        let read = self.loader.read(
            request.location,
            &request.context,
            priority,
            request.progress,
            Box::new(move |bytes| match bytes {
                Ok(bytes) => images.decode(&read_request, source, bytes, id, &decode_stage, done),
                Err(error) => done(Err(error)),
            }),
        );
        let reprioritize = read.reprioritize.clone();
        {
            let mut s = lock(&stage);
            if s.decode.is_none() {
                s.read = Some(read);
            }
        }
        let images = self.clone();
        Ticket::new(move || images.give_up(&stage, id), reprioritize)
    }

    /// The bytes of `request` arrived: decodes them, or waits for the decode
    /// of the same key running.
    fn decode(
        &self,
        request: &Request,
        source: String,
        bytes: ImageData,
        id: u64,
        stage: &Mutex<Stage>,
        done: Done<V>,
    ) {
        let natural = self.natural(&source).or_else(|| Natural::of(&bytes));
        let (key, target) = self.key(request, &source, natural);
        {
            let mut s = lock(stage);
            if s.cancelled {
                return;
            }
            s.read = None;
            s.decode = Some(key.clone());
        }
        // Under the lock a decode ends with (after keeping its image): one
        // decode per key.
        let mut pending = lock(&self.shared.pending);
        if let Some(hit) = self.memory.get(&key) {
            drop(pending);
            done(Ok(hit));
            return;
        }
        if let Some(p) = pending.get_mut(&key) {
            p.waiters.push((id, done));
            return;
        }
        pending.insert(
            key.clone(),
            Pending {
                waiters: vec![(id, done)],
                ticket: None,
            },
        );
        drop(pending);
        let images = self.clone();
        let job_key = key.clone();
        let completion = match self.shared.job_observer.as_ref().map(|observe| observe()) {
            Some(Ok(completion)) => Some(completion),
            Some(Err(error)) => {
                self.decoded(key, Err(error));
                return;
            }
            None => None,
        };
        let ticket = self.loader.decode_observed(
            request.priority,
            move || {
                let result = (images.shared.decoder)(&bytes, &target);
                images.decoded(job_key, result);
            },
            completion,
        );
        if let Some(p) = lock(&self.shared.pending).get_mut(&key) {
            p.ticket = Some(ticket);
        } else {
            ticket.detach();
        }
    }

    /// A decode ended: keeps the image and hands it to who waits.
    fn decoded(&self, key: Key, result: Result<(V, Natural, usize), String>) {
        let take = |key: &Key| {
            lock(&self.shared.pending)
                .remove(key)
                .map(|p| p.waiters)
                .unwrap_or_default()
        };
        match result {
            Ok((value, natural, cost)) => {
                let decoded = Decoded { value, natural };
                // Register before inserting: insertion can evict another bucket
                // of this source (or replace this key). Its callback releases
                // only that entry's hold, including concurrent replacements.
                {
                    let mut naturals = lock(&self.shared.naturals);
                    let entry = naturals.entry(key.source.clone()).or_insert((natural, 0));
                    entry.0 = natural;
                    entry.1 += 1;
                }
                let lease = self.memory.insert(key.clone(), decoded.clone(), cost);
                for (_, done) in take(&key) {
                    done(Ok((decoded.clone(), lease.clone())));
                }
            }
            Err(error) => {
                for (_, done) in take(&key) {
                    done(Err(error.clone()));
                }
            }
        }
    }

    /// Request `id` gave up: its read, or its place among a decode's
    /// waiters, goes (and the decode, when nobody else waits for it).
    fn give_up(&self, stage: &Mutex<Stage>, id: u64) {
        let (read, key) = {
            let mut s = lock(stage);
            s.cancelled = true;
            (s.read.take(), s.decode.take())
        };
        drop(read);
        let Some(key) = key else { return };
        let (removed, ticket) = {
            let mut pending = lock(&self.shared.pending);
            let Some(p) = pending.get_mut(&key) else {
                return;
            };
            let removed = p
                .waiters
                .iter()
                .position(|(w, _)| *w == id)
                .map(|index| p.waiters.swap_remove(index));
            let ticket = if p.waiters.is_empty() {
                pending.remove(&key).and_then(|p| p.ticket)
            } else {
                None
            };
            (removed, ticket)
        };
        // Callback captures can own payloads and completion reports.
        // Never destroy them under the pending-decode mutex.
        drop(removed);
        drop(ticket);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn key(source: &str, longest: u32) -> Key {
        Key {
            source: source.into(),
            longest,
            frames: Frames::All,
        }
    }

    #[test]
    fn unique_sources_release_metadata_but_keep_active_images() {
        let budget = Budget::new(8);
        let images = Images::new(&budget, |_, _| unreachable!());
        let active = key("active", 1);
        images.decoded(active.clone(), Ok((7_u32, Natural::Pixels(1, 1), 4)));
        let (_, lease) = images.memory.get(&active).unwrap();
        for i in 0..10_000 {
            let source = format!("inline:{i}");
            images.decoded(key(&source, 1), Ok((i, Natural::Pixels(1, 1), 4)));
            assert_eq!(budget.used(), 8);
            assert_eq!(lock(&images.shared.naturals).len(), 2);
        }
        assert_eq!(images.natural("active"), Some(Natural::Pixels(1, 1)));
        assert_eq!(images.memory.get(&active).unwrap().0.value, 7);
        assert_eq!(images.natural("inline:0"), None);
        budget.clear();
        assert_eq!(lock(&images.shared.naturals).len(), 1);
        drop(lease);
        budget.clear();
        assert!(lock(&images.shared.naturals).is_empty());
    }

    #[test]
    fn metadata_lives_until_the_last_bucket_and_replacement_go() {
        let budget = Budget::new(100);
        let evictions = Arc::new(AtomicU64::new(0));
        let heard = evictions.clone();
        let images = Images::with_on_evict(
            &budget,
            |_, _| unreachable!(),
            move |_: &u32| {
                heard.fetch_add(1, Ordering::Relaxed);
            },
        );
        let small = key("photo", 1);
        let large = key("photo", 2);
        let natural = Natural::Pixels(2, 2);
        images.decoded(small.clone(), Ok((1, natural, 4)));
        images.decoded(large.clone(), Ok((2, natural, 16)));
        images.decoded(small.clone(), Ok((3, natural, 4)));
        assert_eq!(lock(&images.shared.naturals)["photo"].1, 2);
        images.memory.remove(&small);
        assert_eq!(images.natural("photo"), Some(natural));
        images.memory.remove(&large);
        assert_eq!(images.natural("photo"), None);
        assert_eq!(evictions.load(Ordering::Relaxed), 3);
    }

    #[test]
    fn failed_decodes_keep_no_metadata_and_successful_ones_report_the_decoder_size() {
        let images = Images::new(&Budget::new(16), |_, _| unreachable!());
        images.decoded(key("bad", 0), Err("invalid pixels".into()));
        assert!(lock(&images.shared.naturals).is_empty());
        // Some formats have no header Natural::of can read. The decoder's
        // dimensions must still be remembered while the picture is retained.
        images.decoded(
            key("opaque-header", 0),
            Ok((1_u32, Natural::Pixels(2, 2), 16)),
        );
        assert_eq!(images.natural("opaque-header"), Some(Natural::Pixels(2, 2)));
    }
}
